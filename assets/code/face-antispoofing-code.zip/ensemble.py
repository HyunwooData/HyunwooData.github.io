import os
import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader, ConcatDataset
from torchvision import models
from tqdm import tqdm
from sklearn.metrics import (recall_score, accuracy_score,
                             confusion_matrix, ConfusionMatrixDisplay,
                             roc_curve, auc)

from dataset import (
    get_val_transforms,
    get_combined_dataset,
    CelebASpoofDataset, OULUDataset,
    ROIDataset
)

# ----------------------------------------------------------------
# 경로 설정
# ----------------------------------------------------------------
CELEBA_ROOT    = '/workspace/Project/CelebA_Crop'
CELEBA_VAL_TXT = '/workspace/Project/CelebA_Spoof/metas/intra_test/test_label.txt'
OULU_ROOT      = '/workspace/Project/Oulu-NPU'
CKPT_DIR       = '/workspace/Project/checkpoints'
SAVE_DIR       = '/workspace/Project/checkpoints'

CKPT = {
    1: os.path.join(CKPT_DIR, 'model1_convnext_small_best.pth'),
    2: os.path.join(CKPT_DIR, 'model2_efficientnet_v2_m_best.pth'),
    3: os.path.join(CKPT_DIR, 'model3_efficientnet_b0_best.pth'),
}

# 앙상블 가중치 (합산 = 1.0)
# Model 1 (얼굴 전체)가 가장 중요, Model 2/3은 보조
FUSION_WEIGHTS = {1: 0.5, 2: 0.3, 3: 0.2}

DEVICE   = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
IMG_SIZE = 224

# ----------------------------------------------------------------
# 모델 로드
# ----------------------------------------------------------------
def load_model(model_num):
    if model_num == 1:
        model = models.convnext_small(weights=None)
        model.classifier[2] = nn.Linear(model.classifier[2].in_features, 2)

    elif model_num == 2:
        model = models.efficientnet_v2_m(weights=None)
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, 2)

    elif model_num == 3:
        model = models.efficientnet_b0(weights=None)
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, 2)

    ckpt_path = CKPT[model_num]
    if not os.path.exists(ckpt_path):
        raise FileNotFoundError(f'체크포인트 없음: {ckpt_path}')

    model.load_state_dict(torch.load(ckpt_path, map_location=DEVICE))
    model.to(DEVICE).eval()
    print(f'Model {model_num} 로드 완료: {ckpt_path}')
    return model

# ----------------------------------------------------------------
# Val DataLoader 구성 (train.py와 동일한 방식)
# ----------------------------------------------------------------
def build_val_loaders():
    val_tf = get_val_transforms(IMG_SIZE)

    # Model 1: 얼굴 전체
    val1 = get_combined_dataset(
        CELEBA_ROOT, CELEBA_VAL_TXT, OULU_ROOT, val_tf, split='val')

    # Model 2: 주름살 ROI
    celeba_val = CelebASpoofDataset(CELEBA_ROOT, CELEBA_VAL_TXT, transform=None)
    val2 = ROIDataset(celeba_val, roi_type='wrinkle', transform=val_tf)

    # Model 3: Specular ROI
    oulu_val = OULUDataset(OULU_ROOT, transform=None,
                           val_sessions=(3,), split='val')
    val3 = ConcatDataset([
        ROIDataset(celeba_val, roi_type='specular', transform=val_tf),
        ROIDataset(oulu_val,   roi_type='specular', transform=val_tf),
    ])

    def make_loader(ds):
        return DataLoader(ds, batch_size=64, shuffle=False, num_workers=1)

    return make_loader(val1), make_loader(val2), make_loader(val3)

# ----------------------------------------------------------------
# 단일 모델 추론 → 확률값 반환
# ----------------------------------------------------------------
@torch.no_grad()
def get_probs(model, loader):
    """
    반환: (N,) real 확률, (N,) 정답 라벨
    """
    all_probs  = []
    all_labels = []

    for images, labels in tqdm(loader, desc='Inference', leave=False):
        outputs = model(images.to(DEVICE))
        probs   = torch.softmax(outputs, dim=1)[:, 1]  # spoof 확률
        all_probs.extend(probs.cpu().numpy())
        all_labels.extend(labels.numpy())

    return np.array(all_probs), np.array(all_labels)

# ----------------------------------------------------------------
# 결과 시각화
# ----------------------------------------------------------------
def save_results(labels, preds, probs_ensemble, model_results):
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    fig.suptitle('Ensemble Evaluation', fontsize=14)

    # 1. Confusion Matrix
    cm = confusion_matrix(labels, preds)
    disp = ConfusionMatrixDisplay(cm, display_labels=['Real', 'Spoof'])
    disp.plot(ax=axes[0], colorbar=False)
    axes[0].set_title('Confusion Matrix (Ensemble)')

    # 2. ROC Curve (각 모델 + 앙상블)
    colors = {1: 'blue', 2: 'orange', 3: 'green', 'ensemble': 'red'}
    for key, (probs, lbl) in model_results.items():
        fpr, tpr, _ = roc_curve(lbl, probs)
        roc_auc     = auc(fpr, tpr)
        label       = f'Model {key}' if isinstance(key, int) else 'Ensemble'
        axes[1].plot(fpr, tpr, color=colors[key],
                     label=f'{label} (AUC={roc_auc:.3f})')
    axes[1].plot([0, 1], [0, 1], 'k--')
    axes[1].set_title('ROC Curve')
    axes[1].set_xlabel('FPR')
    axes[1].set_ylabel('TPR')
    axes[1].legend(fontsize=8)

    # 3. 모델별 Recall / Accuracy 막대그래프
    model_labels = ['Model 1\n(Face)', 'Model 2\n(Wrinkle)',
                    'Model 3\n(Specular)', 'Ensemble']
    recalls = []
    accs    = []
    for key in [1, 2, 3, 'ensemble']:
        probs_k, lbl_k = model_results[key]
        preds_k = (probs_k > 0.5).astype(int)
        recalls.append(recall_score(lbl_k, preds_k, zero_division=0))
        accs.append(accuracy_score(lbl_k, preds_k))

    x     = np.arange(len(model_labels))
    width = 0.35
    axes[2].bar(x - width/2, accs,    width, label='Accuracy', color='steelblue')
    axes[2].bar(x + width/2, recalls, width, label='Recall',   color='coral')
    axes[2].set_xticks(x)
    axes[2].set_xticklabels(model_labels, fontsize=8)
    axes[2].set_ylim(0, 1.05)
    axes[2].set_title('Recall & Accuracy per Model')
    axes[2].legend()

    plt.tight_layout()
    save_path = os.path.join(SAVE_DIR, 'ensemble_result.png')
    plt.savefig(save_path, dpi=150)
    plt.close()
    print(f'\n그래프 저장 → {save_path}')

# ----------------------------------------------------------------
# 메인
# ----------------------------------------------------------------
def main():
    print(f'\nDevice: {DEVICE}')
    print(f'Fusion weights: {FUSION_WEIGHTS}\n')

    # 모델 로드
    models_dict = {n: load_model(n) for n in [1, 2, 3]}

    # DataLoader 구성
    loaders = {}
    loaders[1], loaders[2], loaders[3] = build_val_loaders()

    # 각 모델 추론
    probs_dict  = {}
    labels_dict = {}
    for n in [1, 2, 3]:
        probs_dict[n], labels_dict[n] = get_probs(models_dict[n], loaders[n])
        preds_n = (probs_dict[n] > 0.5).astype(int)
        print(f'Model {n} | '
              f'Acc: {accuracy_score(labels_dict[n], preds_n):.4f} | '
              f'Recall: {recall_score(labels_dict[n], preds_n, zero_division=0):.4f}')

    # ── 앙상블 fusion ──────────────────────────────────────────
    # 3개 모델의 val set 크기가 다를 수 있으므로 가장 작은 크기로 맞춤
    min_len = min(len(p) for p in probs_dict.values())
    ensemble_probs = sum(
        FUSION_WEIGHTS[n] * probs_dict[n][:min_len] for n in [1, 2, 3]
    )
    ensemble_labels = labels_dict[1][:min_len]   # 기준: Model 1 라벨
    ensemble_preds  = (ensemble_probs > 0.5).astype(int)

    acc_ens    = accuracy_score(ensemble_labels, ensemble_preds)
    recall_ens = recall_score(ensemble_labels, ensemble_preds, zero_division=0)

    print(f'\n{"="*40}')
    print(f'[Ensemble] Acc: {acc_ens:.4f} | Recall: {recall_ens:.4f}')
    print(f'{"="*40}')

    # 시각화용 데이터 정리
    model_results = {n: (probs_dict[n], labels_dict[n]) for n in [1, 2, 3]}
    model_results['ensemble'] = (ensemble_probs, ensemble_labels)

    save_results(ensemble_labels, ensemble_preds,
                 ensemble_probs, model_results)


if __name__ == '__main__':
    main()