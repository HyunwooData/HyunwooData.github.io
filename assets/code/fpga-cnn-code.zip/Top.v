`timescale 1ns / 1ns

module Top(
  input active,
  input clk, rst,
  
  input [7:0] a11, a12, a13, a14,
  input [7:0] a21, a22, a23, a24,
  input [7:0] a31, a32, a33, a34,
  input [7:0] a41, a42, a43, a44,
  
  input [7:0] b11, b12, b13,
  input [7:0] b21, b22, b23,
  input [7:0] b31, b32, b33,

  //output [7:0] pe_out,
  output [7:0] s_c11, s_c12, s_c21, s_c22,
  output [7:0] s3_c11, s3_c12, s3_c21, s3_c22,
               s2_c11, s2_c12, s2_c21, s2_c22,
  
  output [7:0] c11_33, c12_33, c21_33, c22_33,
               c11_22, c12_22, c21_22, c22_22,
               c11_11, c12_11, c21_11, c22_11
);

wire [7:0]	o_a11, o_a12, o_a13, o_a14, 
				   o_a21, o_a22, o_a23, o_a24, 
				   o_a31, o_a32, o_a33, o_a34, 
				   o_a41, o_a42, o_a43, o_a44;

wire [7:0]	o_b11, o_b12, o_b13, 
				   o_b21, o_b22, o_b23, 
				   o_b31, o_b32, o_b33;

wire //s_c11_en, s_c12_en,
     //s_c21_en, s_c22_en;
     s_active;

wire mem_active, pe_active, sys33_active, sys22_active, display_active;
wire mem_done,   pe_done,   sys33_done,   sys22_done,   display_done;
wire process_inactive;

wire [3:0] a_reg_num, b_reg_num;
wire [7:0] a_reg_out, b_reg_out;
 
Controller controller_module(
  .active(active),
	.clk(clk), .rst(rst),  
	
	.mem_done		   (mem_done), 
	.pe_done			   (pe_done),
	.sys33_done		 (sys33_done),
	.sys22_done		 (sys22_done), 
	.display_done (display_done), 
	
	.mem_active				 (mem_active), 
	.pe_active			   (pe_active), 
	.sys33_active		 (sys33_active), 
	.sys22_active		 (sys22_active), 
	.display_active (display_active),
	 
	.process_inactive(process_inactive)
);  

Memory memory_module (
  .clk        (clk), 
	.rst        (rst),
	.shutdown   (process_inactive),
	.mem_active (mem_active), 
	
	.s_out_en(s_active),
	//.s_out2_en(s_active),
	//.s_out3_en(s_active),
	//.s_out4_en(s_active),
	
	//.s33_out_en	(1'b1), 
	//.s22_out_en	(1'b1),
	.s33_out_en	(sys33_done), 
	.s22_out_en	(sys22_done),
	
	.a11(a11), .a12(a12), .a13(a13), .a14(a14), 
	.a21(a21), .a22(a22), .a23(a23), .a24(a24),
	.a31(a31), .a32(a32), .a33(a33), .a34(a34), 
	.a41(a41), .a42(a42), .a43(a43), .a44(a44),

	.a11_out(o_a11), .a12_out(o_a12), .a13_out(o_a13), .a14_out(o_a14), 
	.a21_out(o_a21), .a22_out(o_a22), .a23_out(o_a23), .a24_out(o_a24),
	.a31_out(o_a31), .a32_out(o_a32), .a33_out(o_a33), .a34_out(o_a34), 
	.a41_out(o_a41), .a42_out(o_a42), .a43_out(o_a43), .a44_out(o_a44),

	.b11(b33), .b12(b32), .b13(b31), 
	.b21(b23), .b22(b22), .b23(b21), 
	.b31(b13), .b32(b12), .b33(b11),  

	.b11_out(o_b11), .b12_out(o_b12), .b13_out(o_b13), 
	.b21_out(o_b21), .b22_out(o_b22), .b23_out(o_b23), 
	.b31_out(o_b31), .b32_out(o_b32), .b33_out(o_b33),   

	.s_c11(s_c11), .s_c12(s_c12), 
	.s_c21(s_c21), .s_c22(s_c22), 
	.s_c11_out	(c11_11),	.s_c12_out	(c12_11), 
	.s_c21_out	(c21_11),	.s_c22_out	(c22_11),

	.s22_c11	(s2_c11),	.s22_c12	(s2_c12), 
	.s22_c21	(s2_c21), .s22_c22	(s2_c22),
	.s22_c11_out(c11_22), .s22_c12_out(c12_22), 
	.s22_c21_out(c21_22), .s22_c22_out(c22_22), 
		
	.s33_c11	(s3_c11), .s33_c12	(s3_c12), 
	.s33_c21	(s3_c21), .s33_c22	(s3_c22),
	.s33_c11_out(c11_33), .s33_c12_out(c12_33), 
	.s33_c21_out(c21_33), .s33_c22_out(c22_33),
	
	.a_reg_num(a_reg_num), .b_reg_num(b_reg_num),
  .a_reg_out(a_reg_out), .b_reg_out(b_reg_out),
  
  .mem_done(mem_done)
);

Computation computation_module (
		.clk(clk), .rst(rst),  

	  .a11(o_a11), .a12(o_a12), .a13(o_a13), .a14(o_a14), 
	  .a21(o_a21), .a22(o_a22), .a23(o_a23), .a24(o_a24),
	  .a31(o_a31), .a32(o_a32), .a33(o_a33), .a34(o_a34), 
	  .a41(o_a41), .a42(o_a42), .a43(o_a43), .a44(o_a44),
		
	  .b11(o_b33), .b12(o_b32), .b13(o_b31), 
	  .b21(o_b23), .b22(o_b22), .b23(o_b21), 
	  .b31(o_b13), .b32(o_b12), .b33(o_b11),  

		.pe_active				(pe_active), 
		.sys33_active	(sys33_active),
		.sys22_active	(sys22_active),
		
		.pe_done			 (pe_done),  
		.sys33_done (sys33_done),  
		.sys22_done	(sys22_done),  

        .s_c11(s_c11), .s_c12(s_c12), .s_c21(s_c21), .s_c22(s_c22),
        .s_active(s_active),
		//.pe_out(pe_out),  
		//.c11_active(s_c11_en), .c12_active(s_c12_en), .c21_active(s_c21_en), .c22_active(s_c22_en),
		
		.s3_c11(s3_c11), .s3_c12(s3_c12), .s3_c21(s3_c21), .s3_c22(s3_c22),
		.s2_c11(s2_c11), .s2_c12(s2_c12), .s2_c21(s2_c21), .s2_c22(s2_c22)    
	);
  
display_module display_module ( 
		.clk (clk), 
		.rst	(rst), 
		
		.display_active	(display_active), 
		.display_done   (display_done), 
        
		.c11_33(c11_33), .c12_33(c12_33), .c21_33(c21_33), .c22_33(c22_33),
		.c11_22(c11_22), .c12_22(c12_22), .c21_22(c21_22), .c22_22(c22_22)                 
	);
  
  
endmodule

