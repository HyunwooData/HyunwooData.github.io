`timescale 1ns / 1ps

module controller_tb();

reg clk, rst;
reg active, mem_done, pe_done, sys33_done, sys22_done, display_done;

wire mem_active, pe_active, sys33_active, sys22_active, display_active;
wire process_inactive;

Controller controller_testbench(
		.clk	(clk), 
		.rst	(rst), 
		.active	(active), 
		
		// Done signal
		.mem_done     (mem_done),
		.pe_done      (pe_done),
		.sys33_done   (sys33_done), 
		.sys22_done   (sys22_done), 
		.display_done (display_done),
		
		//en signal
		.mem_active     (mem_active), 
		.pe_active      (pe_active), 
		.sys33_active   (sys33_active), 
    .sys22_active   (sys22_active),
    .display_active (display_active),
  
    .process_inactive(process_inactive)
);
 
always #10 clk = ~clk;

initial begin
  clk          = 1'b0;
  rst          = 1'b1;
  active       = 1'b0;
  
  mem_done     = 1'b0;
  pe_done      = 1'b0;
  sys33_done   = 1'b0;
  sys22_done   = 1'b0;
  display_done = 1'b0;
  
  #20
  rst = 1'b0;

  #20
  active = 1'b1;

  #20
  active = 1'b0;
  mem_done = 1'b1;
  
  #40
  mem_done = 1'b0;
  pe_done = 1'b1;
 
  #40
  pe_done    = 1'b0;
  sys33_done = 1'b1;
 
  #40
  sys33_done = 1'b0;
  sys22_done = 1'b1;
 
  #40
  sys22_done   = 1'b0;
  display_done = 1'b1;
 
  #40
  display_done = 1'b0;
  
 end

endmodule