`timescale 1ns / 1ps

module sys22_tb;

  reg clk, rst, sys22_active;
  reg [7:0] a11, a12, a13, a14,
            a21, a22, a23, a24,
            a31, a32, a33, a34,
            a41, a42, a43, a44;
  reg [7:0] b11, b12, b13,
            b21, b22, b23,
            b31, b32, b33;

  wire [7:0] c11_o, c12_o, c21_o, c22_o;
  wire [4:0] state;
  wire       sys22_done;

  sys_22 sys_22_testbench (
    .clk         (clk),
    .rst         (rst),
    .sys22_active(sys22_active),

    // 4x4 Input Matrix
    .a11(a11), .a12(a12), .a13(a13), .a14(a14),
    .a21(a21), .a22(a22), .a23(a23), .a24(a24),
    .a31(a31), .a32(a32), .a33(a33), .a34(a34),
    .a41(a41), .a42(a42), .a43(a43), .a44(a44),

    // 3x3 Kernel (Filter)
    .b11(b11), .b12(b12), .b13(b13),
    .b21(b21), .b22(b22), .b23(b23),
    .b31(b31), .b32(b32), .b33(b33),

    // Outputs
    .c1(c11_o), .c2(c12_o), .c3(c21_o), .c4(c22_o),
    .state(state),
    .sys22_done(sys22_done)
  );

  always #10 clk = ~clk;

  initial begin
    clk          = 1'b0;
    rst          = 1'b1;
    sys22_active = 1'b0;

    #11 rst          = 1'b0;
    #5  sys22_active = 1'b1;

    #30 sys22_active = 1'b0;

  end

  initial begin
    // 4x4 Matrix A
    a11=8'd1;   a12=8'd2;   a13=8'd3;   a14=8'd4;
    a21=8'd5;   a22=8'd6;   a23=8'd7;   a24=8'd8;
    a31=8'd9;   a32=8'd10;  a33=8'd11;  a34=8'd12;
    a41=8'd13;  a42=8'd14;  a43=8'd15;  a44=8'd16;

    // 3x3 Filter B
    b11=8'd1;  b12=8'd2;  b13=8'd3;
    b21=8'd4;  b22=8'd5;  b23=8'd6;
    b31=8'd7;  b32=8'd8;  b33=8'd9;
  end    

endmodule
