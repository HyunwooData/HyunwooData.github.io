`timescale 1ns / 1ps

module Memory(
    input clk, rst, mem_active, shutdown,
    input s_out_en,
    //input s_out1_en, s_out2_en, s_out3_en, s_out4_en, 
    input s33_out_en, s22_out_en,
    
    input  [7:0] a11, a12, a13, a14,
                 a21, a22, a23, a24,
                 a31, a32, a33, a34,
                 a41, a42, a43, a44,
    output [7:0] a11_out, a12_out, a13_out, a14_out,
                 a21_out, a22_out, a23_out, a24_out,
                 a31_out, a32_out, a33_out, a34_out,
                 a41_out, a42_out, a43_out, a44_out,
	
    input  [7:0] b11, b12, b13,
                 b21, b22, b23,
                 b31, b32, b33,
    output [7:0] b11_out, b12_out, b13_out,
                 b21_out, b22_out, b23_out,
                 b31_out, b32_out, b33_out,
	
    input  [7:0] s_c11, s_c12, s_c21, s_c22, 
    output [7:0] s_c11_out, s_c12_out, s_c21_out, s_c22_out,
	
    input  [7:0] s33_c11, s33_c12, s33_c21, s33_c22, 
    output [7:0] s33_c11_out, s33_c12_out, s33_c21_out, s33_c22_out,
	
    input  [7:0] s22_c11, s22_c12, s22_c21, s22_c22, 
    output [7:0] s22_c11_out, s22_c12_out, s22_c21_out, s22_c22_out,
	
    input  [3:0] a_reg_num, b_reg_num,
    output reg [7:0] a_reg_out, b_reg_out,
    
    output reg mem_done
);

wire rst_global;

or_gate set_reset (.a(rst), .b(shutdown), .out(rst_global));

Register a11_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a11), .out(a11_out));
Register a12_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a12), .out(a12_out));
Register a13_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a13), .out(a13_out));
Register a14_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a14), .out(a14_out));
Register a21_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a21), .out(a21_out));
Register a22_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a22), .out(a22_out));
Register a23_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a23), .out(a23_out));
Register a24_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a24), .out(a24_out));
Register a31_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a31), .out(a31_out));
Register a32_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a32), .out(a32_out));
Register a33_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a33), .out(a33_out));
Register a34_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a34), .out(a34_out));
Register a41_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a41), .out(a41_out));
Register a42_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a42), .out(a42_out));
Register a43_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a43), .out(a43_out));
Register a44_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(a44), .out(a44_out));

Register b11_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(b11), .out(b11_out));
Register b12_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(b12), .out(b12_out));
Register b13_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(b13), .out(b13_out));
Register b21_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(b21), .out(b21_out));
Register b22_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(b22), .out(b22_out));
Register b23_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(b23), .out(b23_out));
Register b31_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(b31), .out(b31_out));
Register b32_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(b32), .out(b32_out));
Register b33_reg (.clk(clk), .rst(rst_global), .active(mem_active), .in(b33), .out(b33_out));


Register s1_c11_reg (.clk(clk), .rst(rst_global), .active(s_out_en), .in(s_c11), .out(s_c11_out));
Register s1_c12_reg (.clk(clk), .rst(rst_global), .active(s_out_en), .in(s_c12), .out(s_c12_out));
Register s1_c21_reg (.clk(clk), .rst(rst_global), .active(s_out_en), .in(s_c21), .out(s_c21_out));
Register s1_c22_reg (.clk(clk), .rst(rst_global), .active(s_out_en), .in(s_c22), .out(s_c22_out));

Register s3_c11_reg (.clk(clk), .rst(rst_global), .active(s33_out_en), .in(s33_c11), .out(s33_c11_out));
Register s3_c12_reg (.clk(clk), .rst(rst_global), .active(s33_out_en), .in(s33_c12), .out(s33_c12_out));
Register s3_c21_reg (.clk(clk), .rst(rst_global), .active(s33_out_en), .in(s33_c21), .out(s33_c21_out));
Register s3_c22_reg (.clk(clk), .rst(rst_global), .active(s33_out_en), .in(s33_c22), .out(s33_c22_out));

Register s2_c11_reg (.clk(clk), .rst(rst_global), .active(s22_out_en), .in(s22_c11), .out(s22_c11_out));
Register s2_c12_reg (.clk(clk), .rst(rst_global), .active(s22_out_en), .in(s22_c12), .out(s22_c12_out));
Register s2_c21_reg (.clk(clk), .rst(rst_global), .active(s22_out_en), .in(s22_c21), .out(s22_c21_out));
Register s2_c22_reg (.clk(clk), .rst(rst_global), .active(s22_out_en), .in(s22_c22), .out(s22_c22_out));

always @(*) begin
    case (a_reg_num)
        4'd0  : a_reg_out = a11_out;
        4'd1  : a_reg_out = a12_out;
        4'd2  : a_reg_out = a13_out;
        4'd3  : a_reg_out = a14_out;
        4'd4  : a_reg_out = a21_out;
        4'd5  : a_reg_out = a22_out;
        4'd6  : a_reg_out = a23_out;
        4'd7  : a_reg_out = a24_out;
        4'd8  : a_reg_out = a31_out;
        4'd9  : a_reg_out = a32_out;
        4'd10 : a_reg_out = a33_out;
        4'd11 : a_reg_out = a34_out;
        4'd12 : a_reg_out = a41_out;
        4'd13 : a_reg_out = a42_out;
        4'd14 : a_reg_out = a43_out;
        4'd15 : a_reg_out = a44_out;
        default: a_reg_out = 8'd0; 
    endcase

    case (b_reg_num)
        4'd0 : b_reg_out = b11_out;
        4'd1 : b_reg_out = b12_out;
        4'd2 : b_reg_out = b13_out;
        4'd3 : b_reg_out = b21_out;
        4'd4 : b_reg_out = b22_out;
        4'd5 : b_reg_out = b23_out;
        4'd6 : b_reg_out = b31_out;
        4'd7 : b_reg_out = b32_out;
        4'd8 : b_reg_out = b33_out;
        default: b_reg_out = 8'd0;
    endcase
end

always @(*)begin
  mem_done = (mem_active) ? 1'b1 : 1'b0;
end

endmodule




