`timescale 1ns / 1ps

module Controller(
  input active,
  input clk, rst,
  input mem_done, pe_done, sys33_done, sys22_done, display_done,
  
  output mem_active, pe_active, sys33_active, sys22_active, display_active,
  output process_inactive
);

reg [3:0] state, next_state;

localparam [3:0] S0=3'd0, S1=3'd1, S2=3'd2, S3=3'd3, S4=3'd4, S5=3'd5, S6=3'd6;

always @(posedge clk)
begin
  if(rst) state <= S0;
  else    state <= next_state;
end

always @(*)
begin
  next_state = state;
  case(state)
    S0: next_state = (active)      ? S1 : S0;
    S1: next_state = (mem_done)    ? S2 : S1;
    S2: next_state = (pe_done)     ? S3 : S2;
    S3: next_state = (sys33_done)  ? S4 : S3;
    S4: next_state = (sys22_done)  ? S5 : S4;
    S5: next_state = (display_done)? S6 : S5;
    S6: next_state = S0;
    default: next_state = S0;
  endcase
end

assign mem_active       = (state == S1);
assign pe_active        = (state == S2);
assign sys33_active     = (state == S3);
assign sys22_active     = (state == S4);
assign display_active   = (state == S5);
assign process_inactive = (state == S6);

endmodule
