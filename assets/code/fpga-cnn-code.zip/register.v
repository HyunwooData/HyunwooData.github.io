`timescale 1ns / 1ps

module Register (
    input  [7:0] in, 
    output [7:0] out,
    input clk, rst, active
);

reg [7:0] buffer;

assign out = buffer;

always @(posedge clk) begin
  if (rst)
    buffer <= 8'd0;
  else if (active)
    buffer <= in;
  else
    buffer <= buffer;
end

endmodule
