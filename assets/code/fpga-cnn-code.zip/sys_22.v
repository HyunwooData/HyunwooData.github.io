`timescale 1ns / 1ps

module sys_22(
  input clk, rst, sys22_active,
  
  input [7:0] a11, a12, a13, a14,
              a21, a22, a23, a24,
              a31, a32, a33, a34,
              a41, a42, a43, a44,
  
  input [7:0] b11, b12, b13,
              b21, b22, b23,
              b31, b32, b33,
  
  output [7:0] c1, c2, c3, c4,
  
  output reg [4:0] state,
  output reg sys22_done
);

localparam S0  = 0,  S1  = 1,  S2  = 2,  S3  = 3,  S4  = 4,
           S5  = 5,  S6  = 6,  S7  = 7,  S8  = 8,  S9  = 9,
           S10 = 10, S11 = 11, S12 = 12, S13 = 13, S14 = 14,
           S15 = 15, S16 = 16, S17 = 17, S18 = 18, S19 = 19,
           S20 = 20, S21 = 21, S22 = 22, S23 = 23, S24 = 24,
           S25 = 25, S26 = 26, S27 = 27, S28 = 28, S29 = 29;

reg [4:0] next_state;

reg [7:0] matrix_in_top;     // data_in1
reg [7:0] matrix_in_bottom;  // data_in2
reg [7:0] filter_in_left;    // filter_in1
reg [7:0] filter_in_right;

wire [7:0] pe1_sum, pe2_sum, pe3_sum, pe4_sum;
wire [7:0] matrix_pipe_top, matrix_pipe_bottom;
wire [7:0] filter_pipe_left, filter_pipe_right;

reg  [7:0] acc_save1,   acc_save2,   acc_save3,   acc_save4;
reg        acc_active1, acc_active2, acc_active3, acc_active4;
wire [7:0] w_c1, w_c2, w_c3, w_c4;

reg matrix_active;
reg filter_active;

// (0,0) PE : top-left
PE pe1 (
  .clk          (clk),
  .rst          (rst),
  .filter_active(filter_active),
  .matrix_active(matrix_active),
  .sum_active   (matrix_active),
  .sum_in       (8'd0),
  .matrix_in    (matrix_in_top),
  .filter_in    (filter_in_left),
  .matrix_out   (matrix_pipe_top),
  .filter_out   (filter_pipe_left),
  .sum_out      (pe1_sum)
);

// (0,1) PE : top-right
PE pe2 (
  .clk          (clk),
  .rst          (rst),
  .filter_active(filter_active),
  .matrix_active(matrix_active),
  .sum_active   (matrix_active),
  .sum_in       (8'd0),
  .matrix_in    (matrix_pipe_top),
  .filter_in    (filter_in_right),
  .matrix_out   (),
  .filter_out   (filter_pipe_right),
  .sum_out      (pe2_sum)
);

// (1,0) PE : bottom-left
PE pe3 (
  .clk          (clk),
  .rst          (rst),
  .filter_active(filter_active),
  .matrix_active(matrix_active),
  .sum_active   (matrix_active),
  .sum_in       (pe1_sum),
  .matrix_in    (matrix_in_bottom),
  .filter_in    (filter_pipe_left),
  .matrix_out   (matrix_pipe_bottom),
  .filter_out   (),
  .sum_out      (pe3_sum)
);

// (1,1) PE : bottom-right
PE pe4 (
  .clk          (clk),
  .rst          (rst),
  .filter_active(filter_active),
  .matrix_active(matrix_active),
  .sum_active   (matrix_active),
  .sum_in       (pe2_sum),
  .matrix_in    (matrix_pipe_bottom),
  .filter_in    (filter_pipe_right),
  .matrix_out   (),
  .filter_out   (),
  .sum_out      (pe4_sum)
);

Accumulator acc1 (
  .clk    (clk),
  .rst    (rst),
  .active (acc_active1),
  .in     (acc_save1),
  .out    (w_c1)
);

Accumulator acc2 (
  .clk    (clk),
  .rst    (rst),
  .active (acc_active2),
  .in     (acc_save2),
  .out    (w_c2)
);

Accumulator acc3 (
  .clk    (clk),
  .rst    (rst),
  .active (acc_active3),
  .in     (acc_save3),
  .out    (w_c3)
);

Accumulator acc4 (
  .clk    (clk),
  .rst    (rst),
  .active (acc_active4),
  .in     (acc_save4),
  .out    (w_c4)
);

always @(posedge clk or posedge rst) begin
  if (rst)
    state <= S0;
  else
    state <= next_state;
  end

// Next-State * Control Logic
always @(*) begin
        next_state = state;
        sys22_done = 1'b0;

        matrix_in_top    = 8'd0;
        matrix_in_bottom = 8'd0;
        filter_in_left   = 8'd0;
        filter_in_right  = 8'd0;

        acc_active1 = 1'b0;
        acc_active2 = 1'b0;
        acc_active3 = 1'b0;
        acc_active4 = 1'b0;
        acc_save1   = 8'd0;
        acc_save2   = 8'd0;
        acc_save3   = 8'd0;
        acc_save4   = 8'd0;

        matrix_active = 1'b1;
        filter_active = 1'b0;

        case (state)
            S0: begin
                if (sys22_active)
                    next_state = S1;
            end

            // 1st filter
            S1: begin
                filter_in_left  = b23;
                filter_in_right = b22;
                filter_active   = 1'b1;
                matrix_active   = 1'b0;
                next_state      = S2;
            end

            S2: begin
                filter_in_left  = b33;
                filter_in_right = b32;
                filter_active   = 1'b1;
                matrix_active   = 1'b0;
                next_state      = S3;
            end

            // 1st input
            S3: begin
                matrix_in_top    = a11;
                matrix_in_bottom = 8'd0;
                next_state       = S4;
            end

            S4: begin
                matrix_in_top    = a12;
                matrix_in_bottom = a21;
                next_state       = S5;
            end

            S5: begin
                matrix_in_top    = a13;
                matrix_in_bottom = a22;
                acc_active1      = 1'b1;
                acc_save1        = pe3_sum;
                next_state       = S6;
            end

            S6: begin
                matrix_in_top    = a21;
                matrix_in_bottom = a23;
                acc_active2      = 1'b1;
                acc_save2        = pe3_sum;
                next_state       = S7;
            end

            S7: begin
                matrix_in_top    = a22;
                matrix_in_bottom = a31;
                acc_active1      = 1'b1;
                acc_save1        = pe4_sum;
                next_state       = S8;
            end

            S8: begin
                matrix_in_top    = a23;
                matrix_in_bottom = a32;
                acc_active2      = 1'b1;
                acc_save2        = pe4_sum;
                acc_active3      = 1'b1;
                acc_save3        = pe3_sum;
                next_state       = S9;
            end

            S9: begin
                matrix_in_top    = 8'd0;
                matrix_in_bottom = a33;
                acc_active4      = 1'b1;
                acc_save4        = pe3_sum;
                next_state       = S10;
            end

            S10: begin
                matrix_in_top    = 8'd0;
                matrix_in_bottom = 8'd0;
                acc_active3      = 1'b1;
                acc_save3        = pe4_sum;
                next_state       = S11;
            end

            // 2nd filter
            S11: begin
                filter_in_left  = b12;
                filter_in_right = b11;
                filter_active   = 1'b1;
                matrix_active   = 1'b0;
                acc_active4     = 1'b1;
                acc_save4       = pe4_sum;
                next_state      = S12;
            end

            S12: begin
                filter_in_left  = b13;
                filter_in_right = 8'd0;
                filter_active   = 1'b1;
                matrix_active   = 1'b0;
                next_state      = S13;
            end

            // 2nd input
            S13: begin
                matrix_in_top    = a31;
                matrix_in_bottom = 8'd0;
                next_state       = S14;
            end

            S14: begin
                matrix_in_top    = a32;
                matrix_in_bottom = a32;
                next_state       = S15;
            end

            S15: begin
                matrix_in_top    = 8'd0;
                matrix_in_bottom = a33;
                acc_active1      = 1'b1;
                acc_save1        = pe3_sum;
                next_state       = S16;
            end

            S16: begin
                matrix_in_top    = a41;
                matrix_in_bottom = a34;
                acc_active2      = 1'b1;
                acc_save2        = pe3_sum;
                next_state       = S17;
            end

            S17: begin
                matrix_in_top    = a42;
                matrix_in_bottom = a42;
                acc_active1      = 1'b1;
                acc_save1        = pe4_sum;
                next_state       = S18;
            end

            S18: begin
                matrix_in_top    = 8'd0;
                matrix_in_bottom = a43;
                acc_active3      = 1'b1;
                acc_save3        = pe3_sum;
                acc_active2      = 1'b1;
                acc_save2        = pe4_sum;
                next_state       = S19;
            end

            S19: begin
                matrix_in_top    = 8'd0;
                matrix_in_bottom = a44;
                acc_active4      = 1'b1;
                acc_save4        = pe3_sum;
                next_state       = S20;
            end

            S20: begin
                matrix_in_top    = 8'd0;
                matrix_in_bottom = 8'd0;
                acc_active3      = 1'b1;
                acc_save3        = pe4_sum;
                next_state       = S21;
            end

            // 3rd filter
            S21: begin
                filter_in_left  = b21;
                filter_in_right = 8'd0;
                filter_active   = 1'b1;
                matrix_active   = 1'b0;

                acc_active4     = 1'b1;
                acc_save4     	 = pe4_sum;
                next_state      = S22;
            end

            S22: begin
                filter_in_left  = b31;
                filter_in_right = 8'd0;
                filter_active   = 1'b1;
                matrix_active   = 1'b0;
                next_state      = S23;
            end

            // 3rd input
            S23: begin
                matrix_in_top    = a13;
                matrix_in_bottom = 8'd0;
                next_state       = S24;
            end

            S24: begin
                matrix_in_top    = a14;
                matrix_in_bottom = a23;
                next_state       = S25;
            end

            S25: begin
                matrix_in_top    = a23;
                matrix_in_bottom = a24;
                acc_active1      = 1'b1;
                acc_save1        = pe3_sum;
                next_state       = S26;
            end

            S26: begin
                matrix_in_top    = a24;
                matrix_in_bottom = a33;
                acc_active2      = 1'b1;
                acc_save2        = pe3_sum;
                next_state       = S27;
            end

            S27: begin
                matrix_in_top    = 8'd0;
                matrix_in_bottom = a34;
                acc_active3      = 1'b1;
                acc_save3        = pe3_sum;
                next_state       = S28;
            end

            S28: begin
                matrix_in_top    = 8'd0;
                matrix_in_bottom = 8'd0;
                acc_active4      = 1'b1;
                acc_save4        = pe3_sum;
                next_state       = S29;
            end

            S29: begin
                matrix_in_top    = 8'd0;
                matrix_in_bottom = 8'd0;
                sys22_done       = 1'b1;
                next_state       = S0;
            end
        endcase
    end

    assign c1 = w_c1;
    assign c2 = w_c2;
    assign c3 = w_c3;
    assign c4 = w_c4;

endmodule

