import os
import cv2
import random
import numpy as np
import torch
from torch.utils.data import Dataset, ConcatDataset
import albumentations as A
from albumentations.pytorch import ToTensorV2

# ================================================================
# [Citation] CelebA-Spoof
# @inproceedings{zhang2020celeba,
#   title={CelebA-Spoof: Large-Scale Face Anti-Spoofing Dataset
#          with Rich Annotations},
#   author={Zhang, Yuanhan and Yin, Zhenfei and Li, Yidong and
#           Yin, Guojun and Yan, Junjie and Shao, Jing and Liu, Ziwei},
#   booktitle={ECCV},
#   year={2020}
# }
#
# [Citation] OULU-NPU
# @inproceedings{boulkenafet2017oulu,
#   title={OULU-NPU: A mobile face presentation attack database
#          with real-world variations},
#   author={Boulkenafet, Z. and Komulainen, J. and Li, Lei and
#           Feng, X. and Hadid, A.},
#   booktitle={FG},
#   year={2017}
# }
# ================================================================


# ----------------------------------------------------------------
# 1. Transforms
# ----------------------------------------------------------------

def get_train_transforms(img_size=224):
    return A.Compose([
        A.Resize(img_size, img_size),
        A.HorizontalFlip(p=0.5),
        A.ImageCompression(compression_type='jpeg', quality_range=(60, 100), p=0.3),
        A.GaussianBlur(blur_limit=(3, 7), p=0.2),
        A.ColorJitter(brightness=0.2, contrast=0.2, p=0.2),
        A.Normalize(mean=[0.485, 0.456, 0.406],
                    std=[0.229, 0.224, 0.225]),
        ToTensorV2()
    ])

def get_val_transforms(img_size=224):
    return A.Compose([
        A.Resize(img_size, img_size),
        A.Normalize(mean=[0.485, 0.456, 0.406],
                    std=[0.229, 0.224, 0.225]),
        ToTensorV2()
    ])

# ----------------------------------------------------------------
# 2. CelebA-Spoof Dataset
#    - 새 crop 방식(MTCNN 기반)으로 저장된 CelebA_Crop 폴더 사용
#    - txt 파일의 경로가 crop 폴더 기준으로 그대로 유지됨
#    - 라벨: 0 = real, 1 = spoof
# ----------------------------------------------------------------

class CelebASpoofDataset(Dataset):
    def __init__(self, root_dir, list_file, transform=None):
        """
        root_dir  : CelebA_Crop 폴더 경로
        list_file : train_label.txt 또는 test_label.txt 경로
        """
        self.root_dir  = root_dir
        self.transform = transform
        self.data_list = []

        with open(list_file, 'r') as f:
            lines = f.readlines()
            for line in lines:
                parts     = line.strip().split()
                if len(parts) < 2: continue

                img_path  = parts[0]
                label     = int(parts[-1])   # 0: real, 1: spoof

                if img_path.startswith('Data/'):
                    img_path = img_path.replace('Data/', '', 1)
                full_path = os.path.join(root_dir, img_path)
                if os.path.exists(full_path):
                    self.data_list.append((img_path, label))

        print(f"CelebA-Spoof ({os.path.basename(list_file)}): "
              f"{len(self.data_list)}개")

    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, idx):
        img_path, label = self.data_list[idx]
        image = cv2.imread(os.path.join(self.root_dir, img_path))
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        if self.transform:
            image = self.transform(image=image)['image']

        return image, torch.tensor(label, dtype=torch.long)


# ----------------------------------------------------------------
# 3. OULU-NPU Dataset
#    - true/false 폴더 구조
#    - 파일명: {device}_{session}_{subject}_{lighting}_{seq}.jpg
#    - 세션 단위로 train/val 분리 (데이터 누수 방지)
#    - 라벨: 0 = real(true), 1 = spoof(false)
# ----------------------------------------------------------------

def parse_oulu_filename(filename):
    """
    파일명에서 메타데이터 파싱
    예: 2_1_34_2_1.jpg
        → device=2, session=1, subject=34, lighting=2
    """
    name  = os.path.splitext(filename)[0]
    parts = name.split('_')

    if len(parts) < 4:
        return None

    try:
        return {
            'device':   int(parts[0]),   # 1~6  (촬영 기기)
            'session':  int(parts[1]),   # 1~3  (촬영 환경)
            'subject':  int(parts[2]),   # 1~55 (피험자)
            'lighting': int(parts[3]),   # 조명 조건
        }
    except ValueError:
        return None


class OULUDataset(Dataset):
    def __init__(self, root_dir, transform=None,
                 train_sessions=(1, 2), val_sessions=(3,),
                 split='train'):
        """
        root_dir       : oulu_npu 폴더 경로 (true/, false/ 포함)
        train_sessions : train에 사용할 세션 번호 튜플
        val_sessions   : val에 사용할 세션 번호 튜플
        split          : 'train' or 'val'
        """
        self.transform = transform
        self.data_list = []

        target_sessions = train_sessions if split == 'train' else val_sessions

        for label_name, label_idx in [('true', 0), ('false', 1)]:
            folder = os.path.join(root_dir, label_name)
            if not os.path.exists(folder):
                print(f"[경고] 폴더 없음: {folder}")
                continue

            for fname in sorted(os.listdir(folder)):
                if not fname.lower().endswith(('.jpg', '.png', '.jpeg')):
                    continue

                meta = parse_oulu_filename(fname)
                if meta is None:
                    continue

                if meta['session'] not in target_sessions:
                    continue

                full_path = os.path.join(folder, fname)
                if os.path.exists(full_path):
                    self.data_list.append((full_path, label_idx))

        print(f"OULU-NPU [{split}] 세션{target_sessions}: "
              f"{len(self.data_list)}개")

    def __len__(self):
        return len(self.data_list)

    def __getitem__(self, idx):
        img_path, label = self.data_list[idx]
        image = cv2.imread(img_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        if self.transform:
            image = self.transform(image=image)['image']

        return image, torch.tensor(label, dtype=torch.long)


# ----------------------------------------------------------------
# 4. 두 데이터셋 합치기
#    - CelebA-Spoof + OULU-NPU → 하나의 DataLoader로 사용
# ----------------------------------------------------------------

def get_combined_dataset(celeba_root, celeba_list,
                         oulu_root,
                         transform,
                         split='train'):
    """
    CelebA-Spoof와 OULU-NPU를 합친 데이터셋 반환

    사용 예시:
        train_ds = get_combined_dataset(
            celeba_root  = '/workspace/Project/CelebA_Crop',
            celeba_list  = '/workspace/Project/CelebA_Spoof/metas/intra_test/train_label.txt',
            oulu_root    = '/workspace/Project/oulu_npu',
            transform    = get_train_transforms(),
            split        = 'train'
        )
    """
    celeba_ds = CelebASpoofDataset(
        root_dir  = celeba_root,
        list_file = celeba_list,
        transform = transform
    )
    oulu_ds = OULUDataset(
        root_dir       = oulu_root,
        transform      = transform,
        train_sessions = (1, 2),
        val_sessions   = (3,),
        split          = split
    )

    combined = ConcatDataset([celeba_ds, oulu_ds])
    print(f"Combined [{split}]: 총 {len(combined)}개 "
          f"(CelebA {len(celeba_ds)} + OULU {len(oulu_ds)})")
    return combined


# ----------------------------------------------------------------
# 5. dlib 기반 ROI 추출
#    - Model 2 (주름살), Model 3 (specular highlight) 전처리용
#    - shape_predictor_68_face_landmarks.dat 필요
#      다운로드: http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2
# ----------------------------------------------------------------

try:
    import dlib
    _detector  = dlib.get_frontal_face_detector()
    _predictor = dlib.shape_predictor(
        "/workspace/Project/shape_predictor_68_face_landmarks.dat"
    )
    DLIB_AVAILABLE = True
except Exception:
    DLIB_AVAILABLE = False
    print("[경고] dlib 로드 실패 - ROI 기반 dataset은 사용 불가")


def get_landmarks(img_rgb):
    """RGB 이미지 → 68개 랜드마크 좌표 (68, 2) 반환, 실패 시 None"""
    if not DLIB_AVAILABLE:
        return None
    gray  = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2GRAY)
    faces = _detector(gray, 1)
    if len(faces) == 0:
        return None
    shape  = _predictor(gray, faces[0])
    coords = np.array([[shape.part(i).x, shape.part(i).y]
                       for i in range(68)])
    return coords


def crop_wrinkle_roi(img_rgb, landmarks, margin=10):
    """
    주름살 ROI 추출: 눈가(crow's feet) + 팔자주름(nasolabial fold)
    → 4개 영역을 2x2 타일로 합쳐 단일 이미지 반환
    랜드마크 포인트:
        왼쪽 눈: 36~41
        오른쪽 눈: 42~47
        코 끝: 30
        입 왼쪽 모서리: 48
        입 오른쪽 모서리: 54
    """
    h, w   = img_rgb.shape[:2]
    regions = []

    def safe_crop(pts, extra_top=0):
        x1 = max(0, pts[:, 0].min() - margin)
        x2 = min(w, pts[:, 0].max() + margin)
        y1 = max(0, pts[:, 1].min() - margin - extra_top)
        y2 = min(h, pts[:, 1].max() + margin)
        return img_rgb[y1:y2, x1:x2]

    # 왼쪽 눈가
    regions.append(safe_crop(landmarks[36:42]))
    # 오른쪽 눈가
    regions.append(safe_crop(landmarks[42:48]))

    # 왼쪽 팔자주름: 코끝(30) ~ 입 왼쪽(48)
    nose = landmarks[30]
    ml   = landmarks[48]
    pts  = np.array([nose, ml])
    regions.append(safe_crop(pts))

    # 오른쪽 팔자주름: 코끝(30) ~ 입 오른쪽(54)
    mr  = landmarks[54]
    pts = np.array([nose, mr])
    regions.append(safe_crop(pts))

    return _tile_regions(regions, tile_size=112)   # 112*2 = 224


def crop_specular_roi(img_rgb, landmarks, margin=15):
    """
    Specular highlight ROI 추출: 이마 + 코
    → 2개 영역을 1x2 타일로 합쳐 단일 이미지 반환
    랜드마크 포인트:
        눈썹: 17~26
        코:   27~35
    """
    h, w    = img_rgb.shape[:2]
    regions = []

    # 이마: 눈썹(17~26) 기준 위쪽 40px
    brows = landmarks[17:27]
    bx1   = max(0, brows[:, 0].min() - margin)
    bx2   = min(w, brows[:, 0].max() + margin)
    by1   = max(0, brows[:, 1].min() - 40)
    by2   = brows[:, 1].max()
    regions.append(img_rgb[by1:by2, bx1:bx2])

    # 코: 27~35
    nose = landmarks[27:36]
    nx1  = max(0, nose[:, 0].min() - margin)
    nx2  = min(w, nose[:, 0].max() + margin)
    ny1  = max(0, nose[:, 1].min() - margin)
    ny2  = min(h, nose[:, 1].max() + margin)
    regions.append(img_rgb[ny1:ny2, nx1:nx2])

    return _tile_regions(regions, tile_size=112, grid=(1, 2))


def _tile_regions(regions, tile_size=112, grid=(2, 2)):
    """
    여러 ROI 이미지를 타일 형태로 합쳐 단일 이미지로 반환
    빈 슬롯은 검정(0)으로 채움
    """
    rows, cols = grid
    tiles = []
    for r in regions:
        if r is None or r.size == 0:
            tiles.append(np.zeros((tile_size, tile_size, 3), dtype=np.uint8))
        else:
            tiles.append(cv2.resize(r, (tile_size, tile_size)))

    # 부족한 슬롯 채우기
    while len(tiles) < rows * cols:
        tiles.append(np.zeros((tile_size, tile_size, 3), dtype=np.uint8))

    rows_imgs = []
    for i in range(rows):
        rows_imgs.append(np.hstack(tiles[i * cols:(i + 1) * cols]))
    return np.vstack(rows_imgs)


# ----------------------------------------------------------------
# 6. ROI 기반 Dataset (Model 2, 3 전용)
#    - 동일한 이미지에서 dlib으로 ROI를 추출해 학습
#    - wrinkle: 주름살 영역
#    - specular: 이마/코 영역
# ----------------------------------------------------------------

class ROIDataset(Dataset):
    def __init__(self, base_dataset, roi_type='wrinkle', transform=None):
        """
        base_dataset : CelebASpoofDataset 또는 OULUDataset 인스턴스
                       (transform=None으로 생성해서 넘겨야 함)
        roi_type     : 'wrinkle' or 'specular'
        transform    : ROI 이미지에 적용할 transform
        """
        assert roi_type in ('wrinkle', 'specular'), \
            "roi_type은 'wrinkle' 또는 'specular'여야 합니다"
        assert DLIB_AVAILABLE, "dlib이 설치되어 있어야 합니다"

        self.base     = base_dataset
        self.roi_type = roi_type
        self.transform = transform

        # dlib 실패 이미지를 미리 필터링
        self.valid_indices = []
        print(f"ROIDataset ({roi_type}) 유효 이미지 필터링 중...")
        for i in range(len(self.base)):
            img_path = (self.base.data_list[i][0]
                        if hasattr(self.base, 'data_list')
                        else None)
            if img_path:
                img = cv2.imread(
                    os.path.join(getattr(self.base, 'root_dir', ''), img_path)
                    if not os.path.isabs(img_path) else img_path
                )
                if img is not None:
                    lm = get_landmarks(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
                    if lm is not None:
                        self.valid_indices.append(i)

        print(f"ROIDataset ({roi_type}): {len(self.valid_indices)}개 유효")

    def __len__(self):
        return len(self.valid_indices)

    def __getitem__(self, idx):
        base_idx = self.valid_indices[idx]

        # base_dataset에서 원본 이미지 경로와 라벨 가져오기
        item     = self.base.data_list[base_idx]
        img_path = item[0]
        label    = item[1]

        root = getattr(self.base, 'root_dir', '')
        full_path = (os.path.join(root, img_path)
                     if not os.path.isabs(img_path) else img_path)

        img = cv2.imread(full_path)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        landmarks = get_landmarks(img_rgb)

        if self.roi_type == 'wrinkle':
            roi = crop_wrinkle_roi(img_rgb, landmarks)
        else:
            roi = crop_specular_roi(img_rgb, landmarks)

        if self.transform:
            roi = self.transform(image=roi)['image']

        return roi, torch.tensor(label, dtype=torch.long)