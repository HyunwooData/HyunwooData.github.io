import pandas as pd

def sort_by_standard(data, standard, mode):
    ''' 정렬 기준(다중 조건은 리스트 형태로 받음) 데이터와 기준, 모드(오름차순, 내림차순)을 입력받으면 결과를 프린트하는 함수'''
    if mode == 'ascending':
        variable = True
    else:
        variable = False
    tempdata = data.sort_values(by=standard, ascending = variable)
    return tempdata

def search_by_value(data, standard, value):
    '''데이터와 기준, 값을 받으면 그에 따른 결과를 프린트하는 함수'''
    try:
        tempdata = data[data.loc[:,standard].str.contains(value)]
    except:
        tempdata = data[data.loc[:,standard] == value]
    return tempdata

def print_by_cut(data, cut_value):
    '''데이터를 받으면 일정 인덱스까지 잘라 프린트하는 함수'''
    return data.head(cut_value)

def multi_search_by_value(data, standard, value):
    '''standard와 value를 리스트 형태로 받아 검색하는 함수'''
    tempdata = data
    for i in range(len(standard)):
        tempdata = search_by_value(tempdata, standard[i], value[i])
    return tempdata

def search_for_salary_predict(data_list, name, year, team, pos):
    '''데이터 리스트, 이름, 연도, 팀명, 포지션(투수 혹은 타자)를 받아 정보를 검색해
        모델이 예측하기 전단계의 데이터 형태로 바꿔주는 함수
        ex)
        data_list = [hitter, runner, pitcher, hitter]
        '''
    standard = ['선수명', 'Year', '팀명']
    value = [name, year, team]
   
    for idx, data in enumerate(data_list):
        if idx == 0:
            find= multi_search_by_value(data, standard, value)
        else:
            find_one = multi_search_by_value(data, standard, value)
            findtemp = pd.merge(find_one, find, how = 'inner', on=['선수명', '팀명'])
            if findtemp.shape[0] != 0:
                find = findtemp
        
    if pos == 'pitcher':
        find['WAR'] = 3.8
        find = find.drop(columns = ['Year_x', 'Year_y'])
        find['WAR'] = pd.to_numeric(find['WAR'], errors='coerce')

        try:
            find = find.loc[:, ['ERA', 'G', 'W', 'L', 'SV', 'HLD', 'WPCT', 'IP', 'H', 'HR', 'BB', 'HBP',
       'SO', 'R', 'ER', 'WHIP', 'CG', 'SHO', 'QS', 'BSV', 'TBF', 'NP', 'AVG',
       '2B', '3B', 'SAC', 'SF', 'IBB', 'WP', 'BK', 'WAR']]
        except:
            print('Not Enough information on the database')
    elif pos =='batter':
        find['WAR'] = 3.52
        find = find.drop(columns = ['G_x', 'SB%', 'G_y','Year_x', 'Year_y'])
        find['WAR'] = pd.to_numeric(find['WAR'], errors='coerce')
        try:
            find = find.loc[:, ['SBA', 'SB', 'CS', 'OOB', 'PKO', 'AVG', 'PA', 'AB', 'R', 'H', '2B',
       '3B', 'HR', 'TB', 'RBI', 'SAC', 'SF', 'BB', 'IBB', 'HBP', 'SO', 'GDP',
       'SLG', 'OBP', 'OPS', 'MH', 'RISP', 'PH-BA', 'WAR']]
        except:
           print('Not Enough information on the database')
    else:
        print('Please check the position batter/pitcher')
    
    return find