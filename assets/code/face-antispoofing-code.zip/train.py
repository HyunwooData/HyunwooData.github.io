import os
import argparse
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader
from torchvision import models
from tqdm import tqdm
from sklearn.metrics import recall_score, accuracy_score

from dataset import (
    get_train_transforms, get_val_transforms,
    get_combined_dataset,
    CelebASpoofDataset, OULUDataset,
    ROIDataset
)

# ----------------------------------------------------------------
# 경로 설정
# ----------------------------------------------------------------
CELEBA_ROOT      = '/workspace/Project/CelebA_Crop'
CELEBA_TRAIN_TXT = '/workspace/Project/CelebA_Spoof/metas/intra_test/train_label.txt'
CELEBA_VAL_TXT   = '/workspace/Project/CelebA_Spoof/metas/intra_test/test_label.txt'
OULU_ROOT        = '/workspace/Project/Oulu-NPU'
SAVE_DIR         = '/workspace/Project/checkpoints'
os.makedirs(SAVE_DIR, exist_ok=True)

# ----------------------------------------------------------------
# Argparse
# ----------------------------------------------------------------
parser = argparse.ArgumentParser(description="Train Ensemble Anti-Spoofing Models")
parser.add_argument('--model_num', type=int, required=True, choices=[1, 2, 3],
                    help='1: 얼굴(ConvNeXt-S), 2: 주름살(EfficientNetV2-M), 3: Specular(EfficientNetB0)')
parser.add_argument('--epochs',     type=int,   default=20)
parser.add_argument('--batch_size', type=int,   default=64)
parser.add_argument('--lr',         type=float, default=1e-4)
parser.add_argument('--weight_decay', type=float, default=0.05)
args = parser.parse_args()

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
IMG_SIZE = 224

MODEL_INFO = {
    1: ('ConvNeXt-Small',      'convnext_small'),
    2: ('EfficientNetV2-M',    'efficientnet_v2_m'),
    3: ('EfficientNetB0',      'efficientnet_b0'),
}
model_name, model_key = MODEL_INFO[args.model_num]
LOG_PATH = os.path.join(SAVE_DIR, f'log_model{args.model_num}_{model_key}.txt')

# ----------------------------------------------------------------
# 로깅
# ----------------------------------------------------------------
def log(msg):
    print(msg)
    with open(LOG_PATH, 'a') as f:
        f.write(msg + '\n')

# ----------------------------------------------------------------
# 모델 정의
# ----------------------------------------------------------------
def get_model(model_key):
    log(f'Loading {model_key}...')

    if model_key == 'convnext_small':
        model = models.convnext_small(weights='DEFAULT')
        model.classifier[2] = nn.Linear(model.classifier[2].in_features, 2)

    elif model_key == 'efficientnet_v2_m':
        model = models.efficientnet_v2_m(weights='DEFAULT')
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, 2)

    elif model_key == 'efficientnet_b0':
        model = models.efficientnet_b0(weights='DEFAULT')
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, 2)

    return model.to(DEVICE)

# ----------------------------------------------------------------
# 데이터셋 구성
# ----------------------------------------------------------------
def build_dataloaders(model_num):
    train_tf = get_train_transforms(IMG_SIZE)
    val_tf   = get_val_transforms(IMG_SIZE)

    if model_num == 1:
        # 얼굴 전체 - CelebA + OULU 합산
        train_ds = get_combined_dataset(
            CELEBA_ROOT, CELEBA_TRAIN_TXT, OULU_ROOT, train_tf, split='train')
        val_ds = get_combined_dataset(
            CELEBA_ROOT, CELEBA_VAL_TXT, OULU_ROOT, val_tf, split='val')

    elif model_num == 2:
        # 주름살 ROI - CelebA만 (OULU는 이미지 품질이 낮아 ROI 추출 불안정)
        celeba_train = CelebASpoofDataset(CELEBA_ROOT, CELEBA_TRAIN_TXT, transform=None)
        celeba_val   = CelebASpoofDataset(CELEBA_ROOT, CELEBA_VAL_TXT,   transform=None)
        train_ds = ROIDataset(celeba_train, roi_type='wrinkle',  transform=train_tf)
        val_ds   = ROIDataset(celeba_val,   roi_type='wrinkle',  transform=val_tf)

    elif model_num == 3:
        # Specular ROI - CelebA + OULU
        celeba_train = CelebASpoofDataset(CELEBA_ROOT, CELEBA_TRAIN_TXT, transform=None)
        celeba_val   = CelebASpoofDataset(CELEBA_ROOT, CELEBA_VAL_TXT,   transform=None)
        oulu_train   = OULUDataset(OULU_ROOT, transform=None,
                                   train_sessions=(1, 2), split='train')
        oulu_val     = OULUDataset(OULU_ROOT, transform=None,
                                   val_sessions=(3,), split='val')

        from torch.utils.data import ConcatDataset
        train_base = ConcatDataset([celeba_train, oulu_train])
        val_base   = ConcatDataset([celeba_val,   oulu_val])

        # ConcatDataset은 data_list가 없어서 ROIDataset에 직접 못 넘김
        # → 각각 ROI로 변환 후 합치기
        train_ds = ConcatDataset([
            ROIDataset(celeba_train, roi_type='specular', transform=train_tf),
            ROIDataset(oulu_train,   roi_type='specular', transform=train_tf),
        ])
        val_ds = ConcatDataset([
            ROIDataset(celeba_val, roi_type='specular', transform=val_tf),
            ROIDataset(oulu_val,   roi_type='specular', transform=val_tf),
        ])

    train_loader = DataLoader(train_ds, batch_size=args.batch_size,
                              shuffle=True,  num_workers=4, pin_memory=True)
    val_loader   = DataLoader(val_ds,   batch_size=args.batch_size,
                              shuffle=False, num_workers=1)

    log(f'Train: {len(train_ds)}개 | Val: {len(val_ds)}개')
    return train_loader, val_loader

# ----------------------------------------------------------------
# 그래프 저장
# ----------------------------------------------------------------
def save_plots(history, model_num, model_key):
    epochs = range(1, len(history['train_loss']) + 1)

    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    fig.suptitle(f'Model {model_num}: {model_key}', fontsize=13)

    # Loss
    axes[0].plot(epochs, history['train_loss'], label='Train Loss')
    axes[0].set_title('Train Loss')
    axes[0].set_xlabel('Epoch')
    axes[0].legend()

    # Accuracy
    axes[1].plot(epochs, history['val_acc'], label='Val Accuracy', color='orange')
    axes[1].set_title('Validation Accuracy')
    axes[1].set_xlabel('Epoch')
    axes[1].set_ylim(0, 1)
    axes[1].legend()

    # Recall
    axes[2].plot(epochs, history['val_recall'], label='Val Recall', color='green')
    axes[2].set_title('Validation Recall')
    axes[2].set_xlabel('Epoch')
    axes[2].set_ylim(0, 1)
    axes[2].legend()

    plt.tight_layout()
    save_path = os.path.join(SAVE_DIR, f'plot_model{model_num}_{model_key}.png')
    plt.savefig(save_path, dpi=150)
    plt.close()
    log(f'그래프 저장 → {save_path}')

# ----------------------------------------------------------------
# 학습 루프
# ----------------------------------------------------------------
def train():
    log(f'\n{"="*50}')
    log(f'Model {args.model_num}: {model_name} ({model_key})')
    log(f'Device: {DEVICE} | epochs: {args.epochs} | '
        f'batch: {args.batch_size} | lr: {args.lr} | wd: {args.weight_decay}')
    log(f'{"="*50}\n')

    train_loader, val_loader = build_dataloaders(args.model_num)

    model     = get_model(model_key)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(),
                            lr=args.lr, weight_decay=args.weight_decay)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)

    best_recall = 0.0
    history = {'train_loss': [], 'val_acc': [], 'val_recall': []}

    for epoch in range(args.epochs):

        # --- Train ---
        model.train()
        running_loss = 0.0
        for images, labels in tqdm(train_loader,
                                   desc=f'[{epoch+1}/{args.epochs}] Train'):
            images, labels = images.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()
            loss = criterion(model(images), labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        train_loss = running_loss / len(train_loader)
        scheduler.step()

        # --- Validation ---
        model.eval()
        all_labels, all_preds = [], []
        with torch.no_grad():
            for images, labels in tqdm(val_loader, desc='Val'):
                outputs = model(images.to(DEVICE))
                _, preds = torch.max(outputs, 1)
                all_labels.extend(labels.cpu().numpy())
                all_preds.extend(preds.cpu().numpy())

        acc    = accuracy_score(all_labels, all_preds)
        recall = recall_score(all_labels, all_preds, zero_division=0)

        history['train_loss'].append(train_loss)
        history['val_acc'].append(acc)
        history['val_recall'].append(recall)

        log(f'[Epoch {epoch+1:02d}/{args.epochs}] '
            f'Loss: {train_loss:.4f} | '
            f'Acc: {acc:.4f} | '
            f'Recall: {recall:.4f}')

        # --- Best 모델 저장 ---
        if recall > best_recall:
            best_recall = recall
            save_path = os.path.join(
                SAVE_DIR, f'model{args.model_num}_{model_key}_best.pth')
            torch.save(model.state_dict(), save_path)
            log(f'  → Best model saved (Recall: {best_recall:.4f})')

    log(f'\n학습 완료 | Best Recall: {best_recall:.4f}')
    save_plots(history, args.model_num, model_key)


if __name__ == '__main__':
    train()