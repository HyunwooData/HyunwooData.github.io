`timescale 1ns / 1ps

module Single_PE(
    input clk, rst, pe_active,
    
    input [7:0] a11, a12, a13, a14,
                a21, a22, a23, a24,
                a31, a32, a33, a34,
                a41, a42, a43, a44,

    input [7:0] b11, b12, b13,
                b21, b22, b23,
                b31, b32, b33,
   
    output reg s_active,
    output reg [7:0] s_c11, s_c12, s_c21, s_c22,
    output reg pe_done
    //output [7:0] pe_out
);

    localparam  S0=0,  S1=1,  S2=2,  S3=3,  S4=4,  S5=5,  S6=6,  S7=7,  S8=8,  S9=9,
                S10=10,S11=11,S12=12,S13=13,S14=14,S15=15,S16=16,S17=17,S18=18,S19=19,
                S20=20,S21=21,S22=22,S23=23,S24=24,S25=25,S26=26,S27=27,S28=28,S29=29,
                S30=30,S31=31,S32=32,S33=33,S34=34,S35=35,S36=36,S37=37,S38=38; 
    
    wire [7:0] sum;
    wire [7:0] acc_sum;
    reg acc_active; 
    
    reg [7:0] matrix_in;
    reg [7:0] filter_in;

    reg [5:0] state, next_state;            
    
    PE pe (
      .clk          (clk),
      .rst          (rst),
      .filter_active(1'b1),
      .matrix_active(1'b1),
      .sum_active   (1'b1),
      .sum_in       (acc_sum),
      .matrix_in    (matrix_in),
      .filter_in    (filter_in),
      .matrix_out   (),
      .filter_out   (),
      .sum_out      (sum)
    );  
    
    assign acc_sum = (acc_active) ? sum : 8'd0;
    //assign pe_out  = sum;
  
    always @(posedge clk) begin
      if (rst) begin
          state <= S0;
      end else begin
          state <= next_state;
      end
    end
    
    always @(*) begin
        next_state = state;

        acc_active   = 1'b0; 
        s_active = 1'b0;
        pe_done      = 1'b0;
        matrix_in    = 8'd0;
        filter_in    = 8'd0;
        
        case (state)
            S0: begin
                if (pe_active) 
                    next_state = S1;
                end
            S1: begin
                next_state = S2;
                end
            
            // C11
            S2: begin
                next_state = S3;
                acc_active = 1'b0;
                matrix_in  = a11;
                filter_in  = b33;
            end
            S3: begin
                next_state = S4;
                acc_active = 1'b1;
                matrix_in  = a12;
                filter_in  = b32;
            end
            S4: begin
                next_state = S5;
                acc_active = 1'b1;
                matrix_in  = a13;
                filter_in  = b31;
            end
            S5: begin
                next_state = S6;
                acc_active = 1'b1;
                matrix_in  = a21;
                filter_in  = b23;
            end
            S6: begin
                next_state = S7;
                acc_active = 1'b1;
                matrix_in  = a22;
                filter_in  = b22;
            end
            S7: begin
                next_state = S8;
                acc_active = 1'b1;
                matrix_in  = a23;
                filter_in  = b21;
            end
            S8: begin
                next_state = S9;
                acc_active = 1'b1;
                matrix_in  = a31;
                filter_in  = b13;
            end
            S9: begin
                next_state = S10;
                acc_active = 1'b1;
                matrix_in  = a32;
                filter_in  = b12;
            end
            S10: begin
                next_state = S11;
                acc_active = 1'b1;
                matrix_in  = a33;
                filter_in  = b11;
            end
      
            S11: begin
                next_state = S12;
                acc_active = 1'b0;
                //serial_active = 1'b1;
                s_c11 <= sum;
                matrix_in  = a12;
                filter_in  = b33;
            end

            // C12
            S12: begin
                next_state = S13;
                acc_active = 1'b1;
                matrix_in  = a13;
                filter_in  = b32;
            end
            S13: begin
                next_state = S14;
                acc_active = 1'b1;
                matrix_in  = a14;
                filter_in  = b31;
            end
            S14: begin
                next_state = S15;
                acc_active = 1'b1;
                matrix_in  = a22;
                filter_in  = b23;
            end
            S15: begin
                next_state = S16;
                acc_active = 1'b1;
                matrix_in  = a23;
                filter_in  = b22;
            end
            S16: begin
                next_state = S17;
                acc_active = 1'b1;
                matrix_in  = a24;
                filter_in  = b21;
            end
            S17: begin
                next_state = S18;
                acc_active = 1'b1;
                matrix_in  = a32;
                filter_in  = b13;
            end
            S18: begin
                next_state = S19;
                acc_active = 1'b1;
                matrix_in  = a33;
                filter_in  = b12;
            end
            S19: begin
                next_state = S20;
                acc_active = 1'b1;
                matrix_in  = a34;
                filter_in  = b11;
            end

            S20: begin
                next_state = S21;
                acc_active = 1'b0;
                //serial_active = 1'b1;
                s_c12 <= sum;
                matrix_in  = a21;
                filter_in  = b33;
            end

            // C21
            S21: begin
                next_state = S22;
                acc_active = 1'b1;
                matrix_in  = a22;
                filter_in  = b32;
            end
            S22: begin
                next_state = S23;
                acc_active = 1'b1;
                matrix_in  = a23;
                filter_in  = b31;
            end
            S23: begin
                next_state = S24;
                acc_active = 1'b1;
                matrix_in  = a31;
                filter_in  = b23;
            end
            S24: begin
                next_state = S25;
                acc_active = 1'b1;
                matrix_in  = a32;
                filter_in  = b22;
            end
            S25: begin
                next_state = S26;
                acc_active = 1'b1;
                matrix_in  = a33;
                filter_in  = b21;
            end
            S26: begin
                next_state = S27;
                acc_active = 1'b1;
                matrix_in  = a41;
                filter_in  = b13;
            end
            S27: begin
                next_state = S28;
                acc_active = 1'b1;
                matrix_in  = a42;
                filter_in  = b12;
            end
            S28: begin
                next_state = S29;
                acc_active = 1'b1;
                matrix_in  = a43;
                filter_in  = b11;
            end

            S29: begin
                next_state = S30;
                acc_active = 1'b0;
                //serial_active = 1'b1;
                s_c21 <= sum;
                matrix_in  = a22;
                filter_in  = b33;
            end

            // C22
            S30: begin
                next_state = S31;
                acc_active = 1'b1;
                matrix_in  = a23;
                filter_in  = b32;
            end
            S31: begin
                next_state = S32;
                acc_active = 1'b1;
                matrix_in  = a24;
                filter_in  = b31;
            end
            S32: begin
                next_state = S33;
                acc_active = 1'b1;
                matrix_in  = a32;
                filter_in  = b23;
            end
            S33: begin
                next_state = S34;
                acc_active = 1'b1;
                matrix_in  = a33;
                filter_in  = b22;
            end
            S34: begin
                next_state = S35;
                acc_active = 1'b1;
                matrix_in  = a34;
                filter_in  = b21;
            end
            S35: begin
                next_state = S36;
                acc_active = 1'b1;
                matrix_in  = a42;
                filter_in  = b13;
            end
            S36: begin
                next_state = S37;
                acc_active = 1'b1;
                matrix_in  = a43;
                filter_in  = b12;
            end
            S37: begin
                next_state = S38;
                acc_active = 1'b1;
                matrix_in  = a44;
                filter_in  = b11;
            end
         
            S38: begin
                next_state = S0;
                s_active = 1'b1;
                s_c22 <= sum;
                pe_done    = 1'b1;
            end
        endcase
    end
    
endmodule


