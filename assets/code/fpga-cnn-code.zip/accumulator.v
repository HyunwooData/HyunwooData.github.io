`timescale 1ns / 1ps

module Accumulator( 
  input clk, rst, active,
  input [7:0] in,
  output reg [7:0] out
);

always @(posedge clk)
  begin
    if(rst)
      out <= 0;
    else if(active)
      out <= out + in;
    else
      out <= out;
  end

endmodule