`timescale 1ns / 1ps

module in_shift_register(
  input clk, rst,
  input active, shift, 
  input [63:0] in, 
  output [7:0] out
);

reg [63:0] buffer;

assign out = buffer[7:0];

always @(posedge clk or posedge rst) begin
  if (rst) begin
    buffer <= 64'd0;
  end
  else if (active) begin
    buffer <= in;
  end
  else if (shift) begin
    buffer <= {8'd0, buffer[63:8]};
  end
end

endmodule
