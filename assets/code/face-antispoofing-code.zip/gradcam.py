"""
GradCAM++ 시각화
- 3개 모델(ConvNeXt-Small, EfficientNetV2-M, EfficientNetB0)에 대해
  real/fake 샘플 각각 N장을 뽑아 GradCAM++ 히트맵을 저장
- 설치: pip install grad-cam

저장 결과 예시:
  gradcam/model1_convnext_small/real_0.png
  gradcam/model1_convnext_small/fake_0.png
  gradcam/model2_efficientnet_v2_m/real_0.png
  ...
"""

import os
import cv2
import numpy as np
import torch
import torch.nn as nn
from torchvision import models
import matplotlib.pyplot as plt
from pytorch_grad_cam import GradCAMPlusPlus
from pytorch_grad_cam.utils.image import show_cam_on_image
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget

from dataset import (
    get_val_transforms,
    get_combined_dataset,
    CelebASpoofDataset,
    ROIDataset
)

# ----------------------------------------------------------------
# 경로 설정
# ----------------------------------------------------------------
CELEBA_ROOT    = '/workspace/Project/CelebA_Crop'
CELEBA_VAL_TXT = '/workspace/Project/CelebA_Spoof/metas/intra_test/test_label.txt'
OULU_ROOT      = '/workspace/Project/Oulu-NPU'
CKPT_DIR       = '/workspace/Project/checkpoints'
SAVE_DIR       = '/workspace/Project/gradcam'

CKPT = {
    1: os.path.join(CKPT_DIR, 'model1_convnext_small_best.pth'),
    2: os.path.join(CKPT_DIR, 'model2_efficientnet_v2_m_best.pth'),
    3: os.path.join(CKPT_DIR, 'model3_efficientnet_b0_best.pth'),
}

DEVICE   = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
IMG_SIZE = 224
N_SAMPLES = 5   # real/fake 각각 몇 장씩 시각화할지

# ----------------------------------------------------------------
# 모델 로드 + target layer 지정
# ----------------------------------------------------------------
# GradCAM++은 마지막 Conv layer의 activation map을 사용
# 각 모델마다 어느 레이어를 쓸지 지정해야 함
#
# ConvNeXt-Small   : features[-1][-1]  (마지막 ConvNeXt 블록)
# EfficientNetV2-M : features[-1]      (마지막 MBConv 블록)
# EfficientNetB0   : features[-1]      (마지막 MBConv 블록)
# ----------------------------------------------------------------

def load_model_with_target(model_num):
    if model_num == 1:
        model = models.convnext_small(weights=None)
        model.classifier[2] = nn.Linear(model.classifier[2].in_features, 2)
        # ConvNeXt는 features[-1][-1]이 마지막 stage의 마지막 블록
        target_layers = [model.features[-1][-1]]

    elif model_num == 2:
        model = models.efficientnet_v2_m(weights=None)
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, 2)
        target_layers = [model.features[-1]]

    elif model_num == 3:
        model = models.efficientnet_b0(weights=None)
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, 2)
        target_layers = [model.features[-1]]

    ckpt = CKPT[model_num]
    if not os.path.exists(ckpt):
        raise FileNotFoundError(f'체크포인트 없음: {ckpt}')
    model.load_state_dict(torch.load(ckpt, map_location=DEVICE))
    model.to(DEVICE).eval()

    return model, target_layers


# ----------------------------------------------------------------
# 샘플 수집
# - val dataset에서 real/fake 각각 N장을 원본 numpy 이미지와 함께 반환
# ----------------------------------------------------------------

def collect_samples(dataset, n=5):
    """
    dataset의 __getitem__이 (tensor, label)을 반환한다고 가정
    원본 시각화를 위해 transform 없이 별도로 이미지도 읽어야 함
    → transform=None인 base dataset과 transform 적용 dataset을 함께 씀
    """
    real_tensors, real_imgs = [], []
    fake_tensors, fake_imgs = [], []

    val_tf = get_val_transforms(IMG_SIZE)

    for i in range(len(dataset)):
        if len(real_tensors) >= n and len(fake_tensors) >= n:
            break

        tensor, label = dataset[i]
        label = int(label)

        # 원본 이미지 (히트맵 오버레이용, 0~1 float RGB)
        # tensor는 이미 normalize된 상태라 역변환 필요
        raw = denormalize(tensor)  # (H, W, 3) float32 0~1

        if label == 0 and len(real_tensors) < n:
            real_tensors.append(tensor)
            real_imgs.append(raw)
        elif label == 1 and len(fake_tensors) < n:
            fake_tensors.append(tensor)
            fake_imgs.append(raw)

    return (real_tensors, real_imgs), (fake_tensors, fake_imgs)


def denormalize(tensor):
    """
    ImageNet normalize 역변환 → (H, W, 3) float32 [0, 1]
    """
    mean = np.array([0.485, 0.456, 0.406])
    std  = np.array([0.229, 0.224, 0.225])
    img  = tensor.permute(1, 2, 0).cpu().numpy()
    img  = std * img + mean
    return np.clip(img, 0, 1).astype(np.float32)


# ----------------------------------------------------------------
# GradCAM++ 히트맵 생성 + 저장
# ----------------------------------------------------------------

def run_gradcam(model_num):
    model_keys = {1: 'convnext_small', 2: 'efficientnet_v2_m', 3: 'efficientnet_b0'}
    model_key  = model_keys[model_num]
    save_dir   = os.path.join(SAVE_DIR, f'model{model_num}_{model_key}')
    os.makedirs(save_dir, exist_ok=True)

    print(f'\n{"="*50}')
    print(f'Model {model_num}: {model_key}')

    # 모델 + target layer 로드
    model, target_layers = load_model_with_target(model_num)

    # 데이터셋 구성
    val_tf = get_val_transforms(IMG_SIZE)
    if model_num == 1:
        dataset = get_combined_dataset(
            CELEBA_ROOT, CELEBA_VAL_TXT, OULU_ROOT, val_tf, split='val')
    elif model_num == 2:
        base    = CelebASpoofDataset(CELEBA_ROOT, CELEBA_VAL_TXT, transform=None)
        dataset = ROIDataset(base, roi_type='wrinkle', transform=val_tf)
    elif model_num == 3:
        base    = CelebASpoofDataset(CELEBA_ROOT, CELEBA_VAL_TXT, transform=None)
        dataset = ROIDataset(base, roi_type='specular', transform=val_tf)

    # real/fake 샘플 수집
    (real_tensors, real_imgs), (fake_tensors, fake_imgs) = \
        collect_samples(dataset, n=N_SAMPLES)

    print(f'Real: {len(real_tensors)}장 | Fake: {len(fake_tensors)}장 수집 완료')

    # GradCAM++ 초기화
    cam = GradCAMPlusPlus(model=model, target_layers=target_layers)

    # real(0) / fake(1) 각각 처리
    for class_name, tensors, raw_imgs, target_idx in [
        ('real', real_tensors, real_imgs, 0),
        ('fake', fake_tensors, fake_imgs, 1),
    ]:
        for i, (tensor, raw) in enumerate(zip(tensors, raw_imgs)):
            input_tensor = tensor.unsqueeze(0).to(DEVICE)  # (1, C, H, W)
            targets      = [ClassifierOutputTarget(target_idx)]

            # GradCAM++ 히트맵 계산
            grayscale_cam = cam(input_tensor=input_tensor,
                                targets=targets)[0]  # (H, W)

            # 히트맵 오버레이
            visualization = show_cam_on_image(raw, grayscale_cam, use_rgb=True)

            # 원본 | 히트맵 나란히 저장
            _save_side_by_side(
                raw, visualization, grayscale_cam,
                save_path=os.path.join(save_dir, f'{class_name}_{i}.png'),
                title=f'Model {model_num} ({model_key}) | {class_name.upper()} sample {i}'
            )

    print(f'저장 완료 → {save_dir}')


def _save_side_by_side(raw, overlay, heatmap, save_path, title):
    """
    원본 이미지 / GradCAM++ 오버레이 / 히트맵만 → 3열로 저장
    """
    fig, axes = plt.subplots(1, 3, figsize=(12, 4))
    fig.suptitle(title, fontsize=11)

    axes[0].imshow(raw)
    axes[0].set_title('Original')
    axes[0].axis('off')

    axes[1].imshow(overlay)
    axes[1].set_title('GradCAM++')
    axes[1].axis('off')

    axes[2].imshow(heatmap, cmap='jet')
    axes[2].set_title('Heatmap only')
    axes[2].axis('off')

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()


# ----------------------------------------------------------------
# 메인
# ----------------------------------------------------------------
if __name__ == '__main__':
    # 설치 확인
    try:
        import pytorch_grad_cam
    except ImportError:
        print('pytorch-grad-cam이 설치되어 있지 않습니다.')
        print('설치: pip install grad-cam')
        exit(1)

    for model_num in [1, 2, 3]:
        run_gradcam(model_num)

    print(f'\n전체 완료 → {SAVE_DIR}')