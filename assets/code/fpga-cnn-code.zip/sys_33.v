`timescale 1ns / 1ps

module sys_33(
  input clk, rst, sys33_active,

  input [7:0] a11, a12, a13, a14,
              a21, a22, a23, a24,
              a31, a32, a33, a34,
              a41, a42, a43, a44,

  input [7:0] b11, b12, b13,
             	b21, b22, b23,
             	b31, b32, b33,
             	
  output [7:0] c1, c2, c3, c4,

  output reg sys33_done
);

reg [5:0] state, next_state;
localparam  S0  =  0, S1  =  1, S2  =  2, S3  =  3,
      	     S4  =  4, S5  =  5, S6  =  6, S7  =  7,
      	     S8  =  8, S9  =  9, S10 = 10, S11 = 11,
      	     
S12 = 12, S13 = 13, S14 = 14, S15 = 15,
      	     
S16 = 16;
    
reg [5:0] cnt;    
reg cnt_active; 
reg cnt_rst;

reg buffer_active;
reg [3:0] acc_active; 

reg [2:0] in_shift;
reg w_shift;

reg [7:0] c11, c12, c21, c22;
wire [7:0] sum1, sum2, sum3;

wire [63:0] matrix_buffer1, matrix_buffer2, matrix_buffer3;
wire [23:0] filter_buffer1, filter_buffer2, filter_buffer3;

wire [7:0] pipe_row1 [2:0];
wire [7:0] pipe_row2 [2:0];
wire [7:0] pipe_row33 [2:0];
wire [7:0] pipe_col1 [2:0];
wire [7:0] pipe_col2 [2:0];
wire [7:0] pipe_col3[2:0];
wire [7:0] pipe_sum1 [2:0];
wire [7:0] pipe_sum2 [2:0];
wire [7:0] pipe_sum3 [2:0];

in_shift_register append_pipe_row1(.clk(clk), .rst(rst), .active(buffer_active), .shift(in_shift[0]), .in(matrix_buffer1), .out(pipe_row1[0]));
in_shift_register append_pipe_row2(.clk(clk), .rst(rst), .active(buffer_active), .shift(in_shift[1]), .in(matrix_buffer2), .out(pipe_row2[0]));
in_shift_register append_pipe_row3(.clk(clk), .rst(rst), .active(buffer_active), .shift(in_shift[2]), .in(matrix_buffer3), .out(pipe_row33[0]));

w_shift_register append_pipe_col1(.clk(clk), .rst(rst), .active(buffer_active), .shift(w_shift) ,.in(filter_buffer1), .out(pipe_col1[0]));
w_shift_register append_pipe_col2(.clk(clk), .rst(rst), .active(buffer_active), .shift(w_shift) ,.in(filter_buffer2), .out(pipe_col2[0]));
w_shift_register append_pipe_col3(.clk(clk), .rst(rst), .active(buffer_active), .shift(w_shift) ,.in(filter_buffer3), .out(pipe_col3[0]));

PE pe_11(
    .clk          (clk),
    .rst          (rst),
    .filter_active(w_shift),
    .matrix_active(in_shift[0]),
    .sum_active   (in_shift[0]),

    .sum_in       (8'd0),
    .matrix_in    (pipe_row1[0]),
    .filter_in    (pipe_col1[0]),

    .matrix_out   (pipe_row1[1]),
    .filter_out   (pipe_col1[1]),
    .sum_out      (pipe_sum1[1])
);   

PE pe_12 (
    .clk          (clk),
    .rst          (rst),
    .filter_active(w_shift),
    .matrix_active(in_shift[0]),
    .sum_active   (in_shift[0]),

    .sum_in       (8'd0),
    .matrix_in    (pipe_row1[1]),
    .filter_in    (pipe_col2[0]),

    .matrix_out   (pipe_row1[2]),
    .filter_out   (pipe_col2[1]),
    .sum_out      (pipe_sum2[1])
);
    
PE pe_13 (
    .clk          (clk),
    .rst          (rst),
    .filter_active(w_shift),
    .matrix_active(in_shift[0]),
    .sum_active   (in_shift[0]),

    .sum_in       (8'd0),
    .matrix_in    (pipe_row1[2]),
    .filter_in    (pipe_col3[0]),

    .matrix_out   (),
    .filter_out   (pipe_col3[1]),
    .sum_out      (pipe_sum3[1])
);
    
    
PE pe_21 (
    .clk          (clk),
    .rst          (rst),
    .filter_active(w_shift),
    .matrix_active(in_shift[1]),
    .sum_active   (in_shift[1]),

    .sum_in       (pipe_sum1[1]),
    .matrix_in    (pipe_row2[0]),
    .filter_in    (pipe_col1[1]),

    .matrix_out   (pipe_row2[1]),
    .filter_out   (pipe_col1[2]),
    .sum_out      (pipe_sum1[2])
);   
    
PE pe_22 (
    .clk          (clk),
    .rst          (rst),
    .filter_active(w_shift),
    .matrix_active(in_shift[1]),
    .sum_active   (in_shift[1]),

    .sum_in       (pipe_sum2[1]),
    .matrix_in    (pipe_row2[1]),
    .filter_in    (pipe_col2[1]),

    .matrix_out   (pipe_row2[2]),
    .filter_out   (pipe_col2[2]),
    .sum_out      (pipe_sum2[2])
);
    
PE pe_23 (
    .clk          (clk),
    .rst          (rst),
    .filter_active(w_shift),
    .matrix_active(in_shift[1]),
    .sum_active   (in_shift[1]),

    .sum_in       (pipe_sum3[1]),
    .matrix_in    (pipe_row2[2]),
    .filter_in    (pipe_col3[1]),

    .matrix_out   (),
    .filter_out   (pipe_col3[2]),
    .sum_out      (pipe_sum3[2])
);
    
  
PE pe_31 (
    .clk          (clk),
    .rst          (rst),
    .filter_active(w_shift),
    .matrix_active(in_shift[2]),
    .sum_active   (in_shift[2]),

    .sum_in       (pipe_sum1[2]),
    .matrix_in    (pipe_row33[0]),
    .filter_in    (pipe_col1[2]),

    .matrix_out   (pipe_row33[1]),
    .filter_out   (),
    .sum_out      (sum1)
);   
    
PE pe_32 (
    .clk          (clk),
    .rst          (rst),
    .filter_active(w_shift),
    .matrix_active(in_shift[2]),
    .sum_active   (in_shift[2]),

    .sum_in       (pipe_sum2[2]),
    .matrix_in    (pipe_row33[1]),
    .filter_in    (pipe_col2[2]),

    .matrix_out   (pipe_row33[2]),
    .filter_out   (),
    .sum_out      (sum2)
);

PE pe_33 (
    .clk          (clk),
    .rst          (rst),
    .filter_active(w_shift),
    .matrix_active(in_shift[2]),
    .sum_active   (in_shift[2]),

    .sum_in       (pipe_sum3[2]),
    .matrix_in    (pipe_row33[2]),
    .filter_in    (pipe_col3[2]),

    .matrix_out   (),
    .filter_out   (),
    .sum_out      (sum3)
);

Accumulator acc_c1(.clk(clk), .rst(rst), .active(acc_active[3]), .in(c11), .out(c1)); 
Accumulator acc_c2(.clk(clk), .rst(rst), .active(acc_active[2]), .in(c12), .out(c2));
Accumulator acc_c3(.clk(clk), .rst(rst), .active(acc_active[1]), .in(c21), .out(c3));
Accumulator acc_c4(.clk(clk), .rst(rst), .active(acc_active[0]), .in(c22), .out(c4));

assign matrix_buffer1 = {a24,a23,a22,a21,a14,a13,a12,a11};
assign matrix_buffer2 = {a34,a33,a32,a31,a24,a23,a22,a21};
assign matrix_buffer3 = {a44,a43,a42,a41,a34,a33,a32,a31};

assign filter_buffer1 = {b33,b23,b13};
assign filter_buffer2 = {b32,b22,b12};
assign filter_buffer3 = {b31,b21,b11};


always @(posedge clk) begin
  if (cnt_rst) begin
    cnt <= 0;
  end
  else if (cnt_active) begin
    cnt <= cnt + 1;
  end
end    

always @(posedge clk) begin
  if (rst) begin
    state   <= S0;
  end
  else begin
    state <= next_state;
  end
end

always @(*) begin
        next_state = state;
        
        cnt_rst=1'b0;
        
cnt_active=1'b0;
        

        acc_active=4'b0000; 
        buffer_active=1'b0;
            
        in_shift=3'b000;
        w_shift=1'b0;
        
        sys33_done=1'b0;
        
        c11=8'd0;
        c12=8'd0;
        c21=8'd0;
        c22=8'd0;
        
        case (state)
            S0: begin
               if (sys33_active) 
                 next_state = S1;
            end
            
            S1: begin  
                buffer_active = 1'b1;
                cnt_rst       = 1'b1;
                next_state    = S2;
            end
            
             S2: begin                
                cnt_active = 1'b1;
                w_shift    = 1'b1;
                if(cnt == 2) begin
                    next_state = S3;
                end
             end
            
             S3: begin
                in_shift   = 3'b001;
                cnt_rst    = 1'b1;
                next_state = S4;
             end
             
             S4: begin
                in_shift   = 3'b011;
                next_state = S5;
             end
            
             S5: begin
                in_shift   = 3'b111;
                next_state = S6;
             end
             
             S6: begin
                in_shift   = 3'b111;
                acc_active = 4'b1000;
                c11       	= sum1;
                next_state = S7;
             end    
               
             S7: begin
                in_shift   = 3'b111;
                acc_active = 4'b0100;
                c12       	= sum1;
                next_state = S8;
             end
             
             S8: begin
                in_shift   = 3'b111;
                acc_active = 4'b1000;
                c11        = sum2;
                next_state = S9;
             end
              
             S9: begin
                in_shift   = 3'b111;
                acc_active = 4'b0100;
                c12        = sum2;
                next_state = S10;
             end
            
             S10: begin
                in_shift   = 3'b111;
                acc_active = 4'b1010;
                c21        = sum1;
                c11 	      = sum3;
                next_state = S11;
             end
              
             S11: begin
                in_shift   = 3'b111;
                acc_active = 4'b0101;
                c22        = sum1;
                c12        = sum3;
                next_state = S12;
             end
             
             S12: begin
                in_shift   = 3'b111;
                acc_active = 4'b0010;
                c21        = sum2;   
                next_state = S13;
             end
            
             S13: begin
                in_shift   = 3'b111;
                acc_active = 4'b0001;
                c22        = sum2;
                next_state = S14;
             end
             
             S14: begin
                in_shift   = 3'b111;
                acc_active =  4'b0010;
                c21        = sum3;
                next_state = S15;
             end
            
             S15: begin
                in_shift   = 3'b111;
                acc_active = 4'b0001;
                c22        = sum3;
                next_state = S16;
             end
               
             S16: begin
                sys33_done = 1'b1;
                next_state = S0;
             end
          endcase   
end

endmodule

