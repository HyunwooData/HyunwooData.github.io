`timescale 1ns / 1ps

module w_shift_register(
  input clk, rst,
  input active, shift, 
  input [23:0] in, 
  output [7:0] out
);

reg [23:0] buffer;

assign out = buffer[7:0];

always @(posedge clk or posedge rst) begin
  if (rst) begin
    buffer <= 24'd0;
  end
  else if (active) begin
    buffer <= in;
  end
  else if (shift) begin
    buffer <= {8'd0, buffer[23:8]};
  end
end

endmodule
