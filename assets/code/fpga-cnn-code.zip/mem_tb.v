`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
//
// Create Date: 2024.12.02
// Design Name: mem_tb.v
// Module Name: mem_tb
// Description: 
//      Testbench for Memory module.
//
//////////////////////////////////////////////////////////////////////////////////

module mem_tb;

  reg clk, rst;
  reg mem_active;
  reg process_inactive;        // shutdown? ??? ??

  //reg s_out1_en, s_out2_en, s_out3_en, s_out4_en;
  reg s_out_en;
  reg s33_out_en, s22_out_en;
  
  reg [7:0] a11, a12, a13, a14,
            a21, a22, a23, a24,
            a31, a32, a33, a34,
            a41, a42, a43, a44;
            
  reg [7:0] b11, b12, b13,
            b21, b22, b23,
            b31, b32, b33;
            
  reg [7:0] s_c11, s_c12, s_c21, s_c22;
  reg [7:0] s33_c11, s33_c12, s33_c21, s33_c22;
  reg [7:0] s22_c11, s22_c12, s22_c21, s22_c22;

  // A/B ???? ?? ??
  reg [3:0] a_reg_num, b_reg_num;

  /* ------------------------------------------ Assign W/R -------------------------------------------------- */

  wire [7:0] a11_out, a12_out, a13_out, a14_out,
             a21_out, a22_out, a23_out, a24_out,
             a31_out, a32_out, a33_out, a34_out,
             a41_out, a42_out, a43_out, a44_out;
           
  wire [7:0] b11_out, b12_out, b13_out,
             b21_out, b22_out, b23_out,
             b31_out, b32_out, b33_out;
             
  wire [7:0] s_c11_out,  s_c12_out,  s_c21_out,  s_c22_out;	
  wire [7:0] s33_c11_out, s33_c12_out, s33_c21_out, s33_c22_out;
  wire [7:0] s22_c11_out, s22_c12_out, s22_c21_out, s22_c22_out;

  wire [7:0] a_reg_out, b_reg_out;
  wire       mem_done;
	
  /* ------------------------------------------ Mapping memory port for mem_tb -------------------------------------------------- */

  Memory mem_test (
    .clk        (clk),
    .rst        (rst),
    .mem_active (mem_active),
    .shutdown   (process_inactive),

    // Enable signals for outputs
    //.s_out1_en  (s_out1_en),
    //.s_out2_en  (s_out2_en),
    //.s_out3_en  (s_out3_en),
    //.s_out4_en  (s_out4_en),
    .s_out_en (s_out_en),
    .s33_out_en (s33_out_en),
    .s22_out_en (s22_out_en),
    
    // 4x4 Input Matrix
    .a11(a11), .a12(a12), .a13(a13), .a14(a14), 
    .a21(a21), .a22(a22), .a23(a23), .a24(a24),
    .a31(a31), .a32(a32), .a33(a33), .a34(a34), 
    .a41(a41), .a42(a42), .a43(a43), .a44(a44),

    // 4x4 Output Matrix
    .a11_out(a11_out), .a12_out(a12_out), .a13_out(a13_out), .a14_out(a14_out),
    .a21_out(a21_out), .a22_out(a22_out), .a23_out(a23_out), .a24_out(a24_out),
    .a31_out(a31_out), .a32_out(a32_out), .a33_out(a33_out), .a34_out(a34_out),
    .a41_out(a41_out), .a42_out(a42_out), .a43_out(a43_out), .a44_out(a44_out),
    
    // 3x3 Kernel(Weight)
    .b11(b11), .b12(b12), .b13(b13), 
    .b21(b21), .b22(b22), .b23(b23), 
    .b31(b31), .b32(b32), .b33(b33),  
    
    // 3x3 Kernel Output(Weight)
    .b11_out(b11_out), .b12_out(b12_out), .b13_out(b13_out),
    .b21_out(b21_out), .b22_out(b22_out), .b23_out(b23_out), 
    .b31_out(b31_out), .b32_out(b32_out), .b33_out(b33_out),
    
    // Cout in & out port
    .s_c11(s_c11), .s_c12(s_c12), .s_c21(s_c21), .s_c22(s_c22), 
    .s33_c11(s33_c11), .s33_c12(s33_c12), .s33_c21(s33_c21), .s33_c22(s33_c22),
    .s22_c11(s22_c11), .s22_c12(s22_c12), .s22_c21(s22_c21), .s22_c22(s22_c22),
    
    .s_c11_out(s_c11_out), .s_c12_out(s_c12_out), .s_c21_out(s_c21_out), .s_c22_out(s_c22_out),
    .s33_c11_out(s33_c11_out), .s33_c12_out(s33_c12_out), .s33_c21_out(s33_c21_out), .s33_c22_out(s33_c22_out),  
    .s22_c11_out(s22_c11_out), .s22_c12_out(s22_c12_out), .s22_c21_out(s22_c21_out), .s22_c22_out(s22_c22_out),

    .a_reg_num (a_reg_num),
    .b_reg_num (b_reg_num),
    .a_reg_out (a_reg_out),
    .b_reg_out (b_reg_out),

    .mem_done  (mem_done)
  );

  /* ------------------------------------------ Clock generation -------------------------------------------------- */
  always #10 clk = ~clk; 

  /* ------------------------------------------ Control Stimulus -------------------------------------------------- */

  initial begin
    clk             = 1'b0;
    rst             = 1'b1;
    mem_active      = 1'b0;
    process_inactive= 1'b0;

    //s_out1_en   = 1'b0;
    //s_out2_en   = 1'b0;
    //s_out3_en   = 1'b0;
    //s_out4_en   = 1'b0;
    s_out_en = 1'b0;
    s33_out_en  = 1'b0;
    s22_out_en  = 1'b0;
    a_reg_num   = 4'd0;
    b_reg_num   = 4'd0;
 
    #11 rst        = 1'b0;
    #5  mem_active = 1'b1;   // ??? write ???

    #20
    mem_active  = 1'b0;
    //s_out1_en   = 1'b1;
    //s_out2_en   = 1'b1;
    //s_out3_en   = 1'b1;
    //s_out4_en   = 1'b1;
    s_out_en = 1'b1;
    s33_out_en  = 1'b1;
    s22_out_en  = 1'b1;
    
    a_reg_num   = 4'd0;  // a11_out
    b_reg_num   = 4'd0;  // b11_out
    #20
    a_reg_num   = 4'd5;  // a22_out
    b_reg_num   = 4'd4;  // b22_out
    #20
    a_reg_num   = 4'd10; // a33_out
    b_reg_num   = 4'd8;  // b33_out

    #20
    //s_out1_en   = 1'b0;
    //s_out2_en   = 1'b0;
    //s_out3_en   = 1'b0;
    //s_out4_en   = 1'b0;
    s_out_en = 1'b0;
    s33_out_en  = 1'b0;
    s22_out_en  = 1'b0;

    // ---- ???? process_inactive ?? ----
    #20 process_inactive = 1'b1;   // shutdown ??
    #20 process_inactive = 1'b0;   // ?? ?? ?? ??

    #20 $finish;
  end

  /* ------------------------------------------ Data Stimulus -------------------------------------------------- */

  initial begin
    a11 = 8'd1;   a12 = 8'd2;   a13 = 8'd3;   a14 = 8'd4;
    a21 = 8'd5;   a22 = 8'd6;   a23 = 8'd7;   a24 = 8'd8;
    a31 = 8'd9;   a32 = 8'd10;  a33 = 8'd11;  a34 = 8'd12;
    a41 = 8'd13;  a42 = 8'd14;  a43 = 8'd15;  a44 = 8'd16;

    b11 = 8'd1;  b12 = 8'd2;  b13 = 8'd3;
    b21 = 8'd4;  b22 = 8'd5;  b23 = 8'd6;
    b31 = 8'd7;  b32 = 8'd8;  b33 = 8'd9;
 
    #30
    s_c11   = 8'd30;  s_c12   = 8'd60;  s_c21   = 8'd151; s_c22   = 8'd109;
    s33_c11 = 8'd30;  s33_c12 = 8'd60;  s33_c21 = 8'd151; s33_c22 = 8'd109;
    s22_c11 = 8'd30;  s22_c12 = 8'd60;  s22_c21 = 8'd151; s22_c22 = 8'd109;
  end  

endmodule
