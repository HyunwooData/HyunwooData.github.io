import mysql.connector
from tkinter import *
import tkinter.messagebox as msgbox
from PIL import Image, ImageTk
import tkinter.ttk as ttk
import pandas as pd
import os
import pickle
from utils import *
from salaryprediction import Modelpredict
from query import *

defense, salary, runner, hitter, pitcher = file_import()
batter_model, pitcher_model = model_import()
data_list = [hitter, pitcher, runner, defense, salary]


# 데이터베이스 접속하기
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="khw1609##"
)
Cursor = mydb.cursor()


def use_database(name_database):
    '''Connect Database'''
    Cursor.execute('USE '+name_database)

def fetch(query):
    Cursor.execute(query)
    return Cursor.fetchall()

def fetchall_from_table(table):
    return fetch('SELECT * FROM '+table)

def func_sign_up(input_id,input_pw,input_nickname,input_name,input_phone):
    if len(input_id) == 0:
        msgbox.showwarning("Warning", "Enter your ID !")
    else:
        output_id = fetch("SELECT id FROM login WHERE id = '" + input_id + "'")
        if output_id != []:
            msgbox.showwarning("Warning", "The same ID already exists !")
        else:
            if len(input_pw) == 0:
                msgbox.showwarning("Warning", "Enter your Password !")
            else:
                if len(input_nickname) == 0:
                    msgbox.showwarning("Warning", "Enter your Nickname !")
                else:
                    output_nickname = fetch("SELECT nickname FROM login WHERE nickname = '" + input_nickname + "'")
                    if output_nickname != []:
                        msgbox.showwarning("Warning", "The same nickname already exists !")
                    else:
                        if len(input_name) == 0:
                            msgbox.showwarning("Warning", "Enter your Name !")
                        else:
                            if len(input_phone) == 0:
                                msgbox.showwarning("Warning", "Enter your Phone number !")
                            else:
                                judgement = 1
                                if len(input_phone) != 13:
                                    judgement = 0
                                if (input_phone[3] != '-') or (input_phone[8] != '-'):
                                    judgement = 0
                                if judgement == 0:
                                    msgbox.showwarning("Warning", "Wrong Phone number !")
                                else:
                                    str_sql = "INSERT INTO login(id, pw, nickname, name, phone, img) VALUES (%s, %s, %s, %s, %s, %s)"
                                    str_insert = input_id,input_pw,input_nickname,input_name,input_phone, 'icon1'
                                    Cursor.execute(str_sql, str_insert)
                                    mydb.commit()
                                    msgbox.showinfo("Sign Up", "Sign Up Successfully !")
                                    erase_child_with(page, 3)
                                    design_page_start("start")

def func_login(input_id, input_pw):
    output_info = fetch("SELECT * FROM login WHERE id = '{}'".format(input_id))
    if output_info == []:
        msgbox.showwarning("Warning", "Wrong ID !")
    else:
        if output_info[0][2] == input_pw:
            user_info.clear()
            without_idx = 0
            for info in output_info[0]:
                if without_idx != 0:
                    user_info.append(info)
                else:
                    user_info_6 = info
                without_idx += 1
            user_info.append(user_info_6)
            print(user_info)
            open_page_main()
        else:
            msgbox.showwarning("Warning", "Wrong Password !")

def func_find_id(input_name, input_phone):
    output_id = fetch("SELECT id FROM login WHERE name = '"+input_name+"' AND phone = '"+input_phone+"'")
    if output_id == []:
        msgbox.showwarning("Warning", "There is no ID with ( {} , {} )".format(input_name,input_phone))
    else:
        return_id = str(output_id[0][0])
        msgbox.showinfo("Find id", "Your ID is '"+return_id+"'")

def func_reset_pw(input_id, input_phone):
    output_pw = fetch("SELECT pw FROM login WHERE id = '" + input_id + "' AND phone = '" + input_phone + "'")
    if output_pw == []:
        msgbox.showwarning("Warning", "There is no Password with ( {} , {} )".format(input_id, input_phone))
    else:
        Cursor.execute("UPDATE login SET pw = 'password0' WHERE id = '"+input_id+"' AND phone = '"+input_phone+"'")
        mydb.commit()
        msgbox.showinfo("Reset Password", "Check your phone.\nYour new password has been sent.")

def func_change_BtnColor(btn1, btn2, btn3, btn4, btn_choice):
    btn_fg_list = ["#FFFFFF", "#FFFFFF", "#FFFFFF", "#FFFFFF", "#FFFFFF"]
    btn_bg_list = ["#4554C0", "#4554C0", "#4554C0", "#4554C0", "#4554C0"]
    btn_fg_list[btn_choice] = "#4554C0"
    btn_bg_list[btn_choice] = "#FFFFFF"

    btn1.configure(fg = btn_fg_list[1], bg = btn_bg_list[1])
    btn2.configure(fg=btn_fg_list[2], bg=btn_bg_list[2])
    btn3.configure(fg=btn_fg_list[3], bg=btn_bg_list[3])
    btn4.configure(fg=btn_fg_list[4], bg=btn_bg_list[4])

def func_change_PositionBtnColor(btn1, btn2, btn3, btn4, btn_choice):
    btn_fg_list = ["#FFFFFF", "#FFFFFF", "#FFFFFF", "#FFFFFF", "#FFFFFF"]
    btn_bg_list = ["#4554C0", "#4554C0", "#4554C0", "#4554C0", "#4554C0"]
    btn_fg_list[btn_choice] = "#4554C0"
    btn_bg_list[btn_choice] = "#FFFFFF"

    btn1.configure(fg = btn_fg_list[1], bg = btn_bg_list[1])
    btn2.configure(fg=btn_fg_list[2], bg=btn_bg_list[2])
    btn3.configure(fg=btn_fg_list[3], bg=btn_bg_list[3])
    btn4.configure(fg=btn_fg_list[4], bg=btn_bg_list[4])

def open_page_change_ProfileImage():
    page_img = Toplevel()
    page_img.title("PROFILE IMAGE")
    page_img.geometry("750x600+405+115")
    page_img.resizable = (False, False)

    page_img_frame = Frame(page_img, bg='#FFFFFF')
    page_img_frame.place(relx=0,rely=0,relheight=1,relwidth=1)

    global screen_frame

    ProfileImg1 = ImageTk.PhotoImage(Image.open("Image\icon1.png").resize((100, 100)))
    ProfileImg2 = ImageTk.PhotoImage(Image.open("Image\icon2.png").resize((100, 100)))
    ProfileImg3 = ImageTk.PhotoImage(Image.open("Image\icon3.png").resize((100, 100)))
    ProfileImg4 = ImageTk.PhotoImage(Image.open("Image\icon4.png").resize((100, 100)))
    ProfileImg5 = ImageTk.PhotoImage(Image.open("Image\icon5.png").resize((100, 100)))
    ProfileImg6 = ImageTk.PhotoImage(Image.open("Image\icon6.png").resize((100, 100)))
    ProfileImg7 = ImageTk.PhotoImage(Image.open("Image\icon7.png").resize((100, 100)))
    ProfileImg8 = ImageTk.PhotoImage(Image.open("Image\icon8.png").resize((100, 100)))
    ProfileImg9 = ImageTk.PhotoImage(Image.open("Image\icon9.png").resize((100, 100)))
    ProfileImg10 = ImageTk.PhotoImage(Image.open("Image\icon10.png").resize((100, 100)))
    ProfileImg11 = ImageTk.PhotoImage(Image.open("Image\icon11.png").resize((100, 100)))
    ProfileImg12 = ImageTk.PhotoImage(Image.open("Image\icon12.png").resize((100, 100)))
    ProfileImg13 = ImageTk.PhotoImage(Image.open("Image\icon13.png").resize((100, 100)))
    ProfileImg14 = ImageTk.PhotoImage(Image.open("Image\icon14.png").resize((100, 100)))
    ProfileImg15 = ImageTk.PhotoImage(Image.open("Image\icon15.png").resize((100, 100)))
    ProfileImg16 = ImageTk.PhotoImage(Image.open("Image\icon16.png").resize((100, 100)))
    ProfileImg17 = ImageTk.PhotoImage(Image.open("Image\icon17.png").resize((100, 100)))
    ProfileImg18 = ImageTk.PhotoImage(Image.open("Image\icon18.png").resize((100, 100)))
    ProfileImg19 = ImageTk.PhotoImage(Image.open("Image\icon19.png").resize((100, 100)))
    ProfileImg20 = ImageTk.PhotoImage(Image.open("Image\icon20.png").resize((100, 100)))
    PI_btn1 = Button(page_img_frame, image=ProfileImg1, command=lambda:(func_change_ProfileImg("icon1"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn2 = Button(page_img_frame, image=ProfileImg2, command=lambda:(func_change_ProfileImg("icon2"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn3 = Button(page_img_frame, image=ProfileImg3, command=lambda:(func_change_ProfileImg("icon3"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn4 = Button(page_img_frame, image=ProfileImg4, command=lambda:(func_change_ProfileImg("icon4"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn5 = Button(page_img_frame, image=ProfileImg5, command=lambda:(func_change_ProfileImg("icon5"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn6 = Button(page_img_frame, image=ProfileImg6, command=lambda:(func_change_ProfileImg("icon6"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn7 = Button(page_img_frame, image=ProfileImg7, command=lambda:(func_change_ProfileImg("icon7"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn8 = Button(page_img_frame, image=ProfileImg8, command=lambda:(func_change_ProfileImg("icon8"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn9 = Button(page_img_frame, image=ProfileImg9, command=lambda:(func_change_ProfileImg("icon9"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn10 = Button(page_img_frame, image=ProfileImg10, command=lambda:(func_change_ProfileImg("icon10"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn11 = Button(page_img_frame, image=ProfileImg11, command=lambda:(func_change_ProfileImg("icon11"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn12 = Button(page_img_frame, image=ProfileImg12, command=lambda:(func_change_ProfileImg("icon12"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn13 = Button(page_img_frame, image=ProfileImg13, command=lambda:(func_change_ProfileImg("icon13"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn14 = Button(page_img_frame, image=ProfileImg14, command=lambda:(func_change_ProfileImg("icon14"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn15 = Button(page_img_frame, image=ProfileImg15, command=lambda:(func_change_ProfileImg("icon15"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn16 = Button(page_img_frame, image=ProfileImg16, command=lambda:(func_change_ProfileImg("icon16"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn17 = Button(page_img_frame, image=ProfileImg17, command=lambda:(func_change_ProfileImg("icon17"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn18 = Button(page_img_frame, image=ProfileImg18, command=lambda:(func_change_ProfileImg("icon18"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn19 = Button(page_img_frame, image=ProfileImg19, command=lambda:(func_change_ProfileImg("icon19"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn20 = Button(page_img_frame, image=ProfileImg20, command=lambda:(func_change_ProfileImg("icon20"), page_img.destroy(), design_page_main_screen(4,screen_frame)))
    PI_btn1.place(relx=0,rely=0 ,relwidth=0.2,relheight=0.25)
    PI_btn2.place(relx=0.2, rely=0, relwidth=0.2, relheight=0.25)
    PI_btn3.place(relx=0.4, rely=0, relwidth=0.2, relheight=0.25)
    PI_btn4.place(relx=0.6, rely=0, relwidth=0.2, relheight=0.25)
    PI_btn5.place(relx=0.8, rely=0, relwidth=0.2, relheight=0.25)
    PI_btn6.place(relx=0, rely=0.25, relwidth=0.2, relheight=0.25)
    PI_btn7.place(relx=0.2, rely=0.25, relwidth=0.2, relheight=0.25)
    PI_btn8.place(relx=0.4, rely=0.25, relwidth=0.2, relheight=0.25)
    PI_btn9.place(relx=0.6, rely=0.25, relwidth=0.2, relheight=0.25)
    PI_btn10.place(relx=0.8, rely=0.25, relwidth=0.2, relheight=0.25)
    PI_btn11.place(relx=0, rely=0.5, relwidth=0.2, relheight=0.25)
    PI_btn12.place(relx=0.2, rely=0.5, relwidth=0.2, relheight=0.25)
    PI_btn13.place(relx=0.4, rely=0.5, relwidth=0.2, relheight=0.25)
    PI_btn14.place(relx=0.6, rely=0.5, relwidth=0.2, relheight=0.25)
    PI_btn15.place(relx=0.8, rely=0.5, relwidth=0.2, relheight=0.25)
    PI_btn16.place(relx=0, rely=0.75, relwidth=0.2, relheight=0.25)
    PI_btn17.place(relx=0.2, rely=0.75, relwidth=0.2, relheight=0.25)
    PI_btn18.place(relx=0.4, rely=0.75, relwidth=0.2, relheight=0.25)
    PI_btn19.place(relx=0.6, rely=0.75, relwidth=0.2, relheight=0.25)
    PI_btn20.place(relx=0.8, rely=0.75, relwidth=0.2, relheight=0.25)
    page_img.mainloop()

def func_change_ProfileImg(img_path):
    Cursor.execute("UPDATE login SET img = '"+img_path+"' WHERE id = '" + user_info[0] + "'")
    mydb.commit()
    user_info[5] = img_path
    msgbox.showinfo("Change Profile Image", "Profile Image was changed successfully !")


def func_search_stat(entry, cbbox1, cbbox2, frame1, frame2, frame3, frame4):
    erase_child_all(frame1)
    erase_child_all(frame2)
    erase_child_all(frame3)
    erase_child_all(frame4)

    result_df = multi_search_by_value(defense, ['선수명', 'Year', '팀명'], [entry, cbbox1, cbbox2])
    result_rn = multi_search_by_value(runner, ['선수명', 'Year', '팀명'], [entry, cbbox1, cbbox2])
    result_ht = multi_search_by_value(hitter, ['선수명', 'Year', '팀명'], [entry, cbbox1, cbbox2])
    result_pc = multi_search_by_value(pitcher, ['선수명', 'Year', '팀명'], [entry, cbbox1, cbbox2])
    if len(result_df) != 0:
        df_col = list(result_df.columns)
        df_row_temp = result_df.values
        df_row = []
        for i in range(len(df_row_temp)):
            df_row.append([])
        for row in range(len(df_row_temp)):
            for val in range(len(df_row_temp[row])):
                df_row[row].append(df_row_temp[row][val])
        del df_col[0]
        del df_col[0]
        for row in range(len(df_row)):
            del df_row[row][0]
            del df_row[row][0]
        N_col = len(df_col)
        N_row = len(df_row)
        for col in range(N_col):
            Label(frame1, text=df_col[col], bg="#FFFFFF", font=("Cambria", 9)).place(relx=(1/N_col)*col, relwidth=1/N_col, relheight=1/6, rely=0)
        for row in range(N_row):
            for val in range(N_col):
                Label(frame1, text=df_row[row][val], bg="#FFFFFF", font=("Cambria", 9)).place(relx=(1/N_col)*val, relwidth=1/N_col, relheight=1/6, rely=1/6*(row+1))

    if len(result_rn) != 0:
        rn_col = list(result_rn.columns)
        rn_row_temp = result_rn.values
        rn_row = []
        for i in range(len(rn_row_temp)):
            rn_row.append([])
        for row in range(len(rn_row_temp)):
            for val in range(len(rn_row_temp[row])):
                rn_row[row].append(rn_row_temp[row][val])
        del rn_col[0]
        del rn_col[0]
        for row in range(len(rn_row)):
            del rn_row[row][0]
            del rn_row[row][0]
        N_col = len(rn_col)
        N_row = len(rn_row)
        for col in range(N_col):
            Label(frame2, text=rn_col[col], bg="#FFFFFF", font=("Cambria", 9)).place(relx=(1 / N_col) * col, relwidth=1 / N_col, relheight=1 / 6, rely=0)
        for row in range(N_row):
            for val in range(N_col):
                Label(frame2, text=rn_row[row][val], bg="#FFFFFF", font=("Cambria", 9)).place(relx=(1 / N_col) * val, relwidth=1 / N_col, relheight=1 / 6, rely=1 / 6 * (row + 1))

    if len(result_ht) != 0:
        ht_col = list(result_ht.columns)
        ht_row_temp = result_ht.values
        ht_row = []
        for i in range(len(ht_row_temp)):
            ht_row.append([])
        for row in range(len(ht_row_temp)):
            for val in range(len(ht_row_temp[row])):
                ht_row[row].append(ht_row_temp[row][val])
        del ht_col[0]
        del ht_col[0]
        for row in range(len(ht_row)):
            del ht_row[row][0]
            del ht_row[row][0]
        N_col = len(ht_col)
        N_row = len(ht_row)
        for col in range(N_col):
            Label(frame3, text=ht_col[col], bg="#FFFFFF", font=("Cambria", 8)).place(relx=(1 / N_col) * col, relwidth=1 / N_col, relheight=1 / 6, rely=0)
        for row in range(N_row):
            for val in range(N_col):
                Label(frame3, text=ht_row[row][val], bg="#FFFFFF", font=("Cambria", 8)).place(relx=(1 / N_col) * val, relwidth=1 / N_col, relheight=1 / 6, rely=1 / 6 * (row + 1))

    if len(result_pc) != 0:
        pc_col = list(result_pc.columns)
        pc_row_temp = result_pc.values
        pc_row = []
        for i in range(len(pc_row_temp)):
            pc_row.append([])
        for row in range(len(pc_row_temp)):
            for val in range(len(pc_row_temp[row])):
                pc_row[row].append(pc_row_temp[row][val])
        del pc_col[0]
        del pc_col[0]
        for row in range(len(pc_row)):
            del pc_row[row][0]
            del pc_row[row][0]
        N_col = len(pc_col)
        N_row = len(pc_row)
        for col in range(N_col):
            Label(frame4, text=pc_col[col], bg="#FFFFFF", font=("Cambria", 9)).place(relx=(1 / N_col) * col, relwidth=1 / N_col, relheight=1 / 6, rely=0)
        for row in range(N_row):
            for val in range(N_col):
                Label(frame4, text=pc_row[row][val], bg="#FFFFFF", font=("Cambria", 9)).place(relx=(1 / N_col) * val, relwidth=1 / N_col, relheight=1 / 6, rely=1 / 6 * (row + 1))

def func_add_myplayer(entry, cbbox1, cbbox2):
    result_df = multi_search_by_value(defense, ['선수명', 'Year', '팀명'], [entry, cbbox1, cbbox2])
    result_rn = multi_search_by_value(runner, ['선수명', 'Year', '팀명'], [entry, cbbox1, cbbox2])
    result_ht = multi_search_by_value(hitter, ['선수명', 'Year', '팀명'], [entry, cbbox1, cbbox2])
    result_pc = multi_search_by_value(pitcher, ['선수명', 'Year', '팀명'], [entry, cbbox1, cbbox2])
    invalid_input = 1
    if len(result_df) != 0:
        invalid_input = 0
    if len(result_rn) != 0:
        invalid_input = 0
    if len(result_ht) != 0:
        invalid_input = 0
    if len(result_pc) != 0:
        invalid_input = 0

    if invalid_input == 0:
        str_sql = "INSERT INTO my_player(user_id, player_name, year_name, team_name) VALUES (%s, %s, %s, %s)"
        str_insert = user_info[6], entry, cbbox1, cbbox2
        Cursor.execute(str_sql, str_insert)
        mydb.commit()
        msgbox.showinfo("Add My Player", "Added to My Player Successfully !")
    else:
        msgbox.showwarning("Add My Player", "Wrong Input !")

def func_del_myplayer(i):
    data_my_players = fetch(
        "SELECT m.player_name, m.year_name, m.team_name FROM my_player m JOIN login l USING (user_id) WHERE l.id = '" +
        user_info[0] + "'")
    n = 1
    for row in data_my_players:
        if n == i:
            input_name = row[0]
            input_year = row[1]
            input_team = row[2]
        n += 1

    str_sql = "DELETE FROM my_player WHERE user_id = %s AND player_name  = %s AND year_name = %s AND team_name = %s"
    str_insert = user_info[6], input_name, input_year, input_team
    Cursor.execute(str_sql, str_insert)
    mydb.commit()
    msgbox.showinfo("Remove My Player", "Removed from My Player Successfully !")
    design_page_main_screen(4)




def func_search_salary(entry, cbbox1, cbbox2, label1):
    #print(entry, type(entry), cbbox1, type(cbbox1), cbbox2, type(cbbox2))
    A = Modelpredict(data_list)
    A.search_for_model_insert(entry, int(cbbox1), cbbox2)
    if len(A.indb) != 0:
        salary = A.indb.iloc[:,-2][0]
        predict_mode = 0
    else:
        try:
            salary = A.predict(batter_model, pitcher_model)
            predict_mode = 1
        except:
            predict_mode = -1

    if predict_mode == 0:
        text = f'{salary}(existing)'
    elif predict_mode == 1:
        text = f'{salary}(predicted)'
    elif predict_mode == -1:
        text = 'Cannot found the information. Try again'

    label1.configure(text=text)


def open_page_update_PersonalInfo():
    page_UPI = Toplevel()
    page_UPI.title("Personal Information")
    page_UPI.geometry("600x500+480+165")
    page_UPI.resizable = (False, False)

    UPI_frame = Frame(page_UPI, bg='#FFFFFF')
    UPI_frame.place(relx=0,rely=0,relheight=1,relwidth=1)

    UPI_label_id = Label(UPI_frame, text='ID', font=("Cambria", 15), fg="#4554C0", bg="#FFFFFF")
    UPI_label_pw = Label(UPI_frame, text='Password', font=("Cambria", 15), fg="#4554C0", bg="#FFFFFF")
    UPI_label_nickname = Label(UPI_frame, text='Nickname', font=("Cambria", 15), fg="#4554C0", bg="#FFFFFF")
    UPI_label_name = Label(UPI_frame, text='Name', font=("Cambria", 15), fg="#4554C0", bg="#FFFFFF")
    UPI_label_phone = Label(UPI_frame, text='Phone(with -)', font=("Cambria", 15), fg="#4554C0", bg="#FFFFFF")
    UPI_entry_id = Entry(UPI_frame, font=("Cambria", 14), width=20, justify="center", relief="solid")
    UPI_entry_pw = Entry(UPI_frame, font=("Cambria", 14), width=20, justify="center", relief="solid")
    UPI_entry_nickname = Entry(UPI_frame, font=("Cambria", 14), width=20, justify="center", relief="solid")
    UPI_entry_name = Entry(UPI_frame, font=("Cambria", 14), width=20, justify="center", relief="solid")
    UPI_entry_phone = Entry(UPI_frame, font=("Cambria", 14), width=20, justify="center", relief="solid")
    UPI_entry_id.insert(0,user_info[0])
    UPI_entry_pw.insert(0,user_info[1])
    UPI_entry_nickname.insert(0, user_info[2])
    UPI_entry_name.insert(0, user_info[3])
    UPI_entry_phone.insert(0, user_info[4])
    UPI_label_id.place(relx=0.05, rely=0.078, relheight=0.13, relwidth=0.4)
    UPI_entry_id.place(relx=0.45, rely=0.078, relheight=0.13, relwidth=0.4)
    UPI_label_pw.place(relx=0.05, rely=0.236, relheight=0.13, relwidth=0.4)
    UPI_entry_pw.place(relx=0.45, rely=0.236, relheight=0.13, relwidth=0.4)
    UPI_label_nickname.place(relx=0.05, rely=0.394, relheight=0.13, relwidth=0.4)
    UPI_entry_nickname.place(relx=0.45, rely=0.394, relheight=0.13, relwidth=0.4)
    UPI_label_name.place(relx=0.05, rely=0.552, relheight=0.13, relwidth=0.4)
    UPI_entry_name.place(relx=0.45, rely=0.552, relheight=0.13, relwidth=0.4)
    UPI_label_phone.place(relx=0.05, rely=0.71, relheight=0.13, relwidth=0.4)
    UPI_entry_phone.place(relx=0.45, rely=0.71, relheight=0.13, relwidth=0.4)

    UPI_btn_update = Button(UPI_frame, text='Update', font=("Cambria", 14), relief="ridge", fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda:(func_update_PersonalInfo(page_UPI, UPI_entry_id.get(), UPI_entry_pw.get(), UPI_entry_nickname.get(), UPI_entry_name.get(), UPI_entry_phone.get())))
    UPI_btn_back = Button(UPI_frame, text="Cancel", font=("Cambria", 14), relief="ridge", fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda:(page_UPI.destroy()))
    UPI_btn_update.place(relx=0.7, rely=0.9, relheight=0.06, relwidth=0.115)
    UPI_btn_back.place(relx=0.84, rely=0.9, relheight=0.06, relwidth=0.115)

    page_UPI.mainloop()

def func_update_PersonalInfo(page_UPI, id, pw, nickname, name, phone):
    curr_id = user_info[0]
    if id != user_info[0]:
        if len(id) == 0:
            msgbox.showwarning("Warning", "Enter Your ID !")
            return 0
        else:
            already_exist = fetch("SELECT id FROM login WHERE id = '" + id + "'")
            if already_exist != []:
                msgbox.showwarning("Warning", "The same ID already exists !")
                return 0

    if pw != user_info[1]:
        if len(pw) == 0:
            msgbox.showwarning("Warning", "Enter Your Password !")
            return 0

    if nickname != user_info[2]:
        if len(nickname) == 0:
            msgbox.showwarning("Warning", "Enter Your Nickname !")
            return 0
        else:
            already_exist = fetch("SELECT nickname FROM login WHERE nickname = '" + nickname + "'")
            if already_exist != []:
                msgbox.showwarning("Warning", "The same Nickname already exists !")
                return 0

    if name != user_info[3]:
        if len(name) == 0:
            msgbox.showwarning("Warning", "Enter Your Name !")
            return 0

    if phone != user_info[4]:
        if len(phone) == 0:
            msgbox.showwarning("Warning", "Enter Your ID !")
            return 0
        elif len(phone) != 13:
            msgbox.showwarning("Warning", "Wrong Phone Number !")
            return 0
        elif (phone[3] != '-') or (phone[8] != '-'):
            msgbox.showwarning("Warning", "Wrong Phone Number !")
            return 0

    Cursor.execute("UPDATE login SET id = '" + id + "' WHERE id = '" + curr_id + "'")
    Cursor.execute("UPDATE login SET pw = '" + pw + "' WHERE id = '" + id + "'")
    Cursor.execute("UPDATE login SET nickname = '" + nickname + "' WHERE id = '" + id + "'")
    Cursor.execute("UPDATE login SET name = '" + name + "' WHERE id = '" + id + "'")
    Cursor.execute("UPDATE login SET phone = '" + phone + "' WHERE id = '" + id + "'")
    user_info[0] = id
    user_info[1] = pw
    user_info[2] = nickname
    user_info[3] = name
    user_info[4] = phone
    mydb.commit()

    msgbox.showinfo("Update Profile Information", "Update Successfully !")
    page_UPI.destroy()

    global screen_frame
    design_page_main_screen(4, screen_frame)

def func_mini_stat(i):
    data_my_players = fetch("SELECT m.player_name, m.year_name, m.team_name FROM my_player m JOIN login l USING (user_id) WHERE l.id = '" +user_info[0] + "'")
    n = 1
    for row in data_my_players:
        if n == i:
            input_name = row[0]
            input_year = row[1]
            input_team = row[2]
        n += 1

    page_MP = Toplevel()
    page_MP.title("MY PLAYER")
    page_MP.geometry("1200x630+180+100")
    page_MP.resizable = (False, False)
    mini_frame = Frame(page_MP, bg="#E0E6F8")
    mini_frame.place(relx=0.01, rely=0.01, relheight=0.98, relwidth=0.98)

    mini_text1 = Label(mini_frame, text="Defense", font=("Cambria", 15), bg="#E0E6F8", fg="#4554C0", anchor='n')
    mini_text2 = Label(mini_frame, text="Runner", font=("Cambria", 15), bg="#E0E6F8", fg="#4554C0", anchor='n')
    mini_text3 = Label(mini_frame, text="Hitter", font=("Cambria", 15), bg="#E0E6F8", fg="#4554C0", anchor='n')
    mini_text4 = Label(mini_frame, text="Pitcher", font=("Cambria", 15), bg="#E0E6F8", fg="#4554C0", anchor='n')
    mini_text1.place(relx=0.01, rely=0.03, relheight=0.18, relwidth=0.09)
    mini_text2.place(relx=0.01, rely=0.245, relheight=0.18, relwidth=0.09)
    mini_text3.place(relx=0.01, rely=0.46, relheight=0.18, relwidth=0.09)
    mini_text4.place(relx=0.01, rely=0.685, relheight=0.18, relwidth=0.09)

    mini_result1 = Frame(mini_frame, bg='#FFFFFF')
    mini_result2 = Frame(mini_frame, bg='#FFFFFF')
    mini_result3 = Frame(mini_frame, bg='#FFFFFF')
    mini_result4 = Frame(mini_frame, bg='#FFFFFF')
    mini_result1.place(relx=0.1, rely=0.03, relheight=0.18, relwidth=0.88)
    mini_result2.place(relx=0.1, rely=0.245, relheight=0.18, relwidth=0.88)
    mini_result3.place(relx=0.1, rely=0.46, relheight=0.18, relwidth=0.88)
    mini_result4.place(relx=0.1, rely=0.685, relheight=0.18, relwidth=0.88)

    mini_btn = Button(mini_frame, text="Close", font=("Cambria", 14), relief="ridge", fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda:(page_MP.destroy()))
    mini_btn.place(relx=0.88, rely=0.91, relheight=0.06, relwidth=0.1)

    result_df = multi_search_by_value(defense, ['선수명', 'Year', '팀명'], [input_name, input_year, input_team])
    result_rn = multi_search_by_value(runner, ['선수명', 'Year', '팀명'], [input_name, input_year, input_team])
    result_ht = multi_search_by_value(hitter, ['선수명', 'Year', '팀명'], [input_name, input_year, input_team])
    result_pc = multi_search_by_value(pitcher, ['선수명', 'Year', '팀명'], [input_name, input_year, input_team])
    if len(result_df) != 0:
        df_col = list(result_df.columns)
        df_row = result_df.values
        N_col = len(df_col)
        N_row = len(df_row)
        for col in range(N_col):
            Label(mini_result1, text=df_col[col], bg="#FFFFFF", font=("Cambria", 9)).place(relx=(1 / N_col) * col,
                                                                                     relwidth=1 / N_col,
                                                                                     relheight=1 / 6, rely=0)
        for row in range(N_row):
            for val in range(N_col):
                Label(mini_result1, text=df_row[row][val], bg="#FFFFFF", font=("Cambria", 9)).place(relx=(1 / N_col) * val,
                                                                                              relwidth=1 / N_col,
                                                                                              relheight=1 / 6,
                                                                                              rely=1 / 6 * (row + 1))

    if len(result_rn) != 0:
        rn_col = result_rn.columns
        rn_row = result_rn.values
        N_col = len(rn_col)
        N_row = len(rn_row)
        for col in range(N_col):
            Label(mini_result2, text=rn_col[col], bg="#FFFFFF", font=("Cambria", 10)).place(relx=(1 / N_col) * col,
                                                                                     relwidth=1 / N_col,
                                                                                     relheight=1 / 6, rely=0)
        for row in range(N_row):
            for val in range(N_col):
                Label(mini_result2, text=rn_row[row][val], bg="#FFFFFF", font=("Cambria", 9)).place(relx=(1 / N_col) * val,
                                                                                              relwidth=1 / N_col,
                                                                                              relheight=1 / 6,
                                                                                              rely=1 / 6 * (row + 1))

    if len(result_ht) != 0:
        ht_col = result_ht.columns
        ht_row = result_ht.values
        N_col = len(ht_col)
        N_row = len(ht_row)
        for col in range(N_col):
            Label(mini_result3, text=ht_col[col], bg="#FFFFFF", font=("Cambria", 8)).place(relx=(1 / N_col) * col,
                                                                                     relwidth=1 / N_col,
                                                                                     relheight=1 / 6, rely=0)
        for row in range(N_row):
            for val in range(N_col):
                Label(mini_result3, text=ht_row[row][val], bg="#FFFFFF", font=("Cambria", 8)).place(relx=(1 / N_col) * val,
                                                                                              relwidth=1 / N_col,
                                                                                              relheight=1 / 6,
                                                                                              rely=1 / 6 * (row + 1))

    if len(result_pc) != 0:
        pc_col = result_pc.columns
        pc_row = result_pc.values
        N_col = len(pc_col)
        N_row = len(pc_row)
        for col in range(N_col):
            Label(mini_result4, text=pc_col[col], bg="#FFFFFF", font=("Cambria", 9)).place(relx=(1 / N_col) * col,
                                                                                     relwidth=1 / N_col,
                                                                                     relheight=1 / 6, rely=0)
        for row in range(N_row):
            for val in range(N_col):
                Label(mini_result4, text=pc_row[row][val], bg="#FFFFFF", font=("Cambria", 9)).place(relx=(1 / N_col) * val,
                                                                                              relwidth=1 / N_col,
                                                                                              relheight=1 / 6,
                                                                                              rely=1 / 6 * (row + 1))

    page_MP.mainloop()

def func_prev_page(label, frame, frame_to_delete, data_my_players):
    global mp_page_now
    global mp_page_total
    if mp_page_now == 1:
        msgbox.showwarning("No page", "This is the first page !")
    else:
        frame_to_delete.destroy()

        mp_page_now -= 1
        label.configure(text = str(mp_page_now)+"/"+str(mp_page_total))

        frame2 = Frame(frame, bg="#FFFFFF")
        frame2.place(relx=0.01, rely=0.02, relheight=0.96, relwidth=0.98)

        row = 1
        rows = 0
        row_size = 1 / 7
        for i in data_my_players:
            if ((mp_page_now - 1) * 7 + 1 <= row) & ((mp_page_now) * 7 + 1 > row):
                Label(frame2, text=str(row), font=("Cambria", 14), bg="#4554C0", fg="#FFFFFF").place(relx=0, rely=row_size * rows, relheight=row_size, relwidth=0.1)
                Label(frame2, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1, rely=row_size * rows, relheight=row_size, relwidth=0.2)
                Label(frame2, text=i[1], font=("Cambria", 14)).place(relx=0.3, rely=row_size * rows, relheight=row_size, relwidth=0.2)
                Label(frame2, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.5, rely=row_size * rows, relheight=row_size, relwidth=0.2)
                exec('Button(frame2, text="Stats", font=("Cambria",13), bg="#4554C0", fg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(func_mini_stat({}))).place(relx=0.78, rely={}+0.001, relheight={}-0.002, relwidth=0.15)'.format(row, row_size * rows, row_size))
                exec('Button(frame2, text="X", bg="#FF0000", fg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(func_del_myplayer({}))).place(relx=0.95, rely={}+0.03, relheight={}-0.06, relwidth=({}-0.06)/3)'.format(row, row_size * rows, row_size, row_size))
                rows += 1
            row += 1
    page.mainloop()

def func_next_page(label, frame, frame_to_delete, data_my_players):
    global mp_page_now
    global mp_page_total
    if mp_page_now == mp_page_total:
        msgbox.showwarning("No page", "This is the last page !")
    else:
        frame_to_delete.destroy()

        mp_page_now += 1
        label.configure(text=str(mp_page_now) + "/" + str(mp_page_total))

        frame2 = Frame(frame, bg="#FFFFFF")
        frame2.place(relx=0.01, rely=0.02, relheight=0.96, relwidth=0.98)

        row = 1
        rows = 0
        row_size = 1 / 7
        for i in data_my_players:
            if ((mp_page_now - 1) * 7 + 1 <= row)&((mp_page_now) * 7 + 1 > row):
                Label(frame2, text=str(row), font=("Cambria", 14), bg="#4554C0", fg="#FFFFFF").place(relx=0, rely=row_size * rows, relheight=row_size, relwidth=0.1)
                Label(frame2, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1, rely=row_size * rows, relheight=row_size, relwidth=0.2)
                Label(frame2, text=i[1], font=("Cambria", 14)).place(relx=0.3, rely=row_size * rows, relheight=row_size, relwidth=0.2)
                Label(frame2, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.5, rely=row_size * rows, relheight=row_size, relwidth=0.2)
                exec('Button(frame2, text="Stats", font=("Cambria",13), bg="#4554C0", fg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(func_mini_stat({}))).place(relx=0.78, rely={}+0.001, relheight={}-0.002, relwidth=0.15)'.format(row, row_size * rows, row_size))
                exec('Button(frame2, text="X", bg="#FF0000", fg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(func_del_myplayer({}))).place(relx=0.95, rely={}+0.03, relheight={}-0.06, relwidth=({}-0.06)/3)'.format(row, row_size * rows, row_size, row_size))
                rows += 1
            row += 1
    page.mainloop()

def func_prev_page_c1(label, frame, frame_to_delete, data_my_players):
    global c1_page_now
    global c1_page_total
    if c1_page_now == 1:
        msgbox.showwarning("No page", "This is the first page !")
    else:
        frame_to_delete.destroy()

        c1_page_now -= 1
        label.configure(text = str(c1_page_now)+"/"+str(c1_page_total))

        frame2 = Frame(frame, bg="#FFFFFF")
        frame2.place(relx=0.05, rely=0.05, relheight=0.82, relwidth=0.9)

        row = 1
        rows = 0
        row_size = 1 / 12
        for i in data_my_players:
            if ((c1_page_now - 1) * 12 + 1 <= row) & ((c1_page_now) * 12 + 1 > row):
                Label(frame2, text=str(row), font=("Cambria", 14), bg="#4554C0", fg="#FFFFFF").place(relx=0, rely=row_size * rows, relheight=row_size, relwidth=0.1)
                Label(frame2, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1, rely=row_size * rows, relheight=row_size, relwidth=0.3)
                Label(frame2, text=i[1], font=("Cambria", 14)).place(relx=0.4, rely=row_size * rows, relheight=row_size, relwidth=0.25)
                Label(frame2, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.65, rely=row_size * rows, relheight=row_size, relwidth=0.25)
                rows += 1
            row += 1
    page.mainloop()

def func_next_page_c1(label, frame, frame_to_delete, data_my_players):
    global c1_page_now
    global c1_page_total
    if c1_page_now == c1_page_total:
        msgbox.showwarning("No page", "This is the last page !")
    else:
        frame_to_delete.destroy()

        c1_page_now += 1
        label.configure(text=str(c1_page_now) + "/" + str(c1_page_total))

        frame2 = Frame(frame, bg="#FFFFFF")
        frame2.place(relx=0.05, rely=0.05, relheight=0.82, relwidth=0.9)

        row = 1
        rows = 0
        row_size = 1 / 12
        for i in data_my_players:
            if ((c1_page_now - 1) * 12 + 1 <= row)&((c1_page_now) * 12 + 1 > row):
                Label(frame2, text=str(row), font=("Cambria", 14), bg="#4554C0", fg="#FFFFFF").place(relx=0, rely=row_size * rows, relheight=row_size, relwidth=0.1)
                Label(frame2, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1, rely=row_size * rows, relheight=row_size, relwidth=0.3)
                Label(frame2, text=i[1], font=("Cambria", 14)).place(relx=0.4, rely=row_size * rows, relheight=row_size, relwidth=0.25)
                Label(frame2, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.65, rely=row_size * rows, relheight=row_size, relwidth=0.25)
                rows += 1
            row += 1
    page.mainloop()

def func_prev_page_R_L(label, frame, frame_to_delete, data_my_players):
    global RRL
    global RRLT
    if RRL == 1:
        msgbox.showwarning("No page", "This is the first page !")
    else:
        frame_to_delete.destroy()

        RRL -= 1
        label.configure(text = str(RRL)+"/"+str(RRLT))

        frame2 = Frame(frame, bg="#FFFFFF")
        frame2.place(relx=0.05, rely=0.14, relheight=0.76, relwidth=0.9)

        row = 1
        rows = 0
        row_size = 1 / 15
        for i in data_my_players:
            if ((RRL - 1) * 15 + 1 <= row) & ((RRL) * 15 + 1 > row):
                if row == 1:
                    Label(frame2, text=str(row - 1), font=("Cambria", 14), bg="#4554C0", fg="#FFFFFF").place(relx=0,
                                                                                                             rely=row_size * rows,
                                                                                                             relheight=row_size,
                                                                                                             relwidth=0.1)
                    Label(frame2, text=i[0], bg="#4554C0",fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.1, rely=row_size * rows,
                                                                                       relheight=row_size,
                                                                                       relwidth=0.25)
                    Label(frame2, text=i[1], bg="#4554C0",fg="#FFFFFF",font=("Cambria", 14)).place(relx=0.35, rely=row_size * rows,
                                                                         relheight=row_size, relwidth=0.18)
                    Label(frame2, text=i[2], bg="#4554C0",fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.53, rely=row_size * rows,
                                                                                       relheight=row_size,
                                                                                       relwidth=0.16)
                    Label(frame2, text=i[3], bg="#4554C0",fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.69, rely=row_size * rows,
                                                                                       relheight=row_size,
                                                                                       relwidth=0.11)
                    Label(frame2, text="Select", bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.8,
                                                                                                     rely=row_size * rows,
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.2)
                else:
                    Label(frame2, text=str(row-1), font=("Cambria", 14), bg="#4554C0", fg="#FFFFFF").place(relx=0, rely=row_size * rows, relheight=row_size, relwidth=0.1)
                    Label(frame2, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1, rely=row_size * rows, relheight=row_size, relwidth=0.25)
                    Label(frame2, text=i[1], font=("Cambria", 14)).place(relx=0.35, rely=row_size * rows, relheight=row_size, relwidth=0.18)
                    Label(frame2, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.53, rely=row_size * rows, relheight=row_size, relwidth=0.16)
                    Label(frame2, text=i[3], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.69, rely=row_size * rows, relheight=row_size, relwidth=0.11)
                    exec(
                        'Button(frame2, text="Select",  bg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(fill_box_L({}, {}, "{}"))).place(relx=0.80, rely={}, relheight={}, relwidth=0.2)'.format(
                            row, data_my_players, "R", row_size * rows, row_size))
                rows += 1
            row += 1
    page.mainloop()

def func_next_page_R_L(label, frame, frame_to_delete, data_my_players):
    global RRL
    global RRLT
    if RRL == RRLT:
        msgbox.showwarning("No page", "This is the last page !")
    else:
        frame_to_delete.destroy()

        RRL += 1
        label.configure(text=str(RRL) + "/" + str(RRLT))

        frame2 = Frame(frame, bg="#FFFFFF")
        frame2.place(relx=0.05, rely=0.14, relheight=0.76, relwidth=0.9)

        row = 1
        rows = 0
        row_size = 1 / 15
        for i in data_my_players:
            if ((RRL - 1) * 15 + 1 <= row)&((RRL) * 15 + 1 > row):
                if row == 1:
                    Label(frame2, text=str(row - 1), font=("Cambria", 14), bg="#4554C0", fg="#FFFFFF").place(relx=0,
                                                                                                             rely=row_size * rows,
                                                                                                             relheight=row_size,
                                                                                                             relwidth=0.1)
                    Label(frame2, text=i[0], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.1,
                                                                                                     rely=row_size * rows,
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.25)
                    Label(frame2, text=i[1], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 14)).place(relx=0.35,
                                                                                                     rely=row_size * rows,
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.18)
                    Label(frame2, text=i[2], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.53,
                                                                                                     rely=row_size * rows,
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.16)
                    Label(frame2, text=i[3], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.69,
                                                                                                     rely=row_size * rows,
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.11)
                    Label(frame2, text="Select", bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.8,
                                                                                                         rely=row_size * rows,
                                                                                                         relheight=row_size,
                                                                                                         relwidth=0.2)
                else:
                    Label(frame2, text=str(row-1), font=("Cambria", 14), bg="#4554C0", fg="#FFFFFF").place(relx=0, rely=row_size * rows, relheight=row_size, relwidth=0.1)
                    Label(frame2, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1, rely=row_size * rows, relheight=row_size, relwidth=0.25)
                    Label(frame2, text=i[1], font=("Cambria", 14)).place(relx=0.35, rely=row_size * rows, relheight=row_size, relwidth=0.18)
                    Label(frame2, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.53, rely=row_size * rows, relheight=row_size, relwidth=0.16)
                    Label(frame2, text=i[3], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.69, rely=row_size * rows,
                                                                                       relheight=row_size, relwidth=0.11)
                    exec(
                        'Button(frame2, text="Select",  bg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(fill_box_L({}, {}, "{}"))).place(relx=0.80, rely={}, relheight={}, relwidth=0.2)'.format(
                            row, data_my_players, "R", row_size * rows, row_size))
                rows += 1
            row += 1
    page.mainloop()

def func_prev_page_R_R(label, frame, frame_to_delete, data_my_players):
    global RRR
    global RRRT
    if RRR == 1:
        msgbox.showwarning("No page", "This is the first page !")
    else:
        frame_to_delete.destroy()

        RRL -= 1
        label.configure(text = str(RRR)+"/"+str(RRRT))

        frame2 = Frame(frame, bg="#FFFFFF")
        frame2.place(relx=0.05, rely=0.14, relheight=0.76, relwidth=0.9)

        row = 1
        rows = 0
        row_size = 1 / 15
        for i in data_my_players:
            if ((RRR - 1) * 15 + 1 <= row) & ((RRR) * 15 + 1 > row):
                if row == 1:
                    Label(frame2, text=str(row - 1), font=("Cambria", 14), bg="#4554C0", fg="#FFFFFF").place(relx=0,
                                                                                                             rely=row_size * rows,
                                                                                                             relheight=row_size,
                                                                                                             relwidth=0.1)
                    Label(frame2, text=i[0], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.1,
                                                                                                     rely=row_size * rows,
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.25)
                    Label(frame2, text=i[1], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 14)).place(relx=0.35,
                                                                                                     rely=row_size * rows,
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.18)
                    Label(frame2, text=i[2], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.53,
                                                                                                     rely=row_size * rows,
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.16)
                    Label(frame2, text=i[3], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.69,
                                                                                                     rely=row_size * rows,
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.11)
                    Label(frame2, text="Select", bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.8,
                                                                                                         rely=row_size * rows,
                                                                                                         relheight=row_size,
                                                                                                         relwidth=0.2)
                else:
                    Label(frame2, text=str(row-1), font=("Cambria", 14), bg="#4554C0", fg="#FFFFFF").place(relx=0, rely=row_size * rows, relheight=row_size, relwidth=0.1)
                    Label(frame2, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1, rely=row_size * rows, relheight=row_size, relwidth=0.25)
                    Label(frame2, text=i[1], font=("Cambria", 14)).place(relx=0.35, rely=row_size * rows, relheight=row_size, relwidth=0.18)
                    Label(frame2, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.53, rely=row_size * rows, relheight=row_size, relwidth=0.16)
                    Label(frame2, text=i[3], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.69, rely=row_size * rows,
                                                                                       relheight=row_size, relwidth=0.11)
                    exec(
                        'Button(frame2, text="Select",  bg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(fill_box_R({}, {}, "{}"))).place(relx=0.80, rely={}, relheight={}, relwidth=0.2)'.format(
                            row, data_my_players, "R", row_size * rows, row_size))
                rows += 1
            row += 1
    page.mainloop()

def func_next_page_R_R(label, frame, frame_to_delete, data_my_players):
    global RRR
    global RRRT
    if RRR == RRRT:
        msgbox.showwarning("No page", "This is the last page !")
    else:
        frame_to_delete.destroy()

        RRL += 1
        label.configure(text=str(RRR) + "/" + str(RRRT))

        frame2 = Frame(frame, bg="#FFFFFF")
        frame2.place(relx=0.05, rely=0.14, relheight=0.76, relwidth=0.9)

        row = 1
        rows = 0
        row_size = 1 / 15
        for i in data_my_players:
            if ((RRR - 1) * 15 + 1 <= row)&((RRR) * 15 + 1 > row):
                if row == 1:
                    Label(frame2, text=str(row - 1), font=("Cambria", 14), bg="#4554C0", fg="#FFFFFF").place(relx=0,
                                                                                                             rely=row_size * rows,
                                                                                                             relheight=row_size,
                                                                                                             relwidth=0.1)
                    Label(frame2, text=i[0], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.1,
                                                                                                     rely=row_size * rows,
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.25)
                    Label(frame2, text=i[1], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 14)).place(relx=0.35,
                                                                                                     rely=row_size * rows,
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.18)
                    Label(frame2, text=i[2], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.53,
                                                                                                     rely=row_size * rows,
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.16)
                    Label(frame2, text=i[3], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.69,
                                                                                                     rely=row_size * rows,
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.11)
                    Label(frame2, text="Select", bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.8,
                                                                                                         rely=row_size * rows,
                                                                                                         relheight=row_size,
                                                                                                         relwidth=0.2)
                else:
                    Label(frame2, text=str(row-1), font=("Cambria", 14), bg="#4554C0", fg="#FFFFFF").place(relx=0, rely=row_size * rows, relheight=row_size, relwidth=0.1)
                    Label(frame2, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1, rely=row_size * rows, relheight=row_size, relwidth=0.25)
                    Label(frame2, text=i[1], font=("Cambria", 14)).place(relx=0.35, rely=row_size * rows, relheight=row_size, relwidth=0.18)
                    Label(frame2, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.53, rely=row_size * rows, relheight=row_size, relwidth=0.16)
                    Label(frame2, text=i[3], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.69, rely=row_size * rows,
                                                                                       relheight=row_size, relwidth=0.11)
                    exec(
                        'Button(frame2, text="Select",  bg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(fill_box_R({}, {}, "{}"))).place(relx=0.80, rely={}, relheight={}, relwidth=0.2)'.format(
                            row, data_my_players, "R", row_size*rows, row_size))
                rows += 1
            row += 1
    page.mainloop()

def fill_box_L(i, data_b, typ):
    compare_box[0].clear()
    compare_box[2].clear()
    if typ == "H":
        data_n = multi_search_by_value(hitter, ['선수명', 'Year', '팀명'], [data_b[i-1][0], data_b[i-1][1], data_b[i-1][2]])
        compare_box[2].append(list(data_n.columns))
        for i in data_n.values[0]:
            compare_box[0].append(i)
    elif typ == "R":
        data_n = multi_search_by_value(runner, ['선수명', 'Year', '팀명'], [data_b[i-1][0], int(data_b[i-1][1]), data_b[i-1][2]])
        compare_box[2].append(list(data_n.columns))
        for i in data_n.values[0]:
            compare_box[0].append(i)
    elif typ == "D":
        data_n = multi_search_by_value(defense, ['선수명', 'Year', '팀명', 'POS'], [data_b[i - 1][0], int(data_b[i - 1][1]), data_b[i - 1][2], data_b[i-1][3]])
        compare_box[2].append(list(data_n.columns))
        for i in data_n.values[0]:
            compare_box[0].append(i)
    elif typ == "P":
        data_n = multi_search_by_value(pitcher, ['선수명', 'Year', '팀명'], [data_b[i-1][0], data_b[i-1][1], data_b[i-1][2]])
        compare_box[2].append(list(data_n.columns))
        for i in data_n.values[0]:
            compare_box[0].append(i)

def fill_box_R(i, data_b, typ):
    compare_box[1].clear()
    compare_box[2].clear()
    if typ == "H":
        data_n = multi_search_by_value(hitter, ['선수명', 'Year', '팀명'], [data_b[i-1][0], data_b[i-1][1], data_b[i-1][2]])
        compare_box[2].append(list(data_n.columns))
        for i in data_n.values[0]:
            compare_box[1].append(i)
    elif typ == "R":
        data_n = multi_search_by_value(runner, ['선수명', 'Year', '팀명'], [data_b[i-1][0], int(data_b[i-1][1]), data_b[i-1][2]])
        compare_box[2].append(list(data_n.columns))
        for i in data_n.values[0]:
            compare_box[1].append(i)
    elif typ == "D":
        data_n = multi_search_by_value(defense, ['선수명', 'Year', '팀명', 'POS'],
                                       [data_b[i - 1][0], int(data_b[i - 1][1]), data_b[i - 1][2], data_b[i-1][3]])
        compare_box[2].append(list(data_n.columns))
        for i in data_n.values[0]:
            compare_box[1].append(i)
    elif typ == "P":
        data_n = multi_search_by_value(pitcher, ['선수명', 'Year', '팀명'], [data_b[i-1][0], data_b[i-1][1], data_b[i-1][2]])
        compare_box[2].append(list(data_n.columns))
        for i in data_n.values[0]:
            compare_box[1].append(i)

def func_compare1(type, LR, year, team, pos, order, check, F):
    erase_child_without(F, 1)
    fr = Frame(F, bg='#FFFFFF')
    fr.place(relx=0.05, rely=0.14, relheight=0.76, relwidth=0.9)

    ordering = "nope"
    if check == 1:
        ordering = "ascending"
    else:
        ordering = "nope"

    result = []

    if type == 'H':
        result_ht_temp = multi_search_by_value(hitter, ['Year', '팀명'], [int(year), team])
        result_ht_temp2 = sort_by_standard(result_ht_temp, order, ordering)
        result_ht = result_ht_temp2[["선수명", "Year", "팀명", order]]
        result_data = result_ht.values
        result.append(["선수명", "Year", "팀명", order])
        for i in range(len(result_data)):
            result.append([])
        for i in range(len(result_data)):
            for j in range(4):
                result[i+1].append(result_data[i][j])
        if LR == 'L':
            row = 1
            rows = 0
            row_size = 1 / 15
            for i in result:
                if rows < 15:
                    if row == 1:
                        Label(fr, text=str(row-1), font=("Cambria", 14), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.1,
                                                                                                             rely=row_size * (
                                                                                                                         row - 1),
                                                                                                             relheight=row_size,
                                                                                                             relwidth=0.25)
                        Label(fr, text=i[1], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 14)).place(relx=0.35,
                                                                                               rely=row_size * (
                                                                                                           row - 1),
                                                                                               relheight=row_size,
                                                                                               relwidth=0.18)
                        Label(fr, text=i[2], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.53,
                                                                                                             rely=row_size * (
                                                                                                                         row - 1),
                                                                                                             relheight=row_size,
                                                                                                             relwidth=0.16)
                        Label(fr, text=i[3], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.69,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.11)
                        Label(fr, text="Select", bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.8,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.2)
                    else:
                        Label(fr, text=str(row-1), font=("Cambria", 10), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.25)
                        Label(fr, text=i[1], font=("Cambria", 10)).place(relx=0.35,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.18)
                        Label(fr, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.53,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.16)
                        Label(fr, text=i[3], font=("Cambria", 12)).place(relx=0.69,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.11)
                        exec(
                            'Button(fr, text="Select", bg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(fill_box_L({}, {}, "{}"))).place(relx=0.80, rely={}, relheight={}, relwidth=0.2)'.format(
                                row, result, "H", row_size * rows, row_size))
                    row += 1
                rows += 1
            global HL
            HL = 1
            global HLT
            HLT = rows // 15 + ((rows - (rows // 15) * 15) != 0)
            # func_prev_page(mp_label_page_now, mp_frame_players_content)
            HL_btn_prev_page = Button(F, text="◀", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (msgbox.showwarning("No page", "This is the first page !")))
            HL_btn_prev_page.place(relx=0.05, rely=0.91, relwidth=0.07, relheight=0.06)

            HL_label_page_now = Label(F, text=str(HL) + "/" + str(HLT),
                                      font=("Cambria", 14), bg='#E0E6F8')
            HL_label_page_now.place(relx=0.125, rely=0.91, relwidth=0.1, relheight=0.06)

            HL_btn_next_page = Button(F, text="▶", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    msgbox.showwarning("No page", "This is the last page !")))
            HL_btn_next_page.place(relx=0.23, rely=0.91, relwidth=0.07, relheight=0.06)
        elif LR == 'R':
            row = 1
            rows = 0
            row_size = 1 / 15
            for i in result:
                if rows < 15:
                    if row == 1:
                        Label(fr, text=str(row-1), font=("Cambria", 14), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.1,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.25)
                        Label(fr, text=i[1], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 14)).place(relx=0.35,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.18)
                        Label(fr, text=i[2], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.53,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.16)
                        Label(fr, text=i[3], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.69,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.11)
                        Label(fr, text="Select", bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.8,
                                                                                                         rely=row_size * (
                                                                                                                 row - 1),
                                                                                                         relheight=row_size,
                                                                                                         relwidth=0.2)
                    else:
                        Label(fr, text=str(row-1), font=("Cambria", 10), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.25)
                        Label(fr, text=i[1], font=("Cambria", 10)).place(relx=0.35,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.18)
                        Label(fr, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.53,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.16)
                        Label(fr, text=i[3], font=("Cambria", 12)).place(relx=0.69,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.11)
                        exec(
                            'Button(fr, text="Select",  bg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(fill_box_R({}, {}, "{}"))).place(relx=0.80, rely={}, relheight={}, relwidth=0.2)'.format(
                                row, result, "H", row_size * rows, row_size))
                    row += 1
                rows += 1
            global HR
            HR = 1
            global HRT
            HRT = rows // 15 + ((rows - (rows // 15) * 15) != 0)
            # func_prev_page(mp_label_page_now, mp_frame_players_content)
            HR_btn_prev_page = Button(F, text="◀", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    msgbox.showwarning("No page", "This is the first page !")))
            HR_btn_prev_page.place(relx=0.05, rely=0.91, relwidth=0.07, relheight=0.06)

            HR_label_page_now = Label(F, text=str(HR) + "/" + str(HRT),
                                      font=("Cambria", 14), bg='#E0E6F8')
            HR_label_page_now.place(relx=0.125, rely=0.91, relwidth=0.1, relheight=0.06)

            HR_btn_next_page = Button(F, text="▶", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    msgbox.showwarning("No page", "This is the last page !")))
            HR_btn_next_page.place(relx=0.23, rely=0.91, relwidth=0.07, relheight=0.06)
    elif type == 'P':
        result_pc_temp = multi_search_by_value(pitcher, ['Year', '팀명'], [int(year), team])
        result_pc_temp2 = sort_by_standard(result_pc_temp, order, ordering)
        result_pc = result_pc_temp2[["선수명", "Year", "팀명", order]]
        result_data = result_pc.values
        result.append(["선수명", "Year", "팀명", order])
        for i in range(len(result_data)):
            result.append([])
        for i in range(len(result_data)):
            for j in range(4):
                result[i+1].append(result_data[i][j])
        if LR == 'L':
            row = 1
            rows = 0
            row_size = 1 / 15
            for i in result:
                if rows < 15:
                    if row == 1:
                        Label(fr, text=str(row-1), font=("Cambria", 14), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.1,
                                                                                                             rely=row_size * (
                                                                                                                         row - 1),
                                                                                                             relheight=row_size,
                                                                                                             relwidth=0.25)
                        Label(fr, text=i[1], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 14)).place(relx=0.35,
                                                                                               rely=row_size * (
                                                                                                           row - 1),
                                                                                               relheight=row_size,
                                                                                               relwidth=0.18)
                        Label(fr, text=i[2], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.53,
                                                                                                             rely=row_size * (
                                                                                                                         row - 1),
                                                                                                             relheight=row_size,
                                                                                                             relwidth=0.16)
                        Label(fr, text=i[3], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.69,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.11)
                        Label(fr, text="Select", bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.8,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.2)
                    else:
                        Label(fr, text=str(row-1), font=("Cambria", 10), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.25)
                        Label(fr, text=i[1], font=("Cambria", 10)).place(relx=0.35,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.18)
                        Label(fr, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.53,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.16)
                        Label(fr, text=i[3], font=("Cambria", 12)).place(relx=0.69,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.11)
                        exec(
                            'Button(fr, text="Select", bg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(fill_box_L({}, {}, "{}"))).place(relx=0.80, rely={}, relheight={}, relwidth=0.2)'.format(
                                row, result, "P", row_size * rows, row_size))
                    row += 1
                rows += 1
            global PL
            PL = 1
            global PLT
            PLT = rows // 15 + ((rows - (rows // 15) * 15) != 0)
            # func_prev_page(mp_label_page_now, mp_frame_players_content)
            PL_btn_prev_page = Button(F, text="◀", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    msgbox.showwarning("No page", "This is the first page !")))
            PL_btn_prev_page.place(relx=0.05, rely=0.91, relwidth=0.07, relheight=0.06)

            PL_label_page_now = Label(F, text=str(PL) + "/" + str(PLT),
                                      font=("Cambria", 14), bg='#E0E6F8')
            PL_label_page_now.place(relx=0.125, rely=0.91, relwidth=0.1, relheight=0.06)

            PL_btn_next_page = Button(F, text="▶", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    msgbox.showwarning("No page", "This is the last page !")))
            PL_btn_next_page.place(relx=0.23, rely=0.91, relwidth=0.07, relheight=0.06)
        elif LR == 'R':
            row = 1
            rows = 0
            row_size = 1 / 15
            for i in result:
                if rows < 15:
                    if row == 1:
                        Label(fr, text=str(row-1), font=("Cambria", 14), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.1,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.25)
                        Label(fr, text=i[1], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 14)).place(relx=0.35,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.18)
                        Label(fr, text=i[2], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.53,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.16)
                        Label(fr, text=i[3], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.69,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.11)
                        Label(fr, text="Select", bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.8,
                                                                                                         rely=row_size * (
                                                                                                                 row - 1),
                                                                                                         relheight=row_size,
                                                                                                         relwidth=0.2)
                    else:
                        Label(fr, text=str(row-1), font=("Cambria", 10), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.25)
                        Label(fr, text=i[1], font=("Cambria", 10)).place(relx=0.35,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.18)
                        Label(fr, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.53,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.16)
                        Label(fr, text=i[3], font=("Cambria", 12)).place(relx=0.69,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.11)
                        exec(
                            'Button(fr, text="Select",  bg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(fill_box_R({}, {}, "{}"))).place(relx=0.80, rely={}, relheight={}, relwidth=0.2)'.format(
                                row, result, "P", row_size * rows, row_size))
                    row += 1
                rows += 1
            global PR
            PR = 1
            global PRT
            PRT = rows // 15 + ((rows - (rows // 15) * 15) != 0)
            # func_prev_page(mp_label_page_now, mp_frame_players_content)
            PR_btn_prev_page = Button(F, text="◀", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    msgbox.showwarning("No page", "This is the first page !")))
            PR_btn_prev_page.place(relx=0.05, rely=0.91, relwidth=0.07, relheight=0.06)

            PR_label_page_now = Label(F, text=str(PR) + "/" + str(PRT),
                                      font=("Cambria", 14), bg='#E0E6F8')
            PR_label_page_now.place(relx=0.125, rely=0.91, relwidth=0.1, relheight=0.06)

            PR_btn_next_page = Button(F, text="▶", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    msgbox.showwarning("No page", "This is the last page !")))
            PR_btn_next_page.place(relx=0.23, rely=0.91, relwidth=0.07, relheight=0.06)
    elif type == 'D':
        result_df_temp = multi_search_by_value(defense, ['Year', '팀명', 'POS'], [int(year), team, pos])
        result_df_temp2 = sort_by_standard(result_df_temp, order, ordering)
        result_df = result_df_temp2[["선수명", "Year", "팀명", "POS", order]]
        result_data = result_df.values
        result.append(["선수명", "Year", "팀명", "POS", order])
        for i in range(len(result_data)):
            result.append([])
        for i in range(len(result_data)):
            for j in range(5):
                result[i+1].append(result_data[i][j])
        if LR == 'L':
            row = 1
            rows = 0
            row_size = 1 / 15
            for i in result:
                if rows < 15:
                    if row == 1:
                        Label(fr, text=str(row-1), font=("Cambria", 14), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.1,
                                                                                                             rely=row_size * (
                                                                                                                         row - 1),
                                                                                                             relheight=row_size,
                                                                                                             relwidth=0.25)
                        Label(fr, text=i[1], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 14)).place(relx=0.35,
                                                                                               rely=row_size * (
                                                                                                           row - 1),
                                                                                               relheight=row_size,
                                                                                               relwidth=0.18)
                        Label(fr, text=i[3], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.53,
                                                                                                             rely=row_size * (
                                                                                                                         row - 1),
                                                                                                             relheight=row_size,
                                                                                                             relwidth=0.16)
                        Label(fr, text=i[4], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.69,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.11)
                        Label(fr, text="Select", bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.8,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.2)
                    else:
                        Label(fr, text=str(row-1), font=("Cambria", 10), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.25)
                        Label(fr, text=i[1], font=("Cambria", 10)).place(relx=0.35,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.18)
                        Label(fr, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.53,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.16)
                        Label(fr, text=i[3], font=("Cambria", 12)).place(relx=0.69,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.11)
                        exec(
                            'Button(fr, text="Select",  bg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(fill_box_L({}, {}, "{}"))).place(relx=0.80, rely={}, relheight={}, relwidth=0.2)'.format(
                                row, result, "D", row_size * rows, row_size))
                    row += 1
                rows += 1
            global DL
            DL = 1
            global DLT
            DLT = rows // 15 + ((rows - (rows // 15) * 15) != 0)
            # func_prev_page(mp_label_page_now, mp_frame_players_content)
            DL_btn_prev_page = Button(F, text="◀", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    msgbox.showwarning("No page", "This is the first page !")))
            DL_btn_prev_page.place(relx=0.05, rely=0.91, relwidth=0.07, relheight=0.06)

            DL_label_page_now = Label(F, text=str(DL) + "/" + str(DLT),
                                      font=("Cambria", 14), bg='#E0E6F8')
            DL_label_page_now.place(relx=0.125, rely=0.91, relwidth=0.1, relheight=0.06)

            DL_btn_next_page = Button(F, text="▶", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    msgbox.showwarning("No page", "This is the last page !")))
            DL_btn_next_page.place(relx=0.23, rely=0.91, relwidth=0.07, relheight=0.06)
        elif LR == 'R':
            row = 1
            rows = 0
            row_size = 1 / 15
            for i in result:
                if rows < 15:
                    if row == 1:
                        Label(fr, text=str(row-1), font=("Cambria", 14), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.1,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.25)
                        Label(fr, text=i[1], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 14)).place(relx=0.35,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.18)
                        Label(fr, text=i[2], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.53,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.16)
                        Label(fr, text=i[3], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.69,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.11)
                        Label(fr, text="Select", bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.8,
                                                                                                         rely=row_size * (
                                                                                                                 row - 1),
                                                                                                         relheight=row_size,
                                                                                                         relwidth=0.2)
                    else:
                        Label(fr, text=str(row-1), font=("Cambria", 10), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.25)
                        Label(fr, text=i[1], font=("Cambria", 10)).place(relx=0.35,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.18)
                        Label(fr, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.53,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.16)
                        Label(fr, text=i[3], font=("Cambria", 12)).place(relx=0.69,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.11)
                        exec(
                            'Button(fr, text="Select",  bg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(fill_box_R({}, {}, "{}"))).place(relx=0.80, rely={}, relheight={}, relwidth=0.2)'.format(
                                row, result, "D", row_size * rows, row_size))
                    row += 1
                rows += 1
            global DR
            DR = 1
            global DRT
            DRT = rows // 15 + ((rows - (rows // 15) * 15) != 0)
            # func_prev_page(mp_label_page_now, mp_frame_players_content)
            DR_btn_prev_page = Button(F, text="◀", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    func_prev_page(DR_label_page_now, F, fr, result)))
            DR_btn_prev_page.place(relx=0.05, rely=0.91, relwidth=0.07, relheight=0.06)

            DR_label_page_now = Label(F, text=str(DR) + "/" + str(DRT),
                                      font=("Cambria", 14), bg='#E0E6F8')
            DR_label_page_now.place(relx=0.125, rely=0.91, relwidth=0.1, relheight=0.06)

            DR_btn_next_page = Button(F, text="▶", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    func_next_page(DR_label_page_now, F, fr, result)))
            DR_btn_next_page.place(relx=0.23, rely=0.91, relwidth=0.07, relheight=0.06)
    elif type == 'R':
        result_rn_temp = multi_search_by_value(runner, ['Year', '팀명'], [int(year), team])
        result_rn_temp2 = sort_by_standard(result_rn_temp, order, ordering)
        result_rn = result_rn_temp2[["선수명", "Year", "팀명", order]]
        result_data = result_rn.values
        result.append(["선수명", "Year", "팀명", order])
        for i in range(len(result_data)):
            result.append([])
        for i in range(len(result_data)):
            for j in range(4):
                result[i+1].append(result_data[i][j])
        if LR == 'L':
            row = 1
            rows = 0
            row_size = 1 / 15
            for i in result:
                if rows < 15:
                    if row == 1:
                        Label(fr, text=str(row-1), font=("Cambria", 14), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.1,
                                                                                                             rely=row_size * (
                                                                                                                         row - 1),
                                                                                                             relheight=row_size,
                                                                                                             relwidth=0.25)
                        Label(fr, text=i[1], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 14)).place(relx=0.35,
                                                                                               rely=row_size * (
                                                                                                           row - 1),
                                                                                               relheight=row_size,
                                                                                               relwidth=0.18)
                        Label(fr, text=i[2], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.53,
                                                                                                             rely=row_size * (
                                                                                                                         row - 1),
                                                                                                             relheight=row_size,
                                                                                                             relwidth=0.16)
                        Label(fr, text=i[3], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.69,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.11)
                        Label(fr, text="Select", bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.8,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.2)
                    else:
                        Label(fr, text=str(row-1), font=("Cambria", 10), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.25)
                        Label(fr, text=i[1], font=("Cambria", 10)).place(relx=0.35,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.18)
                        Label(fr, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.53,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.16)
                        Label(fr, text=i[3], font=("Cambria", 12)).place(relx=0.69,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.11)
                        exec(
                            'Button(fr, text="Select",  bg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(fill_box_L({}, {}, "{}"))).place(relx=0.80, rely={}, relheight={}, relwidth=0.2)'.format(
                                row, result, "R", row_size * rows, row_size))
                    row += 1
                rows += 1
            global RRL
            RRL = 1
            global RRLT
            RRLT = rows // 15 + ((rows - (rows // 15) * 15) != 0)
            # func_prev_page(mp_label_page_now, mp_frame_players_content)
            RRL_btn_prev_page = Button(F, text="◀", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    func_prev_page_R_L(RRL_label_page_now, F, fr, result)))
            RRL_btn_prev_page.place(relx=0.05, rely=0.91, relwidth=0.07, relheight=0.06)

            RRL_label_page_now = Label(F, text=str(RRL) + "/" + str(RRLT),
                                      font=("Cambria", 14), bg='#E0E6F8')
            RRL_label_page_now.place(relx=0.125, rely=0.91, relwidth=0.1, relheight=0.06)

            RRL_btn_next_page = Button(F, text="▶", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    func_next_page_R_L(RRL_label_page_now, F, fr, result)))
            RRL_btn_next_page.place(relx=0.23, rely=0.91, relwidth=0.07, relheight=0.06)
        elif LR == 'R':
            row = 1
            rows = 0
            row_size = 1 / 15
            for i in result:
                if rows < 15:
                    if row == 1:
                        Label(fr, text=str(row-1), font=("Cambria", 14), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.1,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.25)
                        Label(fr, text=i[1], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 14)).place(relx=0.35,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.18)
                        Label(fr, text=i[2], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 10)).place(relx=0.53,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.16)
                        Label(fr, text=i[3], bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.69,
                                                                                                     rely=row_size * (
                                                                                                             row - 1),
                                                                                                     relheight=row_size,
                                                                                                     relwidth=0.11)
                        Label(fr, text="Select", bg="#4554C0", fg="#FFFFFF", font=("Cambria", 12)).place(relx=0.8,
                                                                                                         rely=row_size * (
                                                                                                                 row - 1),
                                                                                                         relheight=row_size,
                                                                                                         relwidth=0.2)
                    else:
                        Label(fr, text=str(row-1), font=("Cambria", 10), bg="#4554C0",
                              fg="#FFFFFF").place(relx=0, rely=row_size * (row - 1), relheight=row_size,
                                                  relwidth=0.1)
                        Label(fr, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.25)
                        Label(fr, text=i[1], font=("Cambria", 10)).place(relx=0.35,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.18)
                        Label(fr, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.53,
                                                                                       rely=row_size * (
                                                                                               row - 1),
                                                                                       relheight=row_size,
                                                                                       relwidth=0.16)
                        Label(fr, text=i[3], font=("Cambria", 12)).place(relx=0.69,
                                                                         rely=row_size * (
                                                                                 row - 1),
                                                                         relheight=row_size,
                                                                         relwidth=0.11)
                        exec(
                            'Button(fr, text="Select",  bg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(fill_box_R({}, {}, "{}"))).place(relx=0.80, rely={}, relheight={}, relwidth=0.2)'.format(
                                row, result, "R", row_size * rows, row_size))
                    row += 1
                rows += 1
            global RRR
            RRR = 1
            global RRRT
            RRRT = rows // 15 + ((rows - (rows // 15) * 15) != 0)
            # func_prev_page(mp_label_page_now, mp_frame_players_content)
            RRR_btn_prev_page = Button(F, text="◀", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    func_prev_page_R_R(RRR_label_page_now, F, fr, result)))
            RRR_btn_prev_page.place(relx=0.05, rely=0.91, relwidth=0.07, relheight=0.06)

            RRR_label_page_now = Label(F, text=str(RRR) + "/" + str(RRRT),
                                      font=("Cambria", 14), bg='#E0E6F8')
            RRR_label_page_now.place(relx=0.125, rely=0.91, relwidth=0.1, relheight=0.06)

            RRR_btn_next_page = Button(F, text="▶", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                      bg="#4554C0", cursor='hand2', command=lambda: (
                    func_next_page_R_R(RRR_label_page_now, F, fr, result)))
            RRR_btn_next_page.place(relx=0.23, rely=0.91, relwidth=0.07, relheight=0.06)


def comparing():
    if compare_box[0] == []:
        msgbox.showwarning("Compare Error", "Choose a Player in the Left box.")
        return 0
    elif compare_box[1] == []:
        msgbox.showwarning("Compare Error", "Choose a Player in the Right box.")
        return 0
    page_cp = Toplevel()
    page_cp.title("COMPARE")
    page_cp.geometry("600x700+480+65")
    page_cp.resizable = (False, False)

    cp_frame = Frame(page_cp, bg='#E0E6F8')
    cp_frame.place(relx=0, rely=0, relheight=1, relwidth=1)

    print(compare_box[0], compare_box[1], compare_box[2][0])

    diff = []
    for i in range(len(compare_box[0])):
        if (isinstance(compare_box[0][i],int))or(isinstance(compare_box[0][i],float)):
            print(compare_box[0][i] ,compare_box[1][i])
            diff.append(compare_box[0][i] - compare_box[1][i])
        else:
            print(compare_box[0][i] ,compare_box[1][i])
            diff.append("C")

    M = len(compare_box[0])
    print(diff)
    for i in range(M):
        Label(cp_frame, text = compare_box[2][0][i], bg="#4664C0", fg="#FFFFFF", font = ("Cambria", 14)).place(relx=0.5, rely=0.05+(0.85/M)*(i), relheight=0.85/M, relwidth=0.1, anchor="n")
        Label(cp_frame, text=compare_box[0][i], bg='#E0E6F8', font=("Cambria", 14)).place(relx=0.36, rely=0.05+(0.85/M)*(i), relheight=0.85/M, relwidth=0.18, anchor="n")
        Label(cp_frame, text=compare_box[1][i], bg='#E0E6F8', font=("Cambria", 14)).place(relx=0.64, rely=0.05+(0.85/M)*(i), relheight=0.85/M, relwidth=0.18, anchor="n")
        if diff[i] != "C":
            if diff[i] > 0:
                if isinstance(compare_box[0][i],float):
                    Label(cp_frame, text="▲ "+str(round(diff[i],2)), bg='#E0E6F8', fg="#FF0000", font=("Cambria", 14)).place(relx=0.22, rely=0.05+(0.85/M)*(i), relheight=0.85/M, relwidth=0.1, anchor="n")
                    Label(cp_frame, text="▼ "+str(round(-diff[i],2)), bg='#E0E6F8', fg="#4664C0", font=("Cambria", 14)).place(relx=0.78, rely=0.05+(0.85/M)*(i), relheight=0.85/M, relwidth=0.1, anchor="n")
                else:
                    Label(cp_frame, text="▲ "+str(diff[i]), bg='#E0E6F8', fg="#FF0000", font=("Cambria", 14)).place(relx=0.22, rely=0.05+(0.85/M)*(i), relheight=0.85/M, relwidth=0.1, anchor="n")
                    Label(cp_frame, text="▼ "+str(-diff[i]), bg='#E0E6F8', fg="#4664C0", font=("Cambria", 14)).place(relx=0.78, rely=0.05+(0.85/M)*(i), relheight=0.85/M, relwidth=0.1, anchor="n")
            elif diff[i] == 0:
                Label(cp_frame, text="-", bg='#E0E6F8', font=("Cambria", 14)).place(relx=0.22, rely=0.05+(0.85/M)*(i), relheight=0.85/M, relwidth=0.1, anchor="n")
                Label(cp_frame, text="-", bg='#E0E6F8', font=("Cambria", 14)).place(relx=0.78, rely=0.05+(0.85/M)*(i), relheight=0.85/M, relwidth=0.1, anchor="n")
            else:
                if isinstance(compare_box[0][i], float):
                    Label(cp_frame, text="▼ "+str(round(-diff[i],2)), bg='#E0E6F8', fg="#4664C0", font=("Cambria", 14)).place(relx=0.22, rely=0.05+(0.85/M)*(i), relheight=0.85/M, relwidth=0.1, anchor="n")
                    Label(cp_frame, text="▲ "+str(round(diff[i],2)), bg='#E0E6F8', fg="#FF0000", font=("Cambria", 14)).place(relx=0.78, rely=0.05+(0.85/M)*(i), relheight=0.85/M, relwidth=0.1, anchor="n")
                else:
                    Label(cp_frame, text="▼ " + str(-diff[i]), bg='#E0E6F8', fg="#4664C0", font=("Cambria", 14)).place(relx=0.22, rely=0.05+(0.85/M)*(i), relheight=0.85/M, relwidth=0.1, anchor="n")
                    Label(cp_frame, text="▲ " + str(diff[i]), bg='#E0E6F8', fg="#FF0000", font=("Cambria", 14)).place(relx=0.78, rely=0.05+(0.85/M)*(i), relheight=0.85/M, relwidth=0.1, anchor="n")

    close_btn = Button(cp_frame, text="Close", font=("Cambria", 12), relief="ridge",fg="#FFFFFF", bg="#4554C0", cursor='hand2', command = lambda:(page_cp.destroy()))
    close_btn.place(relx=0.8, rely=0.94, relheight=0.05, relwidth=0.17)

    page_cp.mainloop()


def erase_child_with(place, num):
    i = 0
    for child in place.winfo_children():
        i += 1
    num_del = i-num
    num_curr = 0
    for child in place.winfo_children():
        num_curr += 1
        if num_curr > num_del:
            child.destroy()

def erase_child_without(place, num):
    for child in place.winfo_children():
        if num < 1:
            child.destroy()
        num -= 1

def erase_child_th(place, th):
    i=0
    for child in place.winfo_children():
        i+=1
        if i == th:
            child.destroy()

def erase_child_all(place):
    for child in place.winfo_children():
        child.destroy()

def open_page_start():
    erase_child_all(page)
    start_img = ImageTk.PhotoImage(Image.open("Image\img_start.png").resize((1200, 630)))
    start_img_label = Label(page, image=start_img)
    start_img_label.place(relwidth=1, relheight=1)

    start_LeftFrame = Frame(page, bg='#FFFFFF', highlightbackground="#4664C0", highlightthickness=4)
    start_LeftFrame.place(relx=0.17, rely=0.4, relheight=0.2, relwidth=0.25, anchor=N)

    start_title_label = Label(start_LeftFrame, text='KBO STATS', font=("Impact", 36), fg="#4554C0", bg="#FFFFFF")
    start_title_label.place(relheight=1, relwidth=1)
    design_page_start("start")

def design_page_start(access_type):
    if access_type == 'start':
        start_RightFrame = Frame(page, bg='#FFFFFF', highlightbackground="#4664C0", highlightthickness=4)
        start_RightFrame.place(relx=0.83, rely=0.3, relheight=0.4, relwidth=0.25, anchor=N)

        start_btn_login = Button(start_RightFrame, text='Log In', font=("Cambria",14), fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda:(erase_child_with(page, 1), design_page_start("log in")))
        start_btn_signup = Button(start_RightFrame, text='Sign Up', font=("Cambria",14), fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda: (erase_child_with(page, 1), design_page_start("sign up")))
        start_btn_exit = Button(start_RightFrame, text='Exit', font=("Cambria",14), fg="#FFFFFF", bg="#4554C0",cursor='hand2', command=lambda: quit())
        start_btn_login.place(relx=0.1, rely=0.075, relwidth=0.8, relheight=0.25)
        start_btn_signup.place(relx=0.1, rely=0.25+0.125, relwidth=0.8, relheight=0.25)
        start_btn_exit.place(relx=0.1, rely=0.5+0.175, relwidth=0.8, relheight=0.25)
    elif access_type == 'log in':
        login_frame = Frame(page, bg='#FFFFFF', highlightbackground="#4664C0", highlightthickness=4)
        login_frame.place(relx = 0.83, rely =0.4 , relheight = 0.2, relwidth = 0.25, anchor=N)

        login_label_id = Label(login_frame, text='ID', font=("Cambria", 14), fg="#4554C0", bg="#FFFFFF")
        login_label_pw = Label(login_frame, text='Password', font=("Cambria", 14), fg="#4554C0", bg="#FFFFFF")
        login_entry_id = Entry(login_frame, font=("Cambria", 14), width=20)
        login_entry_pw = Entry(login_frame, font=("Cambria", 14), width=20)
        login_label_id.place(relx=0, rely=0, relheight=0.5, relwidth=0.3)
        login_label_pw.place(relx=0, rely=0.5, relheight=0.5, relwidth=0.3)
        login_entry_id.place(relx=0.3, rely=0, relheight=0.5, relwidth=0.7)
        login_entry_pw.place(relx=0.3, rely=0.5, relheight=0.5, relwidth=0.7)

        login_btn_login = Button(page, text='Log In', font=("Cambria",14), fg="#FFFFFF", bg="#4554C0",cursor='hand2', command=lambda: func_login(login_entry_id.get(), login_entry_pw.get()))
        login_btn_find = Button(page, text='Find Info', font=("Cambria",14), fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda: (erase_child_with(page, 4), design_page_start("find info")))
        login_btn_back = Button(page, text="Back", font=("Cambria",14), fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda:(erase_child_with(page, 4), design_page_start("start")))
        login_btn_login.place(relx=0.7, rely=0.62, relheight=0.06, relwidth=0.08)
        login_btn_find.place(relx=0.79,rely=0.62,relheight=0.06,relwidth=0.08)
        login_btn_back.place(relx=0.88, rely=0.62, relheight=0.06, relwidth=0.08)
    elif access_type == 'sign up':
        signup_frame = Frame(page, bg='#FFFFFF', highlightbackground="#4664C0", highlightthickness=4)
        signup_frame.place(relx=0.7, rely=0.2, relheight=0.6, relwidth=0.5, anchor=N)

        signup_label_id = Label(signup_frame, text='ID', font=("Cambria", 14), fg="#4554C0", bg="#FFFFFF")
        signup_label_pw = Label(signup_frame, text='Password', font=("Cambria", 14), fg="#4554C0", bg="#FFFFFF")
        signup_label_nickname = Label(signup_frame, text='Nickname', font=("Cambria", 14), fg="#4554C0", bg="#FFFFFF")
        signup_label_name = Label(signup_frame, text='Name', font=("Cambria", 14), fg="#4554C0", bg="#FFFFFF")
        signup_label_phone = Label(signup_frame, text='Phone(with -)', font=("Cambria", 14), fg="#4554C0", bg="#FFFFFF")
        signup_entry_id = Entry(signup_frame, font=("Cambria", 14), width=20)
        signup_entry_pw = Entry(signup_frame, font=("Cambria", 14), width=20)
        signup_entry_nickname = Entry(signup_frame, font=("Cambria", 14), width=20)
        signup_entry_name = Entry(signup_frame, font=("Cambria", 14), width=20)
        signup_entry_phone = Entry(signup_frame, font=("Cambria", 14), width=20)

        signup_label_id.place(relx=0, rely=1/30, relheight=0.16, relwidth=0.3)
        signup_label_pw.place(relx=0, rely=0.16 + 2/30, relheight=0.16, relwidth=0.3)
        signup_label_nickname.place(relx=0, rely=0.32 + 3/30, relheight=0.16, relwidth=0.3)
        signup_label_name.place(relx=0, rely=0.48 + 4/30, relheight=0.16, relwidth=0.3)
        signup_label_phone.place(relx=0, rely=0.64 + 5/30, relheight=0.16, relwidth=0.3)
        signup_entry_id.place(relx=0.35, rely=1/30, relheight=0.16, relwidth=0.6)
        signup_entry_pw.place(relx=0.35, rely=0.16 + 2/30, relheight=0.16, relwidth=0.6)
        signup_entry_nickname.place(relx=0.35, rely=0.32 + 3/30, relheight=0.16, relwidth=0.6)
        signup_entry_name.place(relx=0.35, rely=0.48 + 4/30, relheight=0.16, relwidth=0.6)
        signup_entry_phone.place(relx=0.35, rely=0.64 + 5/30, relheight=0.16, relwidth=0.6)

        signup_btn_signup = Button(page, text='Sign Up', font=("Cambria",14), fg="#FFFFFF", bg="#4554C0",cursor='hand2', command=lambda: (func_sign_up(signup_entry_id.get(), signup_entry_pw.get(), signup_entry_nickname.get(), signup_entry_name.get(), signup_entry_phone.get())))
        signup_btn_back = Button(page, text="Back to Menu", font=("Cambria",14), fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda: (erase_child_with(page, 3), design_page_start("start")))
        signup_btn_signup.place(relx=0.708, rely=0.82, relheight=0.06, relwidth=0.115)
        signup_btn_back.place(relx=0.84, rely=0.82, relheight=0.06, relwidth=0.115)

    elif access_type == "find info":
        findinfo_frame = Frame(page, bg='#FFFFFF', highlightbackground="#4664C0", highlightthickness=4)
        findinfo_frame.place(relx = 0.83, rely =0.35 , relheight = 0.3, relwidth = 0.25, anchor=N)

        findinfo_btn_id = Button(findinfo_frame, text="Find ID", font=("Cambria",14), fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda: (erase_child_with(page, 3), design_page_start('find id')))
        findinfo_btn_pw = Button(findinfo_frame, text="Reset Password", font=("Cambria",14), fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda: (erase_child_with(page, 3), design_page_start('reset pw')))
        findinfo_btn_back_login = Button(page, text="Back to Log in", font=("Cambria",14), fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda: (erase_child_with(page, 3), design_page_start("log in")))
        findinfo_btn_back_start = Button(page, text="Back to Menu", font=("Cambria",14), fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda: (erase_child_with(page, 3), design_page_start("start")))
        findinfo_btn_id.place(relx=0.1, rely=0.1, relwidth=0.8, relheight=0.35)
        findinfo_btn_pw.place(relx=0.1, rely=0.55, relwidth=0.8, relheight=0.35)
        findinfo_btn_back_login.place(relx=0.705, rely=0.665, relheight=0.06, relwidth=0.12)
        findinfo_btn_back_start.place(relx=0.836, rely=0.665, relheight=0.06, relwidth=0.12)

    elif access_type == "find id":
        findid_frame = Frame(page, bg='#FFFFFF', highlightbackground="#4664C0", highlightthickness=4)
        findid_frame.place(relx=0.83, rely=0.4, relheight=0.2, relwidth=0.25, anchor=N)

        findid_label_name = Label(findid_frame, text="Name",font=("Cambria", 12), fg="#4554C0", bg="#FFFFFF")
        findid_label_phone = Label(findid_frame, text="Phone(with -)", font=("Cambria", 12), fg="#4554C0", bg="#FFFFFF")
        findid_entry_name = Entry(findid_frame, font=("Cambria", 12), width=20)
        findid_entry_phone = Entry(findid_frame, font=("Cambria", 12), width=20)
        findid_label_name.place(relx=0, rely=1/15, relheight=0.4, relwidth=0.38)
        findid_label_phone.place(relx=0, rely=0.4+2/15, relheight=0.4, relwidth=0.38)
        findid_entry_name.place(relx=0.4, rely=1/15, relheight=0.4, relwidth=0.55)
        findid_entry_phone.place(relx=0.4, rely=0.4+2/15, relheight=0.4, relwidth=0.55)

        findid_btn_find = Button(page, text="Find", font=("Cambria", 14), fg="#FFFFFF", bg="#4554C0",cursor='hand2', command=lambda: (func_find_id(findid_entry_name.get(), findid_entry_phone.get())))
        findid_btn_back = Button(page, text="Back", font=("Cambria", 14), fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda:(erase_child_with(page, 3), design_page_start("find info")))
        findid_btn_find.place(relx=0.705, rely=0.615, relheight=0.06, relwidth=0.12)
        findid_btn_back.place(relx=0.836, rely=0.615, relheight=0.06, relwidth=0.12)

    elif access_type == "reset pw":
        resetpw_frame = Frame(page, bg='#FFFFFF', highlightbackground="#4664C0", highlightthickness=4)
        resetpw_frame.place(relx=0.83, rely=0.4, relheight=0.2, relwidth=0.25, anchor=N)

        resetpw_label_id = Label(resetpw_frame, text="ID", font=("Cambria", 12), fg="#4554C0", bg="#FFFFFF")
        resetpw_label_phone = Label(resetpw_frame, text="Phone(with -)", font=("Cambria", 12), fg="#4554C0", bg="#FFFFFF")
        resetpw_entry_id = Entry(resetpw_frame, font=("Cambria", 12), width=20)
        resetpw_entry_phone = Entry(resetpw_frame, font=("Cambria", 12), width=20)
        resetpw_label_id.place(relx=0, rely=1/15, relheight=0.4, relwidth=0.38)
        resetpw_label_phone.place(relx=0, rely=0.4+2/15, relheight=0.4, relwidth=0.38)
        resetpw_entry_id.place(relx=0.4, rely=1/15, relheight=0.4, relwidth=0.55)
        resetpw_entry_phone.place(relx=0.4, rely=0.4+2/15, relheight=0.4, relwidth=0.55)

        resetpw_btn_reset = Button(page, text="Reset", font=("Cambria",14), fg="#FFFFFF", bg="#4554C0",cursor='hand2', command=lambda: (func_reset_pw(resetpw_entry_id.get(), resetpw_entry_phone.get())))
        resetpw_btn_back = Button(page, text="Back", font=("Cambria",14), fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda:(erase_child_with(page, 3), design_page_start("find info")))
        resetpw_btn_reset.place(relx=0.705, rely=0.615, relheight=0.06, relwidth=0.12)
        resetpw_btn_back.place(relx=0.836, rely=0.615, relheight=0.06, relwidth=0.12)
    page.mainloop()

def open_page_main():
    erase_child_all(page)
    design_page_main_type()

def design_page_main_type():
    main_frame_type = Frame(page, bg='#FFFFFF', highlightbackground="#FFFFFF", highlightthickness=1)
    main_frame_type.place(relx=0, rely=0, relheight=1, relwidth=0.11)

    main_btn1 = Button(main_frame_type, activeforeground="#4554C0", activebackground="#FFFFFF", text="STAT", font=("Cambria",16), fg="#FFFFFF", bg="#4554C0", borderwidth = 0, cursor='hand2', command=lambda:(func_change_BtnColor(main_btn1, main_btn2, main_btn3, main_btn4, 1), design_page_main_screen(1, screen_frame)))
    main_btn2 = Button(main_frame_type, activeforeground="#4554C0", activebackground="#FFFFFF", text="COMPARE", font=("Cambria",16), fg="#FFFFFF", bg="#4554C0", borderwidth = 0, cursor='hand2', command=lambda:(func_change_BtnColor(main_btn1, main_btn2, main_btn3, main_btn4, 2), design_page_main_screen(2, screen_frame)))
    main_btn3 = Button(main_frame_type, activeforeground="#4554C0", activebackground="#FFFFFF", text="SALARY", font=("Cambria",16), fg="#FFFFFF", bg="#4554C0", borderwidth = 0, cursor='hand2', command=lambda:(func_change_BtnColor(main_btn1, main_btn2, main_btn3, main_btn4, 3), design_page_main_screen(3, screen_frame)))
    main_btn4 = Button(main_frame_type, activeforeground="#4554C0", activebackground="#FFFFFF", text="MY PAGE", font=("Cambria",16), fg="#FFFFFF", bg="#4554C0", borderwidth = 0, cursor='hand2', command=lambda:(func_change_BtnColor(main_btn1, main_btn2, main_btn3, main_btn4, 4), design_page_main_screen(4, screen_frame)))
    main_btn1.place(relx=0, rely=0, relheight=0.25,relwidth=1)
    main_btn2.place(relx=0, rely=0.25, relheight=0.25, relwidth=1)
    main_btn3.place(relx=0, rely=0.5, relheight=0.25, relwidth=1)
    main_btn4.place(relx=0, rely=0.75, relheight=0.25, relwidth=1)

    global screen_frame
    screen_frame = Frame(page, bg='#FFFFFF')
    screen_frame.place(relx=0.11, rely=0, relheight=1, relwidth=0.89)

    main_img = ImageTk.PhotoImage(Image.open("Image\img_main2.png").resize((1200, 630)))
    main_label_img = Label(screen_frame, image=main_img)
    main_label_img.place(relwidth=1, relheight=1)

    page.mainloop()

def design_page_main_screen(btn_choice, screen):
    erase_child_all(screen)

    if (btn_choice == 1) or (btn_choice==3):
        screen_frame = Frame(screen, bg='#E0E6F8')
        screen_frame.place(relx=0.01, rely=0.135, relheight=0.845, relwidth=0.97)

        frame_QBox = Frame(screen, bg='#E0E6F8')
        frame_QBox.place(relx=0.01, rely=0.02, relheight=0.1, relwidth=0.97)

        entry1_name = Entry(frame_QBox, justify = 'center', font=("Cambria", 12))
        entry1_name.place(relx=0.02, rely=0.2, relheight=0.6, relwidth=0.1)
        entry1_name.insert(0, "Name")

        var_cbbox1 = IntVar()
        cbbox1_year = ttk.Combobox(frame_QBox, height=20, textvariable=var_cbbox1,
                                   values=["Year", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014",
                                           "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005",
                                           "2004", "2003", "2002"], font=("Cambria", 12), justify="center")
        cbbox1_year.current(0)
        cbbox1_year.place(relx=0.14, rely=0.2, relheight=0.6, relwidth=0.1)

        var_cbbox2 = StringVar()
        cbbox2_team = ttk.Combobox(frame_QBox, height=20, textvariable=var_cbbox2, values=["Team", "두산", "롯데", "삼성", "키움", "한화", "KIA", "KT", "LG", "NC", "SSG", "넥센", "SK", "현대"], font=("Cambria", 12), justify="center")
        cbbox2_team.current(0)
        cbbox2_team.place(relx=0.26, rely=0.2, relheight=0.6, relwidth=0.1)

        if btn_choice == 1:
            btn1_enter = Button(frame_QBox, text="Enter", font=("Cambria", 12), fg="#FFFFFF", bg="#4554C0",
                                cursor='hand2', command=lambda:(func_search_stat(entry1_name.get(), var_cbbox1.get(), var_cbbox2.get(), stat_result1, stat_result2, stat_result3, stat_result4)))
            btn1_enter.place(relx=0.88, rely=0.18, relheight=0.64, relwidth=0.1)

            stat_text1 = Label(screen_frame, text="Defense", font=("Cambria", 15), bg="#E0E6F8", fg="#4554C0", anchor='n')
            stat_text2 = Label(screen_frame, text="Runner", font=("Cambria", 15), bg="#E0E6F8", fg="#4554C0", anchor='n')
            stat_text3 = Label(screen_frame, text="Hitter", font=("Cambria", 15), bg="#E0E6F8", fg="#4554C0", anchor='n')
            stat_text4 = Label(screen_frame, text="Pitcher", font=("Cambria", 15), bg="#E0E6F8", fg="#4554C0", anchor='n')
            stat_text1.place(relx=0.02, rely=0.06, relheight=0.18, relwidth=0.08)
            stat_text2.place(relx=0.02, rely=0.295, relheight=0.18, relwidth=0.08)
            stat_text3.place(relx=0.02, rely=0.53, relheight=0.18, relwidth=0.08)
            stat_text4.place(relx=0.02, rely=0.765, relheight=0.18, relwidth=0.08)

            stat_result1 = Frame(screen_frame, bg='#FFFFFF')
            stat_result2 = Frame(screen_frame, bg='#FFFFFF')
            stat_result3 = Frame(screen_frame, bg='#FFFFFF')
            stat_result4 = Frame(screen_frame, bg='#FFFFFF')
            stat_result1.place(relx=0.105, rely=0.06, relheight=0.18, relwidth=0.87)
            stat_result2.place(relx=0.105, rely=0.295, relheight=0.18, relwidth=0.87)
            stat_result3.place(relx=0.105, rely=0.53, relheight=0.18, relwidth=0.87)
            stat_result4.place(relx=0.105, rely=0.765, relheight=0.18, relwidth=0.87)

            stat_btn_add = Button(frame_QBox, text="Add My Player", font=("Cambria", 12), fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda:(func_add_myplayer(entry1_name.get(), var_cbbox1.get(), var_cbbox2.get())))
            stat_btn_add.place(relx=0.74, rely=0.18, relheight=0.64, relwidth=0.12)
        else:
            btn2_enter = Button(frame_QBox, text="Enter", font=("Cambria", 12), fg="#FFFFFF", bg="#4554C0", cursor='hand2',
                                command=lambda: (func_search_salary(entry1_name.get(), cbbox1_year.get(), cbbox2_team.get(), temp_label1)))
            btn2_enter.place(relx=0.88, rely=0.18, relheight=0.64, relwidth=0.1)
            temp_text1 = Label(screen_frame, text="Salary", font=("Cambria", 15), bg="#E0E6F8", fg="#4554C0", anchor='n')
            temp_text1.place(relx=0.02, rely=0.06, relheight=0.18, relwidth=0.1)
            temp_result1 = Frame(screen_frame, bg='#FFFFFF')
            temp_result1.place(relx=0.12, rely=0.06, relheight=0.18, relwidth=0.83)
            temp_label1 = Label(temp_result1, text=" ", bg="#FFFFFF", font=("Cambria", 14))
            temp_label1.place(relx=0.5, rely=0.33, anchor = 'n')

            sal_img = ImageTk.PhotoImage(Image.open("Image\salary.png").resize((400, 300)))
            sal_label_img = Label(screen_frame, image=sal_img)
            sal_label_img.place(relx = 0.125, rely = 0.33, relwidth=0.388, relheight=0.56)

            sal2_img = ImageTk.PhotoImage(Image.open("Image\salary2.png").resize((400, 300)))
            sal2_label_img = Label(screen_frame, image=sal2_img)
            sal2_label_img.place(relx = 0.565, rely = 0.33, relwidth=0.388, relheight=0.56)




    elif btn_choice == 2:
        case2_frame_position = Frame(screen, bg='#FFFFFF')
        case2_frame_position.place(relx=0.02, rely=0.04, relheight=0.08, relwidth=0.35)

        case2_position_btn1 = Button(case2_frame_position, text="Hitter", font=("Cambria", 12), relief="ridge",
                                     fg="#4554C0", bg="#FFFFFF", cursor='hand2', command=lambda: (func_change_PositionBtnColor(case2_position_btn1, case2_position_btn2, case2_position_btn3, case2_position_btn4, 1), design_page_main_subscreen_compare(screen, 1)))
        case2_position_btn2 = Button(case2_frame_position, text="Pitcher", font=("Cambria", 12), relief="ridge",
                                     fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda: (func_change_PositionBtnColor(case2_position_btn1, case2_position_btn2, case2_position_btn3, case2_position_btn4, 2), design_page_main_subscreen_compare(screen, 2)))
        case2_position_btn3 = Button(case2_frame_position, text="Defense", font=("Cambria", 12), relief="ridge",
                                     fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda: (func_change_PositionBtnColor(case2_position_btn1, case2_position_btn2, case2_position_btn3, case2_position_btn4, 3), design_page_main_subscreen_compare(screen, 3)))
        case2_position_btn4 = Button(case2_frame_position, text="Runner", font=("Cambria", 11), relief="ridge",
                                     fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda: (func_change_PositionBtnColor(case2_position_btn1, case2_position_btn2, case2_position_btn3, case2_position_btn4, 4), design_page_main_subscreen_compare(screen, 4)))
        #case2_position_btn5 = Button(case2_frame_position, text="My Player", font=("Cambria", 12), relief="ridge",
        #                             fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda: (func_change_PositionBtnColor(case2_position_btn1, case2_position_btn2, case2_position_btn3, case2_position_btn4,  5), design_page_main_subscreen_compare(screen, 5)))
        case2_position_btn1.place(relx=0, rely=0.1, relheight=0.8, relwidth=0.17)
        case2_position_btn2.place(relx=0.17 + 0.07/4, rely=0.1, relheight=0.8, relwidth=0.17)
        case2_position_btn3.place(relx=0.34 + 0.14/4, rely=0.1, relheight=0.8, relwidth=0.17)
        case2_position_btn4.place(relx=0.51 + 0.21/4, rely=0.1, relheight=0.8, relwidth=0.17)
        #case2_position_btn5.place(relx=0.68 + 0.28/4, rely=0.1, relheight=0.8, relwidth=0.25)

        design_page_main_subscreen_compare(screen, 1)

    elif btn_choice == 4:
        mp_frame_main = Frame(screen, bg='#E0E6F8')
        mp_frame_main.place(relx=0.01, rely=0.01, relheight=0.97, relwidth=0.97)

        mp_frame_info = Frame(mp_frame_main, bg='#FFFFFF')
        mp_frame_info.place(relx=0.04, rely=0.045, relheight=0.31, relwidth=0.62)

        mp_img = ImageTk.PhotoImage(Image.open("Image/"+user_info[5]+".png").resize((100, 100)))
        mp_img_label = Label(mp_frame_main, image=mp_img)
        mp_img_label.place(relx=0.05, rely=0.06, relwidth=170/1068, relheight=170/630)

        mp_label_nickname = Label(mp_frame_info, text="nickname : ", font=("Cambria", 16), fg="#4554C0", bg="#FFFFFF", anchor="se")
        mp_label_nickname.place(relx=0.30, rely=0.08, relwidth=0.17, relheight=0.4)
        mp_label_Usernickname = Label(mp_frame_info, text = user_info[2], font=("Cambria", 40), fg="#4554C0", bg="#FFFFFF", anchor="sw")
        mp_label_Usernickname.place(relx=0.47, rely=0.1, relwidth=0.5, relheight=0.4)
        mp_label_name = Label(mp_frame_info, text="name : ", font=("Cambria", 16), fg="#4554C0", bg="#FFFFFF", anchor="se")
        mp_label_name.place(relx=0.30, rely=0.5, relwidth=0.17, relheight=0.2)
        mp_label_Username = Label(mp_frame_info, text=user_info[3], font=("Cambria", 14), fg="#4554C0", bg="#FFFFFF", anchor="sw")
        mp_label_Username.place(relx=0.47, rely=0.5, relwidth=0.5, relheight=0.2)
        mp_label_phone = Label(mp_frame_info, text="phone : ", font=("Cambria", 16), fg="#4554C0", bg="#FFFFFF", anchor="se")
        mp_label_phone.place(relx=0.30, rely=0.7, relwidth=0.17, relheight=0.2)
        mp_label_Userphone = Label(mp_frame_info, text=user_info[4], font=("Cambria", 16), fg="#4554C0", bg="#FFFFFF", anchor="sw")
        mp_label_Userphone.place(relx=0.47, rely=0.7, relwidth=0.5, relheight=0.2)

        mp_frame_BtnCase = Frame(mp_frame_main, bg='#FFFFFF')
        mp_frame_BtnCase.place(relx=0.68, rely=0.045, relheight=0.31, relwidth=0.28)

        mp_btn_change_image = Button(mp_frame_BtnCase, text="Change Profile Image", font=("Cambria", 14), relief="ridge", fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda:(open_page_change_ProfileImage()))
        mp_btn_change_image.place(relx=0.1, rely=0.07, relheight=0.4, relwidth=0.8)
        mp_btn_change_info = Button(mp_frame_BtnCase, text="Update Personal Information", font=("Cambria", 13), relief="ridge", fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda:(open_page_update_PersonalInfo()))
        mp_btn_change_info.place(relx=0.1, rely=0.53, relheight=0.4, relwidth=0.8)

        mp_frame_players = Frame(mp_frame_main, bg='#FFFFFF')
        mp_frame_players.place(relx=0.04, rely=0.4, relheight=0.48, relwidth=0.92)

        mp_frame_players_content = Frame(mp_frame_players, bg="#FFFFFF")
        mp_frame_players_content.place(relx=0.01, rely=0.02, relheight=0.96, relwidth=0.98)

        data_my_players = fetch("SELECT m.player_name, m.year_name, m.team_name FROM my_player m JOIN login l USING (user_id) WHERE l.id = '"+user_info[0]+"'")
        mp_row = 1
        mp_rows = 0
        mp_row_size = 1/7
        for i in data_my_players:
            if mp_rows < 7:
                Label(mp_frame_players_content, text = str(mp_row), font=("Cambria",14), bg="#4554C0", fg="#FFFFFF").place(relx=0, rely=mp_row_size*(mp_row-1), relheight=mp_row_size, relwidth=0.1)
                Label(mp_frame_players_content, text = i[0], bg="#FFFFFF", font=("Cambria",14)).place(relx=0.1, rely=mp_row_size*(mp_row-1), relheight=mp_row_size, relwidth=0.2)
                Label(mp_frame_players_content, text = i[1], font=("Cambria",14)).place(relx=0.3, rely=mp_row_size*(mp_row-1), relheight=mp_row_size, relwidth=0.2)
                Label(mp_frame_players_content, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.5, rely=mp_row_size * (mp_row-1), relheight=mp_row_size, relwidth=0.2)
                exec('Button(mp_frame_players_content, text="Stats", font=("Cambria",13), bg="#4554C0", fg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(func_mini_stat({}))).place(relx=0.78, rely={}+0.001, relheight={}-0.002, relwidth=0.15)'.format(mp_row, mp_row_size * (mp_row-1), mp_row_size))
                exec('Button(mp_frame_players_content, text="X", bg="#FF0000", fg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(func_del_myplayer({}))).place(relx=0.95, rely={}+0.03, relheight={}-0.06, relwidth=({}-0.06)/3)'.format(mp_row, mp_row_size * (mp_row-1), mp_row_size, mp_row_size))
                mp_row += 1
            mp_rows += 1
        global mp_page_now
        mp_page_now = 1
        global mp_page_total
        mp_page_total = mp_rows//7 + ((mp_rows - (mp_rows//7)*7) != 0)
        #func_prev_page(mp_label_page_now, mp_frame_players_content)
        mp_btn_prev_page = Button(mp_frame_main, text="◀", font=("Cambria", 14), relief="ridge", fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda: (func_prev_page(mp_label_page_now, mp_frame_players, mp_frame_players_content, data_my_players)))
        mp_btn_prev_page.place(relx=0.05, rely=0.91, relwidth=0.04, relheight=0.06)

        mp_label_page_now = Label(mp_frame_main, text=str(mp_page_now)+"/"+str(mp_page_total), font=("Cambria", 14), bg = '#E0E6F8')
        mp_label_page_now.place(relx=0.1, rely=0.91, relwidth=0.04, relheight=0.06)

        mp_btn_next_page = Button(mp_frame_main, text="▶", font=("Cambria", 14), relief="ridge", fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda: (func_next_page(mp_label_page_now, mp_frame_players, mp_frame_players_content, data_my_players)))
        mp_btn_next_page.place(relx=0.15, rely=0.91, relwidth=0.04, relheight=0.06)

        mp_btn_logout = Button(mp_frame_main, text="Log Out", font=("Cambria", 14), relief="ridge", fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda:(msgbox.showinfo("Log Out", "Log out Successfully !"),open_page_start()))
        mp_btn_logout.place(relx=0.88, rely=0.91, relwidth=0.08, relheight=0.06)
    page.mainloop()


def design_page_main_subscreen_compare(screen, btn_choice):
    erase_child_without(screen, 1)
    compare_box[0].clear()
    compare_box[1].clear()
    compare_box[2].clear()

    left = Frame(screen, bg='#E0E6F8')
    right = Frame(screen, bg='#E0E6F8')
    left.place(relx=0.01, rely=0.135, relheight=0.845, relwidth=0.485)
    right.place(relx=0.505, rely=0.135, relheight=0.845, relwidth=0.485)

    last_btn = Button(screen, text="Compare", font=("Cambria", 14), relief="ridge", fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=comparing)
    last_btn.place(relx=0.86, rely=0.04, relheight=0.07, relwidth=0.1)

    if btn_choice == 3:
        choice1_LeftFrame = Frame(left, bg='#F3F3FD', relief="solid", bd=1)
        choice1_LeftFrame.place(relx=0.05, rely=0.03, relheight=0.08, relwidth=0.9)

        choice1_L_cbbox1 = ttk.Combobox(choice1_LeftFrame, height=20,
                                        values=["Year", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014",
                                                "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005",
                                                "2004", "2003", "2002"], font=("Cambria", 12), justify="center")
        choice1_L_cbbox1.current(0)
        choice1_L_cbbox1.place(relx=0.02, rely=0.14, relheight=0.72, relwidth=0.15)

        choice1_L_cbbox2 = ttk.Combobox(choice1_LeftFrame, height=20,
                                        values=["Team", "두산", "롯데", "삼성", "키움", "한화", "KIA", "KT", "LG", "NC", "SSG",
                                                "넥센", "SK", "현대"], font=("Cambria", 12), justify="center")
        choice1_L_cbbox2.current(0)
        choice1_L_cbbox2.place(relx=0.19, rely=0.14, relheight=0.72, relwidth=0.15)

        choice1_L_cbbox3 = ttk.Combobox(choice1_LeftFrame, height=20, values=["Position", "포수", "내야수", "외야수"],
                                      font=("Cambria", 12), justify="center")
        choice1_L_cbbox3.current(0)
        choice1_L_cbbox3.place(relx=0.36, rely=0.14, relheight=0.72, relwidth=0.20)

        choice1_L_cbbox4 = ttk.Combobox(choice1_LeftFrame, height=20, values=["Order By", 'G', 'GS', 'IP', 'E', 'PKO', 'PO', 'A', 'DP', 'FPCT', 'PB', 'SB', 'CS', 'CS%', 'Year'],
                                      font=("Cambria", 12), justify="center")
        choice1_L_cbbox4.current(0)
        choice1_L_cbbox4.place(relx=0.58, rely=0.14, relheight=0.72, relwidth=0.20)

        choice1_L_cb_val = IntVar()
        choice1_L_cb = Checkbutton(choice1_LeftFrame, text=" ", variable=choice1_L_cb_val, onvalue=1, offvalue=0)
        choice1_L_cb.place(relx=0.81, rely=0.23)

        choice1_L_btn1 = Button(choice1_LeftFrame, text="Enter", font=("Cambria", 12), fg="#FFFFFF", bg="#4554C0",
                                cursor='hand2', command=lambda:(func_compare1("D", "L", choice1_L_cbbox1.get(), choice1_L_cbbox2.get(), choice1_L_cbbox3.get(),
                                                                   choice1_L_cbbox4.get(), choice1_L_cb_val.get(),
                                                                   left)))
        choice1_L_btn1.place(relx=0.89, rely=0.14, relheight=0.72, relwidth=0.1)



        choice1_RightFrame = Frame(right, bg='#F3F3FD', relief="solid", bd=1)
        choice1_RightFrame.place(relx=0.05, rely=0.03, relheight=0.08, relwidth=0.9)

        choice1_R_cbbox1 = ttk.Combobox(choice1_RightFrame, height=20,
                                        values=["Year", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014",
                                                "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005",
                                                "2004", "2003", "2002"], font=("Cambria", 12), justify="center")
        choice1_R_cbbox1.current(0)
        choice1_R_cbbox1.place(relx=0.02, rely=0.14, relheight=0.72, relwidth=0.15)

        choice1_R_cbbox2 = ttk.Combobox(choice1_RightFrame, height=20,
                                        values=["Team", "두산", "롯데", "삼성", "키움", "한화", "KIA", "KT", "LG", "NC", "SSG",
                                                "넥센", "SK", "현대"],
                                        font=("Cambria", 12), justify="center")
        choice1_R_cbbox2.current(0)
        choice1_R_cbbox2.place(relx=0.19, rely=0.14, relheight=0.72, relwidth=0.15)

        choice1_R_cbbox3 = ttk.Combobox(choice1_RightFrame, height=20, values=["Position", "포수", "내야수", "외야수"],
                                        font=("Cambria", 12), justify="center")
        choice1_R_cbbox3.current(0)
        choice1_R_cbbox3.place(relx=0.36, rely=0.14, relheight=0.72, relwidth=0.20)

        choice1_R_cbbox4 = ttk.Combobox(choice1_RightFrame, height=20,
                                        values=["Order By", 'G', 'GS', 'IP', 'E', 'PKO', 'PO', 'A', 'DP', 'FPCT',
                                                'PB', 'SB', 'CS', 'CS%', 'Year'],
                                        font=("Cambria", 12), justify="center")
        choice1_R_cbbox4.current(0)
        choice1_R_cbbox4.place(relx=0.58, rely=0.14, relheight=0.72, relwidth=0.20)

        choice1_R_cb_val = IntVar()
        choice1_R_cb = Checkbutton(choice1_RightFrame, text=" ", variable=choice1_R_cb_val, onvalue=1, offvalue=0)
        choice1_R_cb.place(relx=0.81, rely=0.23)


        choice1_R_btn1 = Button(choice1_RightFrame, text="Enter", font=("Cambria", 12), fg="#FFFFFF", bg="#4554C0",
                                cursor='hand2', command=lambda:(func_compare1("D", "R", choice1_R_cbbox1.get(), choice1_R_cbbox2.get(), choice1_R_cbbox3.get(),
                                                                   choice1_R_cbbox4.get(), choice1_R_cb_val.get(),
                                                                   right)))
        choice1_R_btn1.place(relx=0.89, rely=0.14, relheight=0.72, relwidth=0.1)

        choice2_L_frame = Frame(left, bg='#FFFFFF')
        choice2_L_frame.place(relx=0.05, rely=0.14, relheight=0.76, relwidth=0.9)

        choice2_R_frame = Frame(right, bg='#FFFFFF')
        choice2_R_frame.place(relx=0.05, rely=0.14, relheight=0.76, relwidth=0.9)
    else:
        choice2_LeftFrame = Frame(left, bg='#F3F3FD', relief="solid", bd=1)
        choice2_LeftFrame.place(relx=0.05, rely=0.03, relheight=0.08, relwidth=0.9)

        choice2_L_cbbox1 = ttk.Combobox(choice2_LeftFrame, height=20,
                                        values=["Year", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014",
                                                "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005",
                                                "2004", "2003", "2002"], font=("Cambria", 12), justify="center")
        choice2_L_cbbox1.current(0)
        choice2_L_cbbox1.place(relx=0.02, rely=0.14, relheight=0.72, relwidth=0.15)

        choice2_L_cbbox2 = ttk.Combobox(choice2_LeftFrame, height=20,
                                        values=["Team", "두산", "롯데", "삼성", "키움", "한화", "KIA", "KT", "LG", "NC", "SSG",
                                                "넥센", "SK", "현대"],
                                        font=("Cambria", 12), justify="center")
        choice2_L_cbbox2.current(0)
        choice2_L_cbbox2.place(relx=0.19, rely=0.14, relheight=0.72, relwidth=0.15)

        choice2_RightFrame = Frame(right, bg='#F3F3FD', relief="solid", bd=1)
        choice2_RightFrame.place(relx=0.05, rely=0.03, relheight=0.08, relwidth=0.9)

        choice2_R_cbbox1 = ttk.Combobox(choice2_RightFrame, height=20,
                                        values=["Year", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014",
                                                "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005",
                                                "2004", "2003", "2002"], font=("Cambria", 12), justify="center")
        choice2_R_cbbox1.current(0)
        choice2_R_cbbox1.place(relx=0.02, rely=0.14, relheight=0.72, relwidth=0.15)

        choice2_R_cbbox2 = ttk.Combobox(choice2_RightFrame, height=20,
                                        values=["Team", "두산", "롯데", "삼성", "키움", "한화", "KIA", "KT", "LG", "NC", "SSG",
                                                "넥센", "SK", "현대"], font=("Cambria", 12), justify="center")
        choice2_R_cbbox2.current(0)
        choice2_R_cbbox2.place(relx=0.19, rely=0.14, relheight=0.72, relwidth=0.15)

        choice2_L_frame = Frame(left, bg='#FFFFFF')
        choice2_L_frame.place(relx=0.05, rely=0.14, relheight=0.76, relwidth=0.9)

        choice2_R_frame = Frame(right, bg='#FFFFFF')
        choice2_R_frame.place(relx=0.05, rely=0.14, relheight=0.76, relwidth=0.9)

        if btn_choice == 1:
            choice2_L_cbbox4 = ttk.Combobox(choice2_LeftFrame, height=20,
                                            values=["Order By",'AVG', 'G', 'PA', 'AB', 'R', 'H', '2B', '3B', 'HR', 'TB', 'RBI','SAC', 'SF', 'Year', 'BB', 'IBB', 'HBP', 'SO', 'GDP', 'SLG', 'OBP', 'OPS', 'MH', 'RISP', 'PH-BA'],
                                            font=("Cambria", 12), justify="center")
            choice2_L_cbbox4.current(0)
            choice2_L_cbbox4.place(relx=0.36, rely=0.14, relheight=0.72, relwidth=0.20)
            choice2_R_cbbox4 = ttk.Combobox(choice2_RightFrame, height=20,
                                            values=["Order By", 'AVG', 'G', 'PA', 'AB', 'R', 'H', '2B', '3B', 'HR',
                                                    'TB', 'RBI', 'SAC', 'SF', 'Year', 'BB', 'IBB', 'HBP', 'SO', 'GDP',
                                                    'SLG', 'OBP', 'OPS', 'MH', 'RISP', 'PH-BA'],
                                            font=("Cambria", 12), justify="center")
            choice2_R_cbbox4.current(0)
            choice2_R_cbbox4.place(relx=0.36, rely=0.14, relheight=0.72, relwidth=0.20)

            choice2_L_cb_val = IntVar()
            choice2_L_cb = Checkbutton(choice2_LeftFrame, text="Ascending", font=("Cambria", 12), variable=choice2_L_cb_val, onvalue=1, offvalue=0)
            choice2_L_cb.place(relx=0.58, rely=0.15)

            choice2_R_cb_val = IntVar()
            choice2_R_cb = Checkbutton(choice2_RightFrame, text="Ascending", font=("Cambria", 12), variable=choice2_R_cb_val, onvalue=1,
                                       offvalue=0)
            choice2_R_cb.place(relx=0.58, rely=0.15)

            choice2_L_btn1 = Button(choice2_LeftFrame, text="Enter", font=("Cambria", 12), fg="#FFFFFF", bg="#4554C0",
                                    cursor='hand2',
                                    command=lambda: (func_compare1("H", "L", choice2_L_cbbox1.get(), choice2_L_cbbox2.get(), "NO",
                                                                   choice2_L_cbbox4.get(), choice2_L_cb_val.get(), left)))
            choice2_L_btn1.place(relx=0.89, rely=0.14, relheight=0.72, relwidth=0.1)
            choice2_R_btn1 = Button(choice2_RightFrame, text="Enter", font=("Cambria", 12), fg="#FFFFFF", bg="#4554C0",
                                    cursor='hand2',
                                    command=lambda: (func_compare1("H", "R", choice2_R_cbbox1.get(), choice2_R_cbbox2.get(), "NO",
                                                                   choice2_R_cbbox4.get(), choice2_R_cb_val.get(), right)))
            choice2_R_btn1.place(relx=0.89, rely=0.14, relheight=0.72, relwidth=0.1)
        elif btn_choice == 2:
            choice2_L_cbbox4 = ttk.Combobox(choice2_LeftFrame, height=20,
                                            values=["Order By", 'ERA', 'G', 'W', 'L', 'SV', 'HLD', 'WPCT', 'IP', 'H', 'HR', 'BB', 'HBP', 'SO', 'R', 'ER', 'WHIP', 'Year', 'CG', 'SHO', 'QS', 'BSV', 'TBF', 'NP', 'AVG', '2B', '3B', 'SAC', 'SF', 'IBB', 'WP', 'BK'],
                                            font=("Cambria", 12), justify="center")
            choice2_L_cbbox4.current(0)
            choice2_L_cbbox4.place(relx=0.36, rely=0.14, relheight=0.72, relwidth=0.20)
            choice2_R_cbbox4 = ttk.Combobox(choice2_RightFrame, height=20,
                                            values=["Order By", 'ERA', 'G', 'W', 'L', 'SV', 'HLD', 'WPCT', 'IP', 'H',
                                                    'HR', 'BB', 'HBP', 'SO', 'R', 'ER', 'WHIP', 'Year', 'CG', 'SHO',
                                                    'QS', 'BSV', 'TBF', 'NP', 'AVG', '2B', '3B', 'SAC', 'SF', 'IBB',
                                                    'WP', 'BK'],
                                            font=("Cambria", 12), justify="center")
            choice2_R_cbbox4.current(0)
            choice2_R_cbbox4.place(relx=0.36, rely=0.14, relheight=0.72, relwidth=0.20)

            choice2_L_cb_val = IntVar()
            choice2_L_cb = Checkbutton(choice2_LeftFrame, text="Ascending", font=("Cambria", 12),
                                       variable=choice2_L_cb_val, onvalue=1, offvalue=0)
            choice2_L_cb.place(relx=0.58, rely=0.15)

            choice2_R_cb_val = IntVar()
            choice2_R_cb = Checkbutton(choice2_RightFrame, text="Ascending", font=("Cambria", 12),
                                       variable=choice2_R_cb_val, onvalue=1,
                                       offvalue=0)
            choice2_R_cb.place(relx=0.58, rely=0.15)

            choice2_L_btn1 = Button(choice2_LeftFrame, text="Enter", font=("Cambria", 12), fg="#FFFFFF", bg="#4554C0",
                                    cursor='hand2',
                                    command=lambda: (func_compare1("P", "L", choice2_L_cbbox1.get(), choice2_L_cbbox2.get(), "NO",
                                                                   choice2_L_cbbox4.get(), choice2_L_cb_val.get(),
                                                                   left)))
            choice2_L_btn1.place(relx=0.89, rely=0.14, relheight=0.72, relwidth=0.1)
            choice2_R_btn1 = Button(choice2_RightFrame, text="Enter", font=("Cambria", 12), fg="#FFFFFF", bg="#4554C0",
                                    cursor='hand2',
                                    command=lambda: (func_compare1("P", "R", choice2_R_cbbox1.get(), choice2_R_cbbox2.get(), "NO",
                                                                   choice2_R_cbbox4.get(), choice2_R_cb_val.get(),
                                                                   right)))
            choice2_R_btn1.place(relx=0.89, rely=0.14, relheight=0.72, relwidth=0.1)
        else:
            choice2_L_cbbox4 = ttk.Combobox(choice2_LeftFrame, height=20,
                                            values=["Order By", 'G', 'SBA', 'SB', 'CS', 'SB%', 'OOB', 'PKO', 'Year'],
                                            font=("Cambria", 12), justify="center")
            choice2_L_cbbox4.current(0)
            choice2_L_cbbox4.place(relx=0.36, rely=0.14, relheight=0.72, relwidth=0.20)
            choice2_R_cbbox4 = ttk.Combobox(choice2_RightFrame, height=20,
                                            values=["Order By", 'G', 'SBA', 'SB', 'CS', 'SB%', 'OOB', 'PKO', 'Year'],
                                            font=("Cambria", 12), justify="center")
            choice2_R_cbbox4.current(0)
            choice2_R_cbbox4.place(relx=0.36, rely=0.14, relheight=0.72, relwidth=0.20)

            choice2_L_cb_val = IntVar()
            choice2_L_cb = Checkbutton(choice2_LeftFrame, text="Ascending", font=("Cambria", 12),
                                       variable=choice2_L_cb_val, onvalue=1, offvalue=0)
            choice2_L_cb.place(relx=0.58, rely=0.15)

            choice2_R_cb_val = IntVar()
            choice2_R_cb = Checkbutton(choice2_RightFrame, text="Ascending", font=("Cambria", 12),
                                       variable=choice2_R_cb_val, onvalue=1,
                                       offvalue=0)
            choice2_R_cb.place(relx=0.58, rely=0.15)

            choice2_L_btn1 = Button(choice2_LeftFrame, text="Enter", font=("Cambria", 12), fg="#FFFFFF", bg="#4554C0",
                                    cursor='hand2',
                                    command=lambda: (func_compare1("R", "L", choice2_L_cbbox1.get(), choice2_L_cbbox2.get(), "NO",
                                                                   choice2_L_cbbox4.get(), choice2_L_cb_val.get(),
                                                                   left)))
            choice2_L_btn1.place(relx=0.89, rely=0.14, relheight=0.72, relwidth=0.1)
            choice2_R_btn1 = Button(choice2_RightFrame, text="Enter", font=("Cambria", 12), fg="#FFFFFF", bg="#4554C0",
                                    cursor='hand2',
                                    command=lambda: (func_compare1("R", "R", choice2_R_cbbox1.get(), choice2_R_cbbox2.get(), "NO",
                                                                   choice2_R_cbbox4.get(), choice2_R_cb_val.get(),
                                                                   right)))
            choice2_R_btn1.place(relx=0.89, rely=0.14, relheight=0.72, relwidth=0.1)
    page.mainloop()


global user_info
user_info = ['user1', 'password1', 'kbo_lover', '김현우', '010-0001-0001', 'icon15', 1]
compare_box = [[],[], []]

use_database('project')
global page
page = Tk()
page.title("KBO STATS")
page.geometry("1200x630+180+100")
page.resizable = (False, False)

open_page_main()

'''elif btn_choice == 5:
        choice5_L_frame = Frame(left, bg='#FFFFFF')
        choice5_L_frame.place(relx=0.05, rely=0.05, relheight=0.82, relwidth=0.9)

        choice5_R_frame = Frame(right, bg='#FFFFFF')
        choice5_R_frame.place(relx=0.05, rely=0.05, relheight=0.82, relwidth=0.9)
        c1_player = fetch("SELECT m.player_name, m.year_name, m.team_name FROM my_player m JOIN login l USING (user_id) WHERE l.id = '" +user_info[0] + "'")
        c1_row = 1
        c1_rows = 0
        c1_row_size = 1 / 12
        for i in c1_player:
            if c1_rows < 12:
                Label(choice5_L_frame, text=str(c1_row), font=("Cambria", 14), bg="#4554C0", fg="#FFFFFF").place(relx=0, rely=c1_row_size * (c1_row - 1), relheight=c1_row_size, relwidth=0.1)
                Label(choice5_L_frame, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1,
                                                                                                     rely=c1_row_size * (
                                                                                                             c1_row - 1),
                                                                                                     relheight=c1_row_size,
                                                                                                     relwidth=0.3)
                Label(choice5_L_frame, text=i[1], font=("Cambria", 14)).place(relx=0.4,
                                                                                       rely=c1_row_size * (c1_row - 1),
                                                                                       relheight=c1_row_size,
                                                                                       relwidth=0.25)
                Label(choice5_L_frame, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.65,
                                                                                                     rely=c1_row_size * (
                                                                                                             c1_row - 1),
                                                                                                     relheight=c1_row_size,
                                                                                                     relwidth=0.25)
                exec(
                    'Button(choice5_L_frame, text="Select", bg="#4554C0", fg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(fill_box_L_mp({}, {}))).place(relx=0.80, rely={}, relheight={}, relwidth=0.2)'.format(
                        c1_row, c1_player, c1_row_size * c1_rows, c1_row_size))
                c1_row += 1
            c1_rows += 1
        global c1_page_now
        c1_page_now = 1
        global c1_page_total
        c1_page_total = c1_rows // 12 + ((c1_rows - (c1_rows // 12) * 12) != 0)
        c1_btn_prev_page = Button(left, text="◀", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                  bg="#4554C0", cursor='hand2', command=lambda: (func_prev_page_c1(c1_label_page_now, left, choice5_L_frame, c1_player)))
        c1_btn_prev_page.place(relx=0.05, rely=0.91, relwidth=0.07, relheight=0.06)

        c1_label_page_now = Label(left, text=str(c1_page_now) + "/" + str(c1_page_total), font=("Cambria", 14),
                                  bg='#E0E6F8')
        c1_label_page_now.place(relx=0.13, rely=0.91, relwidth=0.07, relheight=0.06)

        c1_btn_next_page = Button(left, text="▶", font=("Cambria", 14), relief="ridge", fg="#FFFFFF", bg="#4554C0", cursor='hand2', command=lambda: (func_next_page_c1(c1_label_page_now, left, choice5_L_frame, c1_player)))
        c1_btn_next_page.place(relx=0.21, rely=0.91, relwidth=0.07, relheight=0.06)

        c2_player = fetch(
            "SELECT m.player_name, m.year_name, m.team_name FROM my_player m JOIN login l USING (user_id) WHERE l.id = '" +
            user_info[0] + "'")
        c2_row = 1
        c2_rows = 0
        c2_row_size = 1 / 12
        for i in c2_player:
            if c2_rows < 12:
                Label(choice5_R_frame, text=str(c2_row), font=("Cambria", 14), bg="#4554C0", fg="#FFFFFF").place(relx=0,
                                                                                                                 rely=c2_row_size * (
                                                                                                                             c2_row - 1),
                                                                                                                 relheight=c2_row_size,
                                                                                                                 relwidth=0.1)
                Label(choice5_R_frame, text=i[0], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.1,
                                                                                            rely=c2_row_size * (
                                                                                                    c2_row - 1),
                                                                                            relheight=c2_row_size,
                                                                                            relwidth=0.3)
                Label(choice5_R_frame, text=i[1], font=("Cambria", 14)).place(relx=0.4,
                                                                              rely=c2_row_size * (c2_row - 1),
                                                                              relheight=c2_row_size,
                                                                              relwidth=0.25)
                Label(choice5_R_frame, text=i[2], bg="#FFFFFF", font=("Cambria", 14)).place(relx=0.65,
                                                                                            rely=c2_row_size * (
                                                                                                    c2_row - 1),
                                                                                            relheight=c2_row_size,
                                                                                            relwidth=0.25)
                exec(
                    'Button(choice5_L_frame, text="Select", bg="#4554C0", fg="#FFFFFF", relief="ridge",cursor="hand2", command=lambda:(fill_box_R_mp({}, {}))).place(relx=0.80, rely={}, relheight={}, relwidth=0.2)'.format(
                        c2_row, c2_player, c2_row_size * c2_rows, c2_row_size))
                c2_row += 1
            c2_rows += 1
        global c2_page_now
        c2_page_now = 1
        global c2_page_total
        c2_page_total = c2_rows // 12 + ((c2_rows - (c2_rows // 12) * 12) != 0)
        c2_btn_prev_page = Button(right, text="◀", font=("Cambria", 14), relief="ridge", fg="#FFFFFF",
                                  bg="#4554C0", cursor='hand2', command=lambda: (
                func_prev_page_c1(c2_label_page_now, right, choice5_R_frame, c2_player)))
        c2_btn_prev_page.place(relx=0.05, rely=0.91, relwidth=0.07, relheight=0.06)

        c2_label_page_now = Label(right, text=str(c2_page_now) + "/" + str(c2_page_total), font=("Cambria", 14),
                                  bg='#E0E6F8')
        c2_label_page_now.place(relx=0.13, rely=0.91, relwidth=0.07, relheight=0.06)

        c2_btn_next_page = Button(right, text="▶", font=("Cambria", 14), relief="ridge", fg="#FFFFFF", bg="#4554C0",
                                  cursor='hand2', command=lambda: (
                func_next_page_c1(c2_label_page_now, right, choice5_R_frame, c1_player)))
        c2_btn_next_page.place(relx=0.21, rely=0.91, relwidth=0.07, relheight=0.06)'''