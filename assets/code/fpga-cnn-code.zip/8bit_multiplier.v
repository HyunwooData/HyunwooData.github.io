`timescale 1ns / 1ps

module Multiplier_8bit(
  input [7:0]a,
  input [7:0]b,
  output [7:0]cout 
);

wire m00, m10, m20, m30, m40, m50, m60, m70,
     m01, m11, m21, m31, m41, m51, m61,
     m02, m12, m22, m32, m42, m52,
     m03, m13, m23, m33, m43,
     m04, m14, m24, m34,
     m05, m15, m25,
     m06, m16,
     m07;

wire s10, s11, s12, s13, s14, s15, s16,
     s20, s21, s22, s23, s24, s25,
     s30, s31, s32, s33, s34,
     s40, s41, s42, s43,
     s50, s51, s52,
     s60, s61,
     s70;

wire c10, c11, c12, c13, c14, c15,
     c20, c21, c22, c23, c24,
     c30, c31, c32, c33,
     c40, c41, c42,
     c50, c51,
     c60;

and_gate and_gate01(.a(a[0]), .b(b[0]), .out(m00));
and_gate and_gate02(.a(a[1]), .b(b[0]), .out(m10));
and_gate and_gate03(.a(a[2]), .b(b[0]), .out(m20));
and_gate and_gate04(.a(a[3]), .b(b[0]), .out(m30));
and_gate and_gate05(.a(a[4]), .b(b[0]), .out(m40));
and_gate and_gate06(.a(a[5]), .b(b[0]), .out(m50));
and_gate and_gate07(.a(a[6]), .b(b[0]), .out(m60));
and_gate and_gate08(.a(a[7]), .b(b[0]), .out(m70));

and_gate and_gate09(.a(a[0]), .b(b[1]), .out(m01));
and_gate and_gate10(.a(a[1]), .b(b[1]), .out(m11));
and_gate and_gate11(.a(a[2]), .b(b[1]), .out(m21));
and_gate and_gate12(.a(a[3]), .b(b[1]), .out(m31));
and_gate and_gate13(.a(a[4]), .b(b[1]), .out(m41));
and_gate and_gate14(.a(a[5]), .b(b[1]), .out(m51));
and_gate and_gate15(.a(a[6]), .b(b[1]), .out(m61));

and_gate and_gate16(.a(a[0]), .b(b[2]), .out(m02));
and_gate and_gate17(.a(a[1]), .b(b[2]), .out(m12));
and_gate and_gate18(.a(a[2]), .b(b[2]), .out(m22));
and_gate and_gate19(.a(a[3]), .b(b[2]), .out(m32));
and_gate and_gate20(.a(a[4]), .b(b[2]), .out(m42));
and_gate and_gate21(.a(a[5]), .b(b[2]), .out(m52));

and_gate and_gate22(.a(a[0]), .b(b[3]), .out(m03));
and_gate and_gate23(.a(a[1]), .b(b[3]), .out(m13));
and_gate and_gate24(.a(a[2]), .b(b[3]), .out(m23));
and_gate and_gate25(.a(a[3]), .b(b[3]), .out(m33));
and_gate and_gate26(.a(a[4]), .b(b[3]), .out(m43));

and_gate and_gate27(.a(a[0]), .b(b[4]), .out(m04));
and_gate and_gate28(.a(a[1]), .b(b[4]), .out(m14));
and_gate and_gate29(.a(a[2]), .b(b[4]), .out(m24));
and_gate and_gate30(.a(a[3]), .b(b[4]), .out(m34));

and_gate and_gate31(.a(a[0]), .b(b[5]), .out(m05));
and_gate and_gate32(.a(a[1]), .b(b[5]), .out(m15));
and_gate and_gate33(.a(a[2]), .b(b[5]), .out(m25));

and_gate and_gate34(.a(a[0]), .b(b[6]), .out(m06));
and_gate and_gate35(.a(a[1]), .b(b[6]), .out(m16));

and_gate and_gate36(.a(a[0]), .b(b[7]), .out(m07));

full_adder full_adder1(.a(m10), .b(m01), .cin(1'b0), .sum(s10), .cout(c10));
full_adder full_adder2(.a(m20), .b(m11), .cin(c10), .sum(s11), .cout(c11));
full_adder full_adder3(.a(m30), .b(m21), .cin(c11), .sum(s12), .cout(c12));
full_adder full_adder4(.a(m40), .b(m31), .cin(c12), .sum(s13), .cout(c13));
full_adder full_adder5(.a(m50), .b(m41), .cin(c13), .sum(s14), .cout(c14));
full_adder full_adder6(.a(m60), .b(m51), .cin(c14), .sum(s15), .cout(c15));
full_adder full_adder7(.a(m70), .b(m61), .cin(c15), .sum(s16), .cout());

full_adder full_adder8(.a(s11), .b(m02), .cin(1'b0), .sum(s20), .cout(c20));
full_adder full_adder9(.a(s12), .b(m12), .cin(c20), .sum(s21), .cout(c21));
full_adder full_adder10(.a(s13), .b(m22), .cin(c21), .sum(s22), .cout(c22));
full_adder full_adder11(.a(s14), .b(m32), .cin(c22), .sum(s23), .cout(c23));
full_adder full_adder12(.a(s15), .b(m42), .cin(c23), .sum(s24), .cout(c24));
full_adder full_adder13(.a(s16), .b(m52), .cin(c24), .sum(s25), .cout());

full_adder full_adder14(.a(s21), .b(m03), .cin(1'b0), .sum(s30), .cout(c30));
full_adder full_adder15(.a(s22), .b(m13), .cin(c30), .sum(s31), .cout(c31));
full_adder full_adder16(.a(s23), .b(m23), .cin(c31), .sum(s32), .cout(c32));
full_adder full_adder17(.a(s24), .b(m33), .cin(c32), .sum(s33), .cout(c33));
full_adder full_adder18(.a(s25), .b(m43), .cin(c33), .sum(s34), .cout());

full_adder full_adder19(.a(s31), .b(m04), .cin(1'b0), .sum(s40), .cout(c40));
full_adder full_adder20(.a(s32), .b(m14), .cin(c40), .sum(s41), .cout(c41));
full_adder full_adder21(.a(s33), .b(m24), .cin(c41), .sum(s42), .cout(c42));
full_adder full_adder22(.a(s34), .b(m34), .cin(c42), .sum(s43), .cout());

full_adder full_adder23(.a(s41), .b(m05), .cin(1'b0), .sum(s50), .cout(c50));
full_adder full_adder24(.a(s42), .b(m15), .cin(c50), .sum(s51), .cout(c51));
full_adder full_adder25(.a(s43), .b(m25), .cin(c51), .sum(s52), .cout());

full_adder full_adder26(.a(s51), .b(m06), .cin(1'b0), .sum(s60), .cout(c60));
full_adder full_adder27(.a(s52), .b(m16), .cin(c60), .sum(s61), .cout());

full_adder full_adder28(.a(s61), .b(m07), .cin(1'b0), .sum(s70), .cout());


assign cout[0] = m00;
assign cout[1] = s10;
assign cout[2] = s20;
assign cout[3] = s30;
assign cout[4] = s40;
assign cout[5] = s50;
assign cout[6] = s60;
assign cout[7] = s70;

endmodule

