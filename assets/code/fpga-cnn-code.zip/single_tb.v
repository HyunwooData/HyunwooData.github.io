`timescale 1ns / 1ps

module single_tb();
  reg clk, rst, pe_active;
 
  reg [7:0] a11, a12, a13, a14,
            a21, a22, a23, a24,
            a31, a32, a33, a34,
            a41, a42, a43, a44;

  reg [7:0] b11, b12, b13,
            b21, b22, b23,
            b31, b32, b33;
  
  /* ------------------------------------------ Assign W/R -------------------------------------------------- */
 
  //wire c11_active, c12_active, c21_active, c22_active;
  wire pe_done;
  //wire [7:0] pe_out;
  
  wire [7:0] s_c11, s_c12, s_c21, s_c22;
  wire s_active;
  
  /* ------------------------------------------ Mapping Single_PE port for single_tb -------------------------------------------------- */

  Single_PE test_single (
    .clk         (clk),
    .rst         (rst),
    .pe_active   (pe_active),
    
    // 4x4 Input Matrix
    .a11(a11), .a12(a12), .a13(a13), .a14(a14), 
    .a21(a21), .a22(a22), .a23(a23), .a24(a24),
    .a31(a31), .a32(a32), .a33(a33), .a34(a34), 
    .a41(a41), .a42(a42), .a43(a43), .a44(a44),

    // 3x3 Kernel (Filter)
    .b11(b11), .b12(b12), .b13(b13), 
    .b21(b21), .b22(b22), .b23(b23), 
    .b31(b31), .b32(b32), .b33(b33),

    // Cout active signals
    //.c11_active(c11_active),
    //.c12_active(c12_active),
    //.c21_active(c21_active),
    //.c22_active(c22_active),
    .s_active(s_active),
    
    .s_c11(s_c11),
    .s_c12(s_c12),
    .s_c21(s_c21),
    .s_c22(s_c22),
    // Sum & done
    .pe_done   (pe_done)
    //.pe_out  (pe_out)
  );

  /* ------------------------------------------ single tb Condition statement -------------------------------------------------- */

  always #10 clk = ~clk;  

  initial begin
    clk       = 1'b0;
    rst       = 1'b1;
    pe_active = 1'b0;

    #15 rst       = 1'b0;
    #5  pe_active = 1'b1;

    #35 pe_active = 1'b0;

  end

  initial begin
    // 4x4 matrix A
    a11=8'd1;   a12=8'd2;   a13=8'd3;   a14=8'd4;
    a21=8'd5;   a22=8'd6;   a23=8'd7;   a24=8'd8;
    a31=8'd9;   a32=8'd10;  a33=8'd11;  a34=8'd12;
    a41=8'd13;  a42=8'd14;  a43=8'd15;  a44=8'd16;

    // 3x3 filter B
    b11=8'd1;  b12=8'd2;  b13=8'd3;
    b21=8'd4;  b22=8'd5;  b23=8'd6;
    b31=8'd7;  b32=8'd8;  b33=8'd9;
  end    

endmodule
