import pandas as pd
import os
import pickle

def file_import():
    file_path = os.getcwd() + '/data'
    try:
        defense = pd.read_csv(f'{file_path}/수비1107_ansi2.csv', encoding='ansi')
        salary = pd.read_csv(f'{file_path}/연봉1107_ansi.csv', encoding='ansi')
        runner = pd.read_csv(f'{file_path}/주루1107_ansi.csv', encoding = 'ansi')
        hitter = pd.read_csv(f'{file_path}/타자병합1107_ansi.csv', encoding = 'ansi')
        pitcher = pd.read_csv(f'{file_path}/투수병합1107_ansi.csv', encoding='ansi')
        
        return defense, salary, runner, hitter, pitcher
    except:
        print('File Open Error, Please Check the directory')


def model_import():
    file_path = os.getcwd() + '/data'
    try:
        with open(f'{file_path}/batter_model1122.pkl', 'rb') as f:
            batter_model = pickle.load(f)
        with open(f'{file_path}/pitcher_model1122.pkl', 'rb') as f:
            pitcher_model = pickle.load(f)
        
        return batter_model, pitcher_model
    except:
        print('Model open Error, Please Check the directory')