`timescale 1ns / 1ps

module PE (
  input clk, rst,
  input filter_active, matrix_active, sum_active,
  
  input  [7:0] sum_in,
  input  [7:0] matrix_in, filter_in,
  
  output [7:0] matrix_out, filter_out,
  output [7:0] sum_out
); 

  // Internal computation wires
  wire [7:0] mul_out;
  wire [7:0] sum_next;

  // Register storage (buffer)
  wire [7:0] matrix_buffer;
  wire [7:0] filter_buffer;
  wire [7:0] sum_buffer;

  // Matrix (Activation) Register
  Register matrix_reg (
    .clk(clk),
    .rst(rst),
    .active(matrix_active),
    .in(matrix_in),
    .out(matrix_buffer)
  );
  
  // Filter (Weight) Register
  Register filter_reg (
    .clk(clk),
    .rst(rst),
    .active(filter_active),
    .in(filter_in),
    .out(filter_buffer)
  );
  
  // Partial Sum Register
  Register sum_reg (
    .clk(clk),
    .rst(rst),
    .active(sum_active),
    .in(sum_in),
    .out(sum_buffer)
  );
  
  // Multiplier: matrix x filter
  Multiplier_8bit multiplier (
    .a  (matrix_buffer),
    .b  (filter_buffer),
    .cout(mul_out)
  );
  
  // Adder: mul_out + sum_buffer
  Adder_8bit adder (
    .a  (mul_out),
    .b  (sum_buffer),
    .cin(1'b0),
    .sum(sum_next),
    .cout()
  );

  // Outputs to next PE
  assign matrix_out = matrix_buffer;
  assign filter_out = filter_buffer;
  assign sum_out    = sum_next;

endmodule
