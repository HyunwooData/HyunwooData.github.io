`timescale 1ns / 1ps

module PE_tb;

  reg clk, rst;
  reg filter_active, matrix_active, sum_active;
  
  reg  [7:0] sum_in;
  reg  [7:0] matrix_in, filter_in;
  
  wire [7:0] matrix_out, filter_out;
  wire [7:0] sum_out;
  
/* ------------------------------------------ Mapping PE port for PE_tb -------------------------------------------------- */

  PE test_pe (
    .clk          (clk),
    .rst          (rst),
    .filter_active(filter_active),
    .matrix_active(matrix_active),
    .sum_active   (sum_active),
    .sum_in       (sum_in),
    .matrix_in    (matrix_in),
    .filter_in    (filter_in),
    .matrix_out   (matrix_out),
    .filter_out   (filter_out),
    .sum_out      (sum_out)
  );  

/* ------------------------------------------ Clock generation -------------------------------------------------- */

  always #10 clk = ~clk;

/* ------------------------------------------ Stimulus -------------------------------------------------- */

  initial begin
    clk = 1'b0;
    rst = 1'b1;

    // ?? ??
    filter_active = 1'b0;
    matrix_active = 1'b0;
    sum_active    = 1'b0;

    matrix_in = 8'd0;
    filter_in = 8'd0;
    sum_in    = 8'd0;
 
    // reset ??
    #15 rst = 1'b0;

    // ? ?? ??: matrix=6, filter=9, sum=20
    #50;
    matrix_active = 1'b1;
    filter_active = 1'b1;
    sum_active    = 1'b1;
    matrix_in     = 8'd6;
    filter_in     = 8'd9;
    sum_in        = 8'd20;

    // enable ???, ? ?? ??? ?????? ? ??? (???)
    #30;
    matrix_active = 1'b0;
    filter_active = 1'b0;
    sum_active    = 1'b0;
    matrix_in     = 8'd3;
    filter_in     = 8'd2;
    sum_in        = 8'd10;

    #30;
    matrix_active = 1'b1;
    filter_active = 1'b1;
    sum_active    = 1'b1;

    #50;
    $finish;
  end

endmodule
