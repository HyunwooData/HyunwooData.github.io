`timescale 1ns / 1ps

module display_tb;

  reg clk, rst, display_active; 
  reg [7:0] c11_22, c12_22, c21_22, c22_22;
  reg [7:0] c11_33, c12_33, c21_33, c22_33;

  // ------------------------------------------ ?? ?? ------------------------------------------ //
  wire display_done;

  // digit, seg7? display_module ?? reg???
  // waveform?? ?? ?? hierarchical reference? ???
  wire [3:0] digit_sel;
  wire [6:0] seg_7_display;

  /* ------------------------------------------ DUT ???? ------------------------------------------ */

  display_module dut (
    .clk           (clk),
    .rst           (rst),
    .display_active(display_active),

    // Cout 2x2
    .c11_22 (c11_22), 
    .c12_22 (c12_22),
    .c21_22 (c21_22), 
    .c22_22 (c22_22),

    // Cout 3x3
    .c11_33 (c11_33), 
    .c12_33 (c12_33),
    .c21_33 (c21_33), 
    .c22_33 (c22_33),

    .display_done(display_done)
  );

  // ?? reg? ?????? ?? hierarchical ??
  assign digit_sel     = dut.digit;
  assign seg_7_display = dut.seg7;

  /* ------------------------------------------ ?? ?? ------------------------------------------ */

  always #5 clk = ~clk;

  /* ------------------------------------------ ?? ?? ------------------------------------------ */

  initial begin
    clk            = 1'b0;
    rst            = 1'b1;
    display_active = 1'b0;

    #50;
    rst            = 1'b0;
    display_active = 1'b1;
    
        #10
    // 3x3 ??
    c11_33 = 192; 
    c12_33 = 237; 
    c21_33 = 116; 
    c22_33 = 161;
    
    #10
    // 2x2 ??
    c11_22 = 192; 
    c12_22 = 237; 
    c21_22 = 116; 
    c22_22 = 161; 
  end

endmodule
