`timescale 1ns / 1ps

module display_module(
  input clk, rst, display_active, 
  
  input [7:0] c11_22, c12_22, c21_22, c22_22,
  input [7:0] c11_33, c12_33, c21_33, c22_33,

  output display_done
);

reg [26:0] sec_clk_cnt, seg_clk_cnt;
reg [3:0] sec_cnt;
reg seg_clk;
reg [3:0] LED_BCD;
reg [7:0]  c_num;

reg [3:0] digit;
reg [6:0] seg7;
 
 
 always @(posedge clk) begin
        if (rst) begin
            sec_clk_cnt <= 0;
        end
        
        else if (sec_clk_cnt==27'd99) begin  //for tb
        //else if (sec_clk_cnt==27'd99999999) begin
            sec_clk_cnt <= 0;
            
        end
        else if(display_active) begin
        
            sec_clk_cnt<=sec_clk_cnt+1;
        end
        
    end
 
 always @(posedge clk) begin
        if (rst) begin
            sec_cnt <= 0;
        end
        
        else if (sec_cnt==9) begin
            sec_cnt <= 0;
            
        end
        else if(sec_clk_cnt==27'd99) begin // for tb
        //else if(sec_clk_cnt==27'd99999999) begin
        
            sec_cnt<=sec_cnt+1;
        end   
 end   
    
 always @(posedge clk) begin
        if (rst) begin
            seg_clk_cnt <= 0;
            seg_clk<=0;
        end
        
        
        else if (seg_clk_cnt==27'd9) begin // for tb
          // else if (seg_clk_cnt==27'd99999) begin
            seg_clk_cnt <= 0;
            seg_clk=~seg_clk;
            
        end
        else if(display_active) begin
        
            seg_clk_cnt<=seg_clk_cnt+1;
        end
        
    end   
     
always @(posedge seg_clk, posedge rst) begin
        if (rst) begin
          digit <= 4'b1000; 
        end
        
        else if (display_active) begin
          digit <= {digit[0], digit[3:1]};
        end
end    
        
always@(*) begin
    case(digit)
        4'b1000: LED_BCD=c_num / 1000;
        4'b0100: LED_BCD=(c_num%1000) / 100;
        4'b0010: LED_BCD=((c_num%1000)%100) / 10;
        4'b0001: LED_BCD=((c_num%1000)%100) % 10;
        default: LED_BCD=0;
    endcase
end
  
always@(*) begin
    case(LED_BCD) 
        4'b0000: seg7 = 7'b1111110;  //0
        4'b0001: seg7 = 7'b0110000;  //1
        4'b0010: seg7 = 7'b1101101;  //2
        4'b0011: seg7 = 7'b1111001;  //3
        4'b0100: seg7 = 7'b0110011;  //4
        4'b0101: seg7 = 7'b1011011;  //5
        4'b0110: seg7 = 7'b1011111;  //6
        4'b0111: seg7 = 7'b1110000;  //7
        4'b1000: seg7 = 7'b1111111;  //8
        4'b1001: seg7 = 7'b1111011;  //9
        default: seg7 = 7'b1111110;  //0
    endcase
end 
  
always @(*) begin
    case(sec_cnt)
        4'd1 :  c_num = c11_33;
        4'd2 :  c_num = c12_33;
        4'd3 :  c_num = c21_33;
        4'd4 :  c_num = c22_33;
        4'd5 :  c_num = c11_22;
        4'd6 :  c_num = c12_22;
        4'd7 :  c_num = c21_22;
        4'd8 :  c_num = c22_22; 
        default: c_num = 0;       
    endcase
end
    
assign display_done = (sec_cnt == 4'd9);   
    
endmodule

