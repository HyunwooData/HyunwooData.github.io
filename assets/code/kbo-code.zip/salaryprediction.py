import pandas as pd
import sklearn
from query import multi_search_by_value


class Modelpredict:

    def __init__(self, data_list):
        ''' 데이터 리스트(hitter, pitcher, runner, defense, salary)를 받으면 모델을 로드해 결과값을 반환하는 클래스. salary는 제외!'''

        self.data_list = data_list[:-1]
        self.salary = data_list[-1]

    def search_for_model_insert(self, name, year, team):
        '''선수명, 연도(숫자형), 팀명을 입력하면 연봉db에서 해당 선수의 정보를 찾고, 정보가 있다면 그 정보를 반환하고, 없다면
            model에 맞는 형태로 데이터를 반환하고, 객체에 저장하는 함수'''
        standard = ['선수명', 'Year', '팀명']
        value = [name, year, team]
        find = []

        self.indb = multi_search_by_value(self.salary, standard, value)

        if len(self.indb) != 0:
            return self.indb

        try:
            for idx, data in enumerate(self.data_list):
                if idx == 0:
                    row_find = multi_search_by_value(data, standard, value)
                    if len(row_find) != 0:
                        find = row_find
                elif idx == 1:
                    row_find = multi_search_by_value(data, standard, value)
                    if len(row_find) != 0:
                        find = row_find
                else:
                    find_one = multi_search_by_value(data, standard, value)
                    findtemp = pd.merge(find_one, find, how='inner', on=['선수명', '팀명'])
                    if findtemp.shape[0] != 0:
                        find = findtemp
            if find.shape[1] == 50:  # hitter
                self.for_train = self.hitter_preprocessing(find)
            elif find.shape[1] == 48:  # pitcher
                self.for_train = self.pitcher_preprocessing(find)
            else:
                print('Data found doesn`t match to the input data')
                self.for_train = -1
        except:
            self.for_train = -1

        return self.for_train

    def hitter_preprocessing(self, hitter_train):
        hitter_train.columns = ['선수명', '팀명', 'POS', 'G', 'GS', 'IP', 'E', 'PKO_d', 'PO', 'A', 'DP', \
                                'FPCT', 'PB', 'SB_d', 'CS_d', 'CS%', 'Year', 'G_r', 'SBA', 'SB_r', \
                                'CS_r', 'SB%', 'OOB', 'PKO_r', 'Year_x', 'AVG', 'G_y', 'PA', 'AB', 'R', \
                                'H', '2B', '3B', 'HR', 'TB', 'RBI', 'SAC', 'SF', 'Year_y', 'BB', 'IBB', \
                                'HBP', 'SO', 'GDP', 'SLG', 'OBP', 'OPS', 'MH', 'RISP', 'PH-BA']
        # 칼럼 지우기 및 순서 변경
        rm_col_hitter = hitter_train.loc[:, ['G', 'GS', 'IP', 'E', 'PKO_d', 'PO', 'A', 'DP', 'PB', 'SB_d', 'CS_d', \
                                             'G_r', 'SBA', 'SB_r', 'CS_r', 'OOB', 'PKO_r', 'AVG', 'G_y', 'PA', 'AB', \
                                             'R', 'H', '2B', '3B', 'HR', 'TB', 'RBI', 'SAC', 'SF', 'BB', 'IBB', \
                                             'HBP', 'SO', 'GDP', 'SLG', 'OBP', 'OPS', 'MH', 'RISP', 'PH-BA']]
        return rm_col_hitter

    def pitcher_preprocessing(self, pitcher_train):
        pitcher_train.columns = ['선수명', '팀명', 'POS', 'G', 'GS', 'IP', 'E', 'PKO', 'PO', 'A', 'DP', \
                                 'FPCT', 'PB', 'SB', 'CS', 'CS%', 'Year', 'ERA', 'G_y', 'W', 'L', 'SV', \
                                 'HLD', 'WPCT', 'IP_y', 'H', 'HR', 'BB', 'HBP', 'SO', 'R', 'ER', 'WHIP', \
                                 'Year_y', 'CG', 'SHO', 'QS', 'BSV', 'TBF', 'NP', 'AVG', '2B', '3B', \
                                 'SAC', 'SF', 'IBB', 'WP', 'BK']
        rm_col_pitcher = pitcher_train.loc[:, ['G', 'GS', 'IP', 'E', 'PKO', 'PO', 'A', 'DP', 'PB', 'SB', 'CS', 'ERA', \
                                               'W', 'L', 'SV', 'HLD', 'WPCT', 'H', 'HR', 'BB', 'HBP', 'SO', 'R', 'ER', \
                                               'WHIP', 'CG', 'SHO', 'QS', 'BSV', 'TBF', 'NP', 'AVG', '2B', '3B', 'SAC', \
                                               'SF', 'IBB', 'WP', 'BK']]
        return rm_col_pitcher

    def predict(self, batter_model, pitcher_model):

        if self.for_train.shape[1] == 41:  # batter
            result = batter_model.predict(self.for_train)[0]
        elif self.for_train.shape[1] == 39:  # pitcher
            result = pitcher_model.predict(self.for_train)[0]
        else:
            print('Data shape error. check the preprocessing function')

        return result