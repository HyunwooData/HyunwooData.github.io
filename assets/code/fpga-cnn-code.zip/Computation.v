`timescale 1ns / 1ps

module Computation(
  input clk, rst,
  
  input [7:0] a11, a12, a13, a14,
              a21, a22, a23, a24,
              a31, a32, a33, a34,
              a41, a42, a43, a44,

  input [7:0] b11, b12, b13,
              b21, b22, b23,
              b31, b32, b33,

  input pe_active, sys33_active, sys22_active,

  //output [7:0] pe_out,
  //output c11_active, c12_active, c21_active, c22_active,
  output [7:0] s_c11, s_c12, s_c21, s_c22,
  output s_active,
  output [7:0] s3_c11, s3_c12, s3_c21, s3_c22,
  output [7:0] s2_c11, s2_c12, s2_c21, s2_c22,

  output pe_done,
  output sys33_done, sys22_done
);
    

Single_PE single_pe(
  .clk(clk),
  .rst(rst),
  .pe_active(pe_active),

  .a11(a11), .a12(a12), .a13(a13), .a14(a14),
  
.a21(a21), .a22(a22), .a23(a23), .a24(a24),
  .a31(a31), .a32(a32), .a33(a33), .a34(a34),
  .a41(a41), .a42(a42), .a43(a43), .a44(a44),

  .b11(b11), .b12(b12), .b13(b13),
  .b21(b21), .b22(b22), .b23(b23),
  .b31(b31), .b32(b32), .b33(b33),
  
  .s_active(s_active),
//.c11_active(c11_active), .c12_active(c12_active),
  
//.c21_active(c21_active), .c22_active(c22_active),
  
  
.pe_done(pe_done),
//  .pe_out(pe_out)
.s_c11(s_c11), .s_c12(s_c12), .s_c21(s_c21), .s_c22(s_c22)
);    
    
sys_33 sys_33(
  .clk(clk),
  .rst(rst),
  .sys33_active(sys33_active),

  .a11(a11), .a12(a12), .a13(a13), .a14(a14),
  
.a21(a21), .a22(a22), .a23(a23), .a24(a24),
  .a31(a31), .a32(a32), .a33(a33), .a34(a34),
  .a41(a41), .a42(a42), .a43(a43), .a44(a44),

  .b11(b11), .b12(b12), .b13(b13),
  .b21(b21), .b22(b22), .b23(b23),
  .b31(b31), .b32(b32), .b33(b33),

  .c1(s3_c11), .c2(s3_c12), .c3(s3_c21), .c4(s3_c22),
  .sys33_done(sys33_done)
);
   
sys_22 sys_22 (
  .clk(clk),
  .rst(rst),
  .sys22_active(sys22_active),

  .a11(a11), .a12(a12), .a13(a13), .a14(a14),
  
.a21(a21), .a22(a22), .a23(a23), .a24(a24),
  .a31(a31), .a32(a32), .a33(a33), .a34(a34),
  .a41(a41), .a42(a42), .a43(a43), .a44(a44),

  .b11(b11), .b12(b12), .b13(b13),
  .b21(b21), .b22(b22), .b23(b23),
  .b31(b31), .b32(b32), .b33(b33),

  .c1(s2_c11), .c2(s2_c12), .c3(s2_c21), .c4(s2_c22),
  
  .state(),
  .sys22_done(sys22_done)
);
    
endmodule

